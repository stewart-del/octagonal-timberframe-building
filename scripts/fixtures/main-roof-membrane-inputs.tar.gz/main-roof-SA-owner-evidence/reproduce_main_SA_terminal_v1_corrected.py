"""Frozen defaultSA reproduction into a NEW scratch directory only."""
import sys,os,json,gzip,hashlib,shutil,tempfile,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent/'main-roof-SA-terminal-v1';m=json.loads((HERE/'manifest.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for row in list(m['assets'].values())+m['input_guards']+list(m['frozen_recipe_import_closure'].values()):assert sha(HERE/row['path'])==row['sha256'],('FrozenHashMismatch',row['path'])
print('FROZEN_GUARDS_PASS',flush=True)
if '--verify-only' in sys.argv:raise SystemExit(0)
resume='--resume-stage'in sys.argv
stage=Path(sys.argv[sys.argv.index('--resume-stage')+1]).resolve()if resume else Path(tempfile.mkdtemp(prefix='main-SA-v1-reproduction-',dir='/workspace/timberframe-next-step/research'))
if not resume:
 shutil.copytree(HERE/'inputs',stage,dirs_exist_ok=True);shutil.copytree(HERE/'python-deps',stage/'python-deps')
 for p in (HERE/'recipes').glob('*.py'):
  text=p.read_text().replace('/workspace/sites/octagonal-timberframe-building/src/model-data.json',str(stage/'current-model-data.json')).replace('/workspace/sites/octagonal-timberframe-building/scripts',str(stage));(stage/p.name).write_text(text)
commands=[['roof_eave_starters.py'],['roof_physical_layers.py','--field-only'],['roof_physical_layers.py','--resume-fields','--main-only','--membrane-only'],['finish_main_membrane.py'],['seat_main_valley_hips.py'],['finish_eave_starter_fits.py'],['cupola_wall_upturn_finite.py'],['prove_cupola_wall_layers.py'],['audit_final_membrane_laps.py'],['pack_main_SA_rolls.py']]
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
start=int(sys.argv[sys.argv.index('--start-index')+1])if '--start-index'in sys.argv else 0
statefile=stage/'corrected-reproduction-checkpoint.json'
if resume and statefile.exists():start=max(start,json.loads(statefile.read_text()).get('last_completed_index',-1)+1)
state={'stage':str(stage),'last_completed_index':start-1,'status':'RUNNING','immutable_manifest_sha256':sha(HERE/'manifest.json')}
for index,cmd in enumerate(commands):
 if index<start:continue
 state.update({'pending_index':index,'pending_command':cmd});statefile.write_text(json.dumps(state,separators=(',',':')))
 print('RUN',' '.join(cmd),'OUTPUT',stage,flush=True);subprocess.run([sys.executable,str(stage/cmd[0]),*cmd[1:]],cwd=stage,env=env,check=True)
 state['last_completed_index']=index;statefile.write_text(json.dumps(state,separators=(',',':')))
report=json.loads((stage/'cupola-wall-finite-bend-candidate/composition-report.json').read_text());assert report['status']=='MAIN_SA_UPTURN_GP_PHYSICAL_PASS',report
stock=json.loads((stage/'roof-physical-layers-candidate/main-SA-optimized-roll-cut-plan.json').read_text());assert stock['status']=='PASS' and stock['roll_count']==5
sys.path[:0]=[str(stage),str(stage/'python-deps')]
from roof_physical_layers import read,shape
expected=read(HERE/'assets/membrane-parts.json.gz')['parts']
actual=[q for q in read(stage/'roof-physical-layers-candidate/main-membrane-checkpoint.json.gz')['parts'] if not q['id'].startswith('VDSA-CUP')]+[q for q in read(stage/'roof-eave-starter-candidate/parts.json')['parts'] if 'CUP' not in q['id']]+read(stage/'cupola-wall-finite-bend-candidate/parts.json.gz')['parts']
assert len(actual)==85,('ActualPhysicalPieceCount',len(actual))
assert {q['id'] for q in actual}=={q['id'] for q in expected},'PhysicalIDSetMismatch'
byid={q['id']:q for q in actual};equivalence=[]
for q in expected:
 old=shape(q);new=shape(byid[q['id']]);diff=max(0.,(old-new).volume())+max(0.,(new-old).volume())
 assert diff<=1e-6,(q['id'],'OccupiedDifference',diff)
 equivalence.append({'id':q['id'],'occupied_symmetric_difference_in3':diff})
(stage/'immutable-v1-equivalence.json').write_text(json.dumps({'status':'PASS','actual_count':len(actual),'id_set_exact':True,'pieces':equivalence},separators=(',',':')))
print('REPRODUCED_ACTUAL_MAIN85_PHYSICAL_PASS',stage,flush=True)
state.update({'status':'PASS','actual_count':85});statefile.write_text(json.dumps(state,separators=(',',':')))
