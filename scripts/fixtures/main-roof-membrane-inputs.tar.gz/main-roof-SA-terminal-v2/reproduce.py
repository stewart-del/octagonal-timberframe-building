"""Reproduce only the new MAIN2 fold and its85piece/boot combined gate."""
import sys,os,json,gzip,hashlib,shutil,tempfile,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;M=json.loads((HERE/'manifest.json').read_text());V1=(HERE/M['depends_on_immutable_v1']['relative_directory']).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(V1/'manifest.json')==M['depends_on_immutable_v1']['manifest_sha256']
for q in list(M['assets'].values())+list(M['frozen_recipe_import_closure'].values()):assert sha(HERE/q['path'])==q['sha256'],q['path']
print('SA_V2_FROZEN_GUARDS_PASS',flush=True)
if '--verify-only'in sys.argv:raise SystemExit(0)
stage=Path(tempfile.mkdtemp(prefix='main-SA-v2-reproduction-',dir=HERE.parent));os.symlink(V1,stage/'main-roof-SA-terminal-v1');os.symlink(V1/'python-deps',stage/'python-deps');(stage/'upper-boot-SA-compose-candidate').mkdir();(stage/'physical-closure-candidate').mkdir();shutil.copy2(HERE/'inputs/upper-porch-boot-delta-v2.json.gz',stage/'physical-closure-candidate/upper-porch-boot-delta-v2.json.gz')
for p in(HERE/'recipes').glob('*.py'):
 text=p.read_text().replace('/workspace/sites/octagonal-timberframe-building/scripts',str(stage));(stage/p.name).write_text(text)
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
subprocess.run([sys.executable,str(stage/'rebuild_main2_starter_finite_boundary_fast.py')],cwd=stage,env=env,check=True);shutil.copy2(stage/'upper-boot-SA-compose-candidate/starter-fast-replacement.json.gz',stage/'upper-boot-SA-compose-candidate/starter-replacement.json.gz');subprocess.run([sys.executable,str(stage/'audit_upper_boot_SA_composition.py')],cwd=stage,env=env,check=True)
report=json.loads((stage/'upper-boot-SA-compose-candidate/report.json').read_text());assert report['status']=='UPPER_BOOT_85SA_PHYSICAL_PASS'
sys.path[:0]=[str(stage),str(stage/'python-deps')]
from roof_physical_layers import read,native_solid,I
expected=read(HERE/'assets/MAIN2-starter-replacement.json.gz')['parts'][0];actual=read(stage/'upper-boot-SA-compose-candidate/starter-replacement.json.gz')['parts'][0];a=native_solid(expected);b=native_solid(actual);difference=(max(0.,(a-b).volume())+max(0.,(b-a).volume()))/I**3;assert difference<=1e-6,difference
(stage/'v2-reproduction-result.json').write_text(json.dumps({'status':'PASS','combined':report,'occupied_difference_from_frozen_MAIN2_in3':difference},separators=(',',':')));print('REPRODUCED_SA_V2_PASS',stage,difference,flush=True)
