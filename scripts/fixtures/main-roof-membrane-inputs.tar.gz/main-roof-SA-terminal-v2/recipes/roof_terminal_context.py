"""Read-only composition of current bounded roof weather/support sources."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent
sys.path[:0]=[str(D),str(D/'python-deps'),'/workspace/sites/octagonal-timberframe-building/scripts']
from roof_physical_layers import *
def rows(data):
 q=data['add_parts'] if 'add_parts'in data else data['parts']
 return list(q.values()) if isinstance(q,dict) else q
def load_context():
 frozen=D/'main-roof-SA-terminal-v1';inp=frozen/'inputs';a=frozen/'assets'
 primary=read(inp/'current-model-data.json')
 context={q['id']:q for q in primary['parts'] if q.get('triangles') and q['id']!='PLY' and(q.get('is_timber')or q.get('is_fastener')or q['id']=='M-TMP')}
 p=read(inp/'porch-roof-support-candidate/porch-support-patch.json')
 for k in ['add_parts','receiver_readback_snapshots_for_local_proof_only','add_fasteners','replace_fasteners']:context.update(p[k])
 context.update(read(inp/'roof-sheathing-curb-candidate/roof-blocking-candidate-patch.json')['add_parts'])
 context.update(read(inp/'physical-closure-candidate/cupola-box-wood-raw-parts.json.gz')['add_parts'])
 context.update(read(a/'new-GPwall-readback-reference.json.gz')['parts'])
 for rel in ['roof-sheathing-curb-candidate/roof-sheathing-parts.json','porch-roof-support-candidate/revised-porch-decks.json','porch-flashing-substrate-candidate/parts.json','physical-closure-candidate/porch-eave-fascia-final.json.gz','physical-closure-candidate/main-eave-wood-raw-parts.json.gz','physical-closure-candidate/physical-eave-seals.json.gz']:
  context.update({q['id']:q for q in rows(read(inp/rel))})
 for rel in ['retained-main-porch-drips.json','retained-R-saddle-leaves.json','membrane-parts.json.gz']:context.update({q['id']:q for q in rows(read(a/rel))})
 delta=read(D/'physical-closure-candidate/upper-porch-boot-delta-v2.json.gz')
 for pid in delta['removeFrozenEaveSealIds']:context.pop(pid,None)
 for key in ['replaceFrozenEaveSealParts','replace_new_envelope_parts','add_parts']:context.update(delta[key])
 replacement=D/'upper-boot-SA-compose-candidate/starter-replacement.json.gz'
 if replacement.exists():context.update({q['id']:q for q in rows(read(replacement))})
 return context

