"""Compose the immutable85SA v1 with the actual new20-part porch boot delta."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps'),'/workspace/sites/octagonal-timberframe-building/scripts']
from roof_physical_layers import *
from audit_cavity_fit import inspect_mesh
import hashlib
OUT=D/'upper-boot-SA-compose-candidate';OUT.mkdir(exist_ok=True)
def run():
 frozen=D/'main-roof-SA-terminal-v1';manifest=read(frozen/'manifest.json');inp=frozen/'inputs';a=frozen/'assets';sa=read(a/'membrane-parts.json.gz')['parts'];gp=read(a/'new-GPwall-readback-reference.json.gz')['parts'];primary=read(inp/'current-model-data.json');context={q['id']:q for q in primary['parts'] if q.get('triangles') and q['id']!='PLY' and(q.get('is_timber') or q.get('is_fastener') or q['id']=='M-TMP')};p=read(inp/'porch-roof-support-candidate/porch-support-patch.json');context.update(p['add_parts']);context.update(p['receiver_readback_snapshots_for_local_proof_only']);context.update(p['add_fasteners']);context.update(p['replace_fasteners']);context.update(read(inp/'roof-sheathing-curb-candidate/roof-blocking-candidate-patch.json')['add_parts']);context.update(read(inp/'physical-closure-candidate/cupola-box-wood-raw-parts.json.gz')['add_parts']);context.update(gp)
 for rel in ['roof-sheathing-curb-candidate/roof-sheathing-parts.json','porch-roof-support-candidate/revised-porch-decks.json','porch-flashing-substrate-candidate/parts.json','physical-closure-candidate/porch-eave-fascia-final.json.gz','physical-closure-candidate/main-eave-wood-raw-parts.json.gz','physical-closure-candidate/physical-eave-seals.json.gz']:
  x=read(inp/rel);parts=x['add_parts'] if 'add_parts'in x else x['parts'];parts=parts.values() if isinstance(parts,dict) else parts;context.update({q['id']:q for q in parts})
 for rel in ['retained-main-porch-drips.json','retained-R-saddle-leaves.json']:context.update({q['id']:q for q in read(a/rel)['parts']})
 replacement=D/'upper-boot-SA-compose-candidate/starter-replacement.json.gz'
 if replacement.exists():
  replacements={q['id']:q for q in read(replacement)['parts']};sa=[replacements.get(q['id'],q) for q in sa]
 context.update({q['id']:q for q in sa});deltafile=D/'physical-closure-candidate/upper-porch-boot-delta-v2.json.gz';delta=read(deltafile)
 for pid in delta['removeFrozenEaveSealIds']:context.pop(pid,None)
 context.update(delta['replaceFrozenEaveSealParts']);context.update(delta['replace_new_envelope_parts']);context.update(delta['add_parts']);target={q['id'] for q in sa}|set(delta['add_parts'])|set(delta['replaceFrozenEaveSealParts'])|set(delta['replace_new_envelope_parts']);solids={pid:shape(q) for pid,q in context.items()};grid=Grid();pairs=[];checks=0;raw=[]
 for pid,s in solids.items():
  if pid in delta['add_parts'] or pid in delta['replace_new_envelope_parts']:
   q=context[pid];r=inspect_mesh(np.asarray(q['vertices']),np.asarray(q['triangles'],np.uint64),require_single=True)
   if r['status']!='PASS':raw.append({'id':pid,'audit':r})
  for mid in grid.query(bounds(s)):
   if pid not in target and mid not in target:continue
   checks+=1;vol=max(0.,(s^solids[mid]).volume())
   if vol>TOL:pairs.append({'a':pid,'b':mid,'overlap_in3':vol})
  grid.add(pid,s)
 report={'status':'UPPER_BOOT_85SA_PHYSICAL_PASS' if not pairs and not raw else'BLOCKED','frozen_manifest_sha256':hashlib.sha256((frozen/'manifest.json').read_bytes()).hexdigest(),'upper_boot_delta_sha256':hashlib.sha256(deltafile.read_bytes()).hexdigest(),'SA_parts':len(sa),'new_boot_parts':len(delta['add_parts']),'context':len(context),'checks':checks,'intersections':pairs,'raw_failures':raw,'remainingInterfaces':delta['remainingInterfaces'],'scope':'Actualstaticgeometrywith85immutableSA+20newboots/4NEWfasciapockets/7oldsealtrims/2retirements. No capacity/weather/replaycertificate; latermat/cedar/metalandaccessiblebracemovementseal remainnamedinterfaces.'};dump(OUT/'report.json',report);print('DONE',len(context),'pairs',len(pairs),'raw',len(raw),'checks',checks,flush=True)
if __name__=='__main__':run()
