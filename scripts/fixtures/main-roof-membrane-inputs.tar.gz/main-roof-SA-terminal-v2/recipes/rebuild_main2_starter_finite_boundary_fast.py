"""Direct connected finite-bend boundary over the two actual upper porch boots.
Refine the already-closed parent sheet, then displace BOTH boundary faces by
the same normal field. This avoids a Boolean union of coincident thin caps.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps')]
from roof_terminal_context import *
from closed_roof_envelope import closed_roof_record
from audit_cavity_fit import inspect_mesh
import hashlib
OUT=D/'upper-boot-SA-compose-candidate'
def run():
 source=D/'main-roof-SA-terminal-v1/assets/membrane-parts.json.gz';q=next(q for q in read(source)['parts']if q['id']=='VDSA-EAVE-STARTER-MAIN2');old=shape(q);f=frame_main(2);U,N=f['U'],f['N'];refined=old.refine_to_length(.5);mesh=refined.to_mesh64();v=np.asarray(mesh.vert_properties)[:,:3].copy();t=np.array(mesh.tri_verts,dtype=np.uint64,order='C');u=v@U;y=v[:,1]
 # The two real .4/.8mm tape stacks top out at .031496in above fascia.
 # A40mil finite bridge clears them. Exact source roof/corner surfaces are
 # unchanged outside these two local U intervals and below the eave fold.
 a=np.abs(u);wu=np.maximum(0.,np.minimum(np.minimum((a-40.)/3.,(61.-a)/3.),1.));wy=np.maximum(0.,np.minimum((97.3782059080668-y)/(97.3782059080668-97.25),1.));qrel=v@N-185.226906502257;stepY=95.3782059080668;tape=.00035/I
 # Re-form the prior .35mm tape step into a flat25mil wrap over the new
 # .4mm fascia boot. Its outerface .017+.025=.042in remains BELOW the fixed
 # copper's .050in innerface. The double-layer perpendicular corner tabs
 # are cleared by the explicit straight plate openings, below.
 baseline=np.where(y<stepY,tape,0.);denom=np.full(len(v),.025);fold=(y>=stepY)&(y<=stepY+.025);baseline[fold]=0.;denom[fold]=.025+tape
 layer=np.clip((qrel-baseline)/denom,0.,1.);target=.017+.025*layer;delta=(target-qrel)*wu*wy;v+=delta[:,None]*N
 formed=m.Manifold(m.Mesh64(np.asarray(v,order='C'),t));assert str(formed.status())=='Error.NoError';B=np.column_stack([U,UP,N]);O=N*185.226906502257
 knifeplan=unary_union([box(46.9,90.,54.6,94.42),box(-54.6,90.,-46.9,94.42)]);tools=[prism(p,[0,0,-.1],[0,0,1.]).transform(np.column_stack([B,O]).tolist())for p in pieces(knifeplan)];before=formed;formed=formed-m.Manifold.batch_boolean(tools,m.OpType.Add);knifevol=max(0.,(before-formed).volume());print('FINITE_DIRECT',len(v),len(t),'components',len(formed.decompose()),'knife',knifevol,flush=True)
 # Remove redundant coplanar subdivisions before the strict raw audit.
 native_before=native_solid(pack(formed));native_after=native_before.simplify(1e-11);mm=native_after.to_mesh64();rec={'vertices':np.asarray(mm.vert_properties)[:,:3].tolist(),'triangles':np.asarray(mm.tri_verts).tolist(),'volume_m3':native_after.volume()};audit=inspect_mesh(np.asarray(rec['vertices']),np.asarray(rec['triangles'],np.uint64),require_single=True);delta=(max(0.,(native_before-native_after).volume())+max(0.,(native_after-native_before).volume()))/I**3;assert audit['status']=='PASS' and delta<=TOL,(audit,delta);formed=shape(rec);receipt={'status':'PASS','method':'canonical-metre occupied-equivalent coplanar compaction','occupied_difference_in3':delta,'audit':audit,'native_simplification_tolerance_m':1e-11}
 result={**q,**rec,'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier membrane','upper_porch_boot_v2_reseat':{'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'boot_delta_sha256':hashlib.sha256((D/'physical-closure-candidate/upper-porch-boot-delta-v2.json.gz').read_bytes()).hexdigest(),'direct_boundary_recipe':'Refine source boundary to.5in maximum native edge; re-form the old.35mm tape step to a25mil wrap over a.017in fascia-normal seat. U ramps40..43 and58..61in at both plate penetrations; Y ramp97.25..97.3782059080668in. Source roof and both remote corner interfaces remain exact.','selected_fascia_normal_inner_seat_in':.017,'selected_fascia_normal_outer_face_in':.042,'nominal_fascia_normal_gauge_in':.025,'maximum_selected_upper_transition_slope':.017/(97.3782059080668-97.25),'maximum_upper_transition_normal_gauge_approximation_fraction':1-1/math.sqrt(1+(.017/(97.3782059080668-97.25))**2),'parent_blank_fold_allowance_in':.1,'declared_plate_knife_removed_in3':knifevol,'straight_plate_knife_openings_local_UY_in':[[46.9,90.,54.6,94.42],[-54.6,90.,-46.9,94.42]],'scope':'Actual finite field re-fold gross envelope, microscopic inner/outer fibers not modeled, straight stock knife cuts. No factory fold/bonding/weather approval. Fixed25mil stock, no mat compression or source timber/copper changes.'},'raw_mesh_status':receipt['status'],'boundary_receipt':receipt};dump(OUT/'starter-fast-replacement.json.gz',{'parts':[result],'retire_ids':[q['id']],'source_guard':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Direct-boundary MAIN2 replacement only. Immutable v1 remains unchanged.'});print('DIRECT_STARTER_PASS',len(rec['triangles']),receipt['method'],flush=True)
if __name__=='__main__':run()
