// Portable real-size roof math. Geometry kernels supply clipping/support/rays.
export const INCH=.0254;
export const STOCK=Object.freeze({
 cedar:{lengthIn:18,buttIn:.45,tipIn:.0625,tipStatus:'Explicitprofileassumption',keywayIn:.25,defaultWidthIn:6,maxSelectedWidthIn:14},
 plywood:{lengthIn:95.875,widthIn:47.875,thicknessIn:.703,rawLengthIn:96,rawWidthIn:48,requiredStamp:'APA STRUCTURAL I48/24 C-CEXTERIOR PS1 23/32CAT; suppliersubmittal/actualthicknessacceptance'},
 iceBarrier:{manufacturer:'BenjaminObdyke',product:'VaporDrySA',widthIn:57,lengthIn:960,thicknessIn:.025,horizontalLapIn:4,endLapIn:6,cornerLapIn:12,wallUpturnIn:12,approval:'ManufacturerAC48icebarrier/fullroofcoverage; D1970nailsealing'},
 mat:{product:'CedarBreather',widthIn:39,lengthIn:738,thicknessIn:.285,courseLapIn:0},
 copper:{supplier:'AlaskanCopper',partNumber:'492794',widthIn:48,lengthIn:120,thicknessIn:.027,weightOzFt2:20},
 nails:{field:{product:'T7SN7B',lengthIn:2.25,shankIn:.092,headIn:7/32,material:'316SS'},cap:{product:'T20SNDB',lengthIn:4,shankIn:.131,headIn:.25,material:'316SS',procurement:'Historicalmanufacturerpart/currentavailabilityunconfirmed'},flashing:{product:'T311ARN1',lengthIn:1.25,shankIn:.120,headIn:11/32,material:'316SS'},deck:{product:'8DHDGPT500/2500',lengthIn:2.5,shankIn:.131,headIn:.285,material:'HDGcarbonsteel',prototype:'FLOOR-8DHDGPT',scope:'Actualselectedroofgeometry; capacityunqualified'}}
});
const add=(a,b)=>a.map((v,i)=>v+b[i]),mul=(a,s)=>a.map(v=>v*s),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const sub=(a,b)=>add(a,mul(b,-1));
export const unit=a=>mul(a,1/Math.hypot(...a));
const UP=[0,1,0],C=Math.cos(Math.PI/8);
export function roofDatums({mainPitch=4,wallHeightIn=89.03615129287599,cupolaLiftIn=10}={}){
 const p=mainPitch/12,s=mainPitch/12,root=Math.sqrt(1+p*p),base=Math.sqrt(1+1/9);
 const mainInterceptIn=90+(wallHeightIn-89.03615129287599)+176*p+5+10*root;
 const cupShiftIn=(wallHeightIn-89.03615129287599)+135*(p-1/3)+5*(root-base);
 const seatIn=188.77046276694728+cupShiftIn+(cupolaLiftIn-10);
 return {units:'inches',cupolaPitchDerivedFrom:'mainPitch',pitchInterpretation:'UIrise/12alongradialHIP/CRaxis',mainHipSlope:p,mainFaceSlope:p/C,mainInterceptIn,cupShiftIn,cupolaSeatIn:seatIn,cupolaRadialSlope:s,cupolaFaceSlope:s/C,cupolaTopInterceptIn:seatIn+39.5*s+6*Math.sqrt(1+s*s),requirements:['ApplyactualstoppedmainRbackingoutside45in/eavemiterateachnewpitch.','ApplyactualstoppedCRbackingoutside7in; unbackedrectangularCRcornerisnotfullfacebearing.']};
}
export function faceFrame({faceIndex=0,hipSlope=1/3,planeInterceptIn=164.20759220056127,outerApothemIn=200*C,innerApothemIn=42,deckThicknessIn=.703}={}){
 const a=-(faceIndex+.5)*Math.PI/4,N=[Math.cos(a),0,Math.sin(a)],U=[-N[2],0,N[0]],p=hipSlope/C,g=Math.sqrt(1+p*p),W=unit(add(UP,mul(N,p))),S=unit(add(mul(N,-1),mul(UP,p)));
 const O=add(add(mul(N,outerApothemIn*INCH),mul(UP,(planeInterceptIn-p*outerApothemIn)*INCH)),mul(W,deckThicknessIn*INCH));
 return {units:'meters',id:'MAIN'+faceIndex,O,U,S,W,N,faceSlope:p,gamma:g,roofSurfaceHeightM:(outerApothemIn-innerApothemIn)*g*INCH,deckThicknessM:deckThicknessIn*INCH};
}
export const localPoint=(f,u,s,w)=>add(add(add(f.O,mul(f.U,u)),mul(f.S,s)),mul(f.W,w));
export function cedarExposureIn(faceSlope){const pitch=12*faceSlope;if(pitch<3-1e-8)throw Error('CSSBcedarminimum3:12');return pitch<4-1e-8?4.25:5.5;}
export function courseStarts({heightM,faceSlope,overhangIn=0,topRemainderIn=9}){
 const exposure=cedarExposureIn(faceSlope)*INCH,start=-overhangIn*INCH,end=heightM-topRemainderIn*INCH;
 const result=[start];for(let q=start;q<=end+1e-10;q+=exposure)result.push(q);if(end-result.at(-1)>.25*INCH)result.push(end);return result;
}
export function rigidProfile({startM,seatingM,thetaRad,lengthM=18*INCH,buttM=.45*INCH,tipM=.0625*INCH}){
 const d=[Math.cos(thetaRad),-Math.sin(thetaRad)],n=[Math.sin(thetaRad),Math.cos(thetaRad)],p=[startM,seatingM];
 const plus=(a,b)=>a.map((v,i)=>v+b[i]),scale=(a,s)=>a.map(v=>v*s);
 return [p,plus(p,scale(d,lengthM)),plus(plus(p,scale(d,lengthM)),scale(n,tipM)),plus(p,scale(n,buttM))];
}
function clipInterval(poly,lo,hi){let p=poly;for(const [side,c] of [[1,lo],[-1,-hi]]){const out=[];for(let i=0;i<p.length;i++){const a=p[i],b=p[(i+1)%p.length],da=side*a[0]-c,db=side*b[0]-c;if(da>=-1e-12)out.push(a);if(da*db<0){const t=da/(da-db);out.push(a.map((v,j)=>v+t*(b[j]-v)));}}p=out;}return p;}
function golden(fn,a,b){const r=(Math.sqrt(5)-1)/2;let c=b-r*(b-a),d=a+r*(b-a),fc=fn(c),fd=fn(d);for(let i=0;i<80;i++){if(fc<fd){b=d;d=c;fd=fc;c=b-r*(b-a);fc=fn(c);}else{a=c;c=d;fc=fd;d=a+r*(b-a);fd=fn(d);}}return(a+b)/2;}
export function seatCourseProfile(startM,priorProfiles,{baseM=.310*INCH,lengthM=18*INCH}={}){
 const h=theta=>{const end=startM+lengthM*Math.cos(theta),pts=[[startM,baseM],[end,baseM]];for(const old of priorProfiles)pts.push(...clipInterval(old,startM,end));return Math.max(...pts.map(p=>p[1]+Math.tan(theta)*(p[0]-startM)));};
 const objective=t=>h(t)-lengthM/2*Math.sin(t);const samples=Array.from({length:27},(_,i)=>.13*i/26);let best=0;for(let i=1;i<samples.length;i++)if(objective(samples[i])<objective(samples[best]))best=i;
 const thetaRad=golden(objective,samples[Math.max(0,best-1)],samples[Math.min(26,best+1)]),seatingM=h(thetaRad)+1e-9*INCH;
 return {thetaRad,seatingM,profile:rigidProfile({startM,seatingM,thetaRad,lengthM}),qualification:'Actual3Dboundary/metal/local-supportfitmustfollowthis1Dcoursefit; nodimensionstretch.'};
}
function outwardFaces(vertices,triangles){const center=vertices[0].map((_,j)=>vertices.reduce((s,v)=>s+v[j],0)/vertices.length);return triangles.map(t=>{const p=t.map(i=>vertices[i]),n=cross(sub(p[1],p[0]),sub(p[2],p[0])),c=p[0].map((_,j)=>p.reduce((s,v)=>s+v[j],0)/3);return dot(n,sub(c,center))<0?[t[0],t[2],t[1]]:t;});}
export function rigidShingleStock(f,u0M,u1M,profile){const vertices=[];for(const u of[u0M,u1M])for(const[s,w]of profile)vertices.push(localPoint(f,u,s,w));const tt=[[0,1,2],[0,2,3],[4,6,5],[4,7,6]];for(let i=0;i<4;i++){const j=(i+1)%4;tt.push([i,j,j+4],[i,j+4,i+4]);}return {vertices,triangles:outwardFaces(vertices,tt),stockLengthM:18*INCH,stockWidthM:u1M-u0M,clipRequired:true};}
export function fieldNailHeads(f,profile,thetaRad,actualNailLineBoundsM,{stationIn=7}={}){
 const L=18*INCH,station=stationIn*INCH,t=.45*INCH+(.0625-.45)*INCH*station/L,d=[Math.cos(thetaRad),-Math.sin(thetaRad)],n=[Math.sin(thetaRad),Math.cos(thetaRad)];
 const q=profile[0][0]+station*d[0]+t*n[0],w=profile[0][1]+station*d[1]+t*n[1],angle=thetaRad+Math.atan((.45-.0625)/18),normal=add(mul(f.S,Math.sin(angle)),mul(f.W,Math.cos(angle))),[lo,hi]=actualNailLineBoundsM;
 if(hi-lo<2*INCH)throw Error('Retainedstockneedsmerge/recutfor2realnails');return {heads:[localPoint(f,lo+.75*INCH,q,w),localPoint(f,hi-.75*INCH,q,w)],outwardNormal:normal,product:STOCK.nails.field,stationIn,requiredRay:'Actualphysicalleafandallinterleavedlayers, then>=.75inwoodORcompletelythroughactualroofsheathing. Neverstretchproductlength.'};
}
export function capLeafStock({origin,V,U,W,betaRad,startM,thetaRad,seatingM,side,cross0M,cross1M}){
 const along=sub(mul(V,Math.cos(thetaRad)),mul(W,Math.sin(thetaRad))),bisector=add(mul(V,Math.sin(thetaRad)),mul(W,Math.cos(thetaRad))),across=sub(mul(U,side*Math.cos(betaRad)),mul(bisector,Math.sin(betaRad))),normal=add(mul(U,side*Math.sin(betaRad)),mul(bisector,Math.cos(betaRad))),O=add(add(origin,mul(V,startM)),mul(W,seatingM));
 const local={O,U:across,S:along,W:normal};const profile=[[0,0],[18*INCH,0],[18*INCH,.0625*INCH],[0,.45*INCH]];
 return {...rigidShingleStock(local,cross0M,cross1M,profile),frame:{O,along,across,normal},requiredOperations:['Commonlongitudinalaxisfortwoleaves, thenBooleanreceivingleafminuscoverleaf.','Selected1e-7inverticalfitclearance; actualindependentrawmeshmustpass.','Clipendonly; retainfull18instockdefinition. TwofixedproductnailsPERphysicalleaf atstation7.5in.']};
}
export function capNailHeads(frame,crossStationsM,{stationIn=7.5}={}){
 if(crossStationsM.length!==2)throw Error('Every physical cap leaf needs two nail stations.');
 const station=stationIn*INCH,t=(.45+(.0625-.45)*stationIn/18)*INCH,a=Math.atan((.45-.0625)/18),normal=add(mul(frame.along,Math.sin(a)),mul(frame.normal,Math.cos(a)));
 return {heads:crossStationsM.map(u=>add(add(add(frame.O,mul(frame.along,station)),mul(frame.across,u)),mul(frame.normal,t))),outwardNormal:normal,product:STOCK.nails.cap,stationIn,requiredRay:'Fixed real4in historicalT20SNDB; probe every leaf/interleaved wood/deck/receiver. Report infeasible reach or collisions explicitly.'};
}
export function membraneCoursePlan(heightM,{projectedWidthIn=56,lapIn=4}={}){
 if(projectedWidthIn>57||lapIn<4)throw Error('InvalidVaporDrystock/lap');const result=[];for(let s=0,i=0;s<heightM;s+=(projectedWidthIn-lapIn)*INCH,i++)result.push({id:'VDSA-C'+i,startM:s,endM:Math.min(heightM,s+projectedWidthIn*INCH),rawStockWidthM:57*INCH,maxRollLengthM:960*INCH,lapM:lapIn*INCH,physicalThicknessM:.025*INCH,foldAllowanceM:(57-projectedWidthIn)*INCH});return result;
}
export function plywoodBlankGrid(bounds,{pitchUM=96*INCH,pitchSM=48*INCH}={}){
 const[a,b,c,d]=bounds,out=[];for(let u=Math.floor(a/pitchUM)*pitchUM;u<c;u+=pitchUM)for(let s=Math.floor(b/pitchSM)*pitchSM;s<d;s+=pitchSM)out.push({u0M:u+.0625*INCH,u1M:u+95.9375*INCH,s0M:s+.0625*INCH,s1M:s+47.9375*INCH,thicknessM:.703*INCH,rawStock:STOCK.plywood,qualification:'Cliptotrueface/collar/valley; seamsmustrelocatetoactualbearingoraddrealsupport. Thisgridisnotitselfaqualifiedrooflayout.'});return out;
}
export const REQUIRED_RUNTIME_CHECKS=Object.freeze(['Recomputeactualstock/cutsanduniqueIDsateachparameterstate; noaffinearchitecturestretch.','Actualclosedwood/woodandmetal/metalnonoverlap; intentionalfastenerpenetrationonly.','Actualbearing/support, holes/collars/valley/exposedeaves; nominalplanesaloneinsufficient.','Everynewnailhasfixedpublishedproductgeometry,actualwood/layerreceiversandlocalinsertionwithdrawalprerequisites.','Ifstock/nail/productconditionsfailatastate,returnexplicitinfeasible/needsdifferentverifiedproduct; donotstretchhardwareorhideunsupportedpanels.','Refreshinstallation/removalroutesfromnewphysicalgeometry; preserveindividualfastenersandremovalprerequisites.']);
