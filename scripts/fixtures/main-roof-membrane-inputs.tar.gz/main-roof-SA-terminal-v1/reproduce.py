"""Frozen defaultSA reproduction into a NEW scratch directory only."""
import sys,os,json,gzip,hashlib,shutil,tempfile,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;m=json.loads((HERE/'manifest.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for row in list(m['assets'].values())+m['input_guards']+list(m['frozen_recipe_import_closure'].values()):assert sha(HERE/row['path'])==row['sha256'],('FrozenHashMismatch',row['path'])
print('FROZEN_GUARDS_PASS',flush=True)
if '--verify-only' in sys.argv:raise SystemExit(0)
stage=Path(tempfile.mkdtemp(prefix='main-SA-v1-reproduction-',dir='/workspace/timberframe-next-step/research'));shutil.copytree(HERE/'inputs',stage,dirs_exist_ok=True);shutil.copytree(HERE/'python-deps',stage/'python-deps')
for p in (HERE/'recipes').glob('*.py'):
 text=p.read_text().replace('/workspace/sites/octagonal-timberframe-building/src/model-data.json',str(stage/'current-model-data.json')).replace('/workspace/sites/octagonal-timberframe-building/scripts',str(stage));(stage/p.name).write_text(text)
commands=[['roof_eave_starters.py'],['finish_eave_starter_fits.py'],['roof_physical_layers.py','--field-only'],['roof_physical_layers.py','--resume-fields','--main-only','--membrane-only'],['finish_main_membrane.py'],['seat_main_valley_hips.py'],['cupola_wall_upturn_finite.py'],['prove_cupola_wall_layers.py'],['audit_final_membrane_laps.py'],['pack_main_SA_rolls.py']]
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
for cmd in commands:print('RUN',' '.join(cmd),'OUTPUT',stage,flush=True);subprocess.run([sys.executable,str(stage/cmd[0]),*cmd[1:]],cwd=stage,env=env,check=True)
report=json.loads((stage/'cupola-wall-finite-bend-candidate/composition-report.json').read_text());assert report['status']=='MAIN_SA_UPTURN_GP_PHYSICAL_PASS',report
stock=json.loads((stage/'roof-physical-layers-candidate/main-SA-optimized-roll-cut-plan.json').read_text());assert stock['status']=='PASS' and stock['roll_count']==5
print('REPRODUCED_MAIN85_PHYSICAL_PASS',stage,flush=True)
