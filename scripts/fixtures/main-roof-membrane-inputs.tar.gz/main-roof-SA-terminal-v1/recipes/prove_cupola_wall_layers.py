"""Exact bounded main/porchSA +cupwall composition and NEWGP-only seats."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps'),'/workspace/sites/octagonal-timberframe-building/scripts']
from roof_physical_layers import *
from export_cupola_aux_instances import swept
from closed_roof_envelope import closed_roof_record
import hashlib
OUT=D/'cupola-wall-finite-bend-candidate'
def run():
 path=D/'roof-physical-layers-candidate/main-membrane-checkpoint.json.gz';main=[q for q in read(path)['parts'] if not q['id'].startswith('VDSA-CUP')];up=read(OUT/'parts.json.gz')['parts'];starters=[q for q in read(D/'roof-eave-starter-candidate/parts.json')['parts'] if 'CUP' not in q['id']];drips=[q for q in read(D/'roof-edge-flashing-candidate/drip-parts.json')['parts'] if 'CUP' not in q['id']];saddles=[q for q in read(D/'air-boundary-candidate/air-boundary-parts.json.gz')['parts'] if q['id'].startswith('CU-SADDLE-')];layers={q['id']:q for q in main+up+starters};supports={q['id']:shape(q) for q in main+up+starters+drips+saddles};boxfile=D/'physical-closure-candidate/cupola-box-wood-raw-parts.json.gz';boxwood=read(boxfile)['add_parts'];tools={};GP={};toolreceipts=[]
 from roof_heightfield_sheet import top_faces
 from shapely.strtree import STRtree
 from shapely.geometry import box as rectangle
 for face in range(8):
  pid=next(pid for pid,q in boxwood.items() if pid.endswith('-WALL-PLY') and q.get('faceIndex',face)==face and (('faceIndex'in q) or pid==['BOX-CUP-N-WALL-PLY','BOX-CUP-NW-WALL-PLY','BOX-CUP-W-WALL-PLY','BOX-CUP-SW-WALL-PLY','BOX-CUP-S-WALL-PLY','BOX-CUP-SE-WALL-PLY','BOX-CUP-E-WALL-PLY','BOX-CUP-NE-WALL-PLY'][face]));q=boxwood[pid];wood=shape(q);f=frame_main(face);B=np.column_stack([f['U'],f['N'],UP]);v=np.asarray(q['vertices'])/I;u0,u1=float(min(v@f['U'])),float(max(v@f['U']));q0,q1=float(min(v@f['N'])),float(max(v@f['N']));C=float(f['O']@f['W']);patches=[]
  for fid,film in supports.items():
   if not bbox_overlap(bounds(wood),bounds(film)):continue
   mesh=film.to_mesh64();vv=np.asarray(mesh.vert_properties)[:,:3]
   for tri in mesh.tri_verts:
    points=vv[np.asarray(tri)];xy=np.column_stack([points@f['U'],points@f['N']]);poly=Polygon(xy)
    # ALL real boundaryfaces contribute an upperoccupiedbound, including
    # steep25mil step risers whose projection extends past their topface.
    # Ignoring those faces left six measurable GP/SA corner contacts.
    if poly.area<1e-10 or max(points[:,1])<145. or min(points[:,1])>153.:continue
    hvals=(points-f['O'])@f['W'];h=np.linalg.solve(np.column_stack([xy,np.ones(3)]),hvals);poly=poly.intersection(rectangle(u0,q0,u1,q1))
    if poly.is_empty or poly.area<1e-10:continue
    if max(height(h,pt) for pp in pieces(poly) for pt in np.asarray(pp.exterior.coords))>.5:continue
    patches.append({'polygon':poly,'plane':h,'id':fid})
  index=STRtree([p['polygon'] for p in patches]);bands=[];cuts=[];hosts=set();step=.125
  for lo in np.arange(u0,u1-1e-8,step):
   hi=min(lo+step,u1);reg=rectangle(lo,q0,hi,q1);heights=[0.]
   for idx in index.query(reg):
    pp=patches[int(idx)];hit=pp['polygon'].intersection(reg)
    for poly in pieces(hit):
     if not poly.is_empty and poly.area>1e-10:heights += [height(pp['plane'],pt) for pt in np.asarray(poly.exterior.coords)];hosts.add(pp['id'])
   level=math.ceil((max(heights)+1e-6)*1000.)/1000.+.0001
   if bands and abs(bands[-1]['height']-level)<1e-10:bands[-1]['u1']=hi
   else:bands.append({'u0':lo,'u1':hi,'height':level})
  for band in bands:
   poly=rectangle(band['u0']-.000001,q0-.01,band['u1']+.000001,q1+.01);top=[0.,-f['pitch'],(C+band['height'])/f['W'][1]];cuts.append(prism(poly,[0.,0.,140.],top).transform(np.column_stack([B,np.zeros(3)]).tolist()))
  tool=m.Manifold.batch_boolean(cuts,m.OpType.Add);finished=wood-tool;qq,finished,rr=closed_roof_record(finished);GP[pid]={**q,**qq,'barrier_seat_receiver_parts':sorted(hosts),'barrier_seat_scope':'NEWGPbottomedgeonly: conservativeopenstraightsteppedstockcuts in1/8in tangentbands,1milheightbound. FinishGPsupportedbyitsretainedwallanchors; no roofbearingcapacityclaimed. Originaltimbers/ROsunchanged.','selected_bottom_cut_profile':bands,'boundary_receipt':rr};tools[pid]=pack(tool);toolreceipts.append({'host':pid,'source_layers':sorted(hosts),'selected_tangent_profile_grid_in':.125,'selected_extra_roofnormal_fit_clearance_in':.0001,'selected_height_upper_bound_quantum_in':.001,'raw_status':rr['status'],'removed_in3':max(0.,(wood-finished).volume()),'minimum_roof_normal_height_in':min(b['height'] for b in bands),'maximum_roof_normal_height_in':max(b['height'] for b in bands)});print('GP_SEAT',pid,rr['status'],'bands',len(bands),flush=True)
 current=Path('/workspace/sites/octagonal-timberframe-building/src/model-data.json');context={q['id']:q for q in read(current)['parts'] if q.get('triangles') and q['id']!='PLY' and(q.get('is_timber') or q.get('is_fastener'))};patch=read(D/'porch-roof-support-candidate/porch-support-patch.json');context.update(patch['add_parts']);context.update(patch['receiver_readback_snapshots_for_local_proof_only']);context.update(patch['add_fasteners']);context.update(patch['replace_fasteners']);context.update(read(D/'roof-sheathing-curb-candidate/roof-blocking-candidate-patch.json')['add_parts']);context.update(boxwood);context.update(GP)
 for fn in ['roof-sheathing-curb-candidate/roof-sheathing-parts.json','porch-roof-support-candidate/revised-porch-decks.json','porch-flashing-substrate-candidate/parts.json','physical-closure-candidate/porch-eave-fascia-final.json.gz','physical-closure-candidate/main-eave-wood-raw-parts.json.gz','physical-closure-candidate/physical-eave-seals.json.gz']:
  a=read(D/fn);qs=list(a['add_parts'].values()) if 'add_parts' in a else a['parts'];qs=list(qs.values()) if isinstance(qs,dict) else qs;context.update({q['id']:q for q in qs})
 context.update({q['id']:q for q in drips+saddles});context.update(layers);solids={pid:shape(q) for pid,q in context.items()};grid=Grid();pairs=[];checks=0
 for pid,ss in solids.items():
  for mid in grid.query(bounds(ss)):
   if pid not in layers and mid not in layers and pid not in GP and mid not in GP:continue
   v=max(0.,(ss^solids[mid]).volume());checks+=1
   if v>TOL:pairs.append({'a':pid,'b':mid,'overlap_in3':v})
  grid.add(pid,ss)
 dump(OUT/'new-GPwall-seat-tools.json.gz',{'cutting_tools_by_host':tools,'receipts':toolreceipts,'scope':'FreshNEWGPwallseatcuts only; downwardsweepguaranteesopenbottomseats, notblindfilm-shapedpockets. PreserveoriginalC/CC/RandallwindowROs.'});dump(OUT/'new-GPwall-readback-reference.json.gz',{'parts':GP});dump(OUT/'composition-report.json',{'status':'MAIN_SA_UPTURN_GP_PHYSICAL_PASS' if not pairs else'BLOCKED','main_porch_SA':len(main),'upturns_and_corner_patches':len(up),'main_porch_starters':len(starters),'context':len(solids),'checks':checks,'intersections':pairs,'GP_seat_receipts':toolreceipts,'source_main_SA_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_new_GP_sha256':hashlib.sha256(boxfile.read_bytes()).hexdigest(),'source_primary_sha256':hashlib.sha256(current.read_bytes()).hexdigest(),'scope':['ActualfixedstockSA/publishedproduct, finitefieldbendnormalgaugeapproximationexplicit.','OnlyNEWGPwallbottomseatcuts; originaltimbers/jointsarefixed.','Futuremat/cedar/actualCuvalleyandcounterflashingcompositionseparate. No weather/capacitycertificate.']});print('DONE',len(layers),'pairs',len(pairs),'checks',checks,flush=True)
if __name__=='__main__':run()
