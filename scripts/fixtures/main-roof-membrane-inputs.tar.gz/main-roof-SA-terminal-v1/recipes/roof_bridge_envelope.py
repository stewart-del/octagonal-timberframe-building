"""Conservative gentle fieldformed-sheet envelope above actual lap terrain.
Gridnodes are >= all actualsupport anywhere in every incidentcell. Thus
lineartriangles cannot cut through a lap between samples. Fixedproduct
thickness and blank dimensions remain explicit; fieldbendprofile custom.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps')]
from roof_heightfield_sheet import *
from roof_heightfield_boundary import boundary,refined_sheet
from shapely.geometry import box

def gently_bridged_sheet(domain,supports,thickness=.027,grid_in=1.,perimeter_heel_width_in=0.,heel_region=None,heel_height_in=None,top_options=None,height_quantum_in=None):
 terrain=[{'polygon':domain,'plane':np.array([0.,0.,0.])}]
 for support in supports:
  for face in top_faces(support,**(top_options or {})):
   clipped=face['polygon'].intersection(domain)
   if not clipped.is_empty and clipped.area>1e-10:terrain.append({**face,'polygon':clipped})
 raw_patch_count=len(terrain);grouped={}
 for patch in terrain:
  key=tuple(np.round(patch['plane'],8));grouped.setdefault(key,[]).append(patch['polygon'])
 terrain=[{'polygon':unary_union(polys),'plane':np.asarray(key)} for key,polys in grouped.items()]
 heel=max(height(q['plane'],p) for q in terrain for poly in components(q['polygon']) for p in np.asarray(poly.exterior.coords))
 if heel_height_in is not None:heel=max(heel,float(heel_height_in))
 if heel_region is not None:terrain.append({'polygon':heel_region.intersection(domain),'plane':np.array([0.,0.,heel])})
 if perimeter_heel_width_in>0:terrain.append({'polygon':domain.difference(domain.buffer(-perimeter_heel_width_in,join_style='mitre')),'plane':np.array([0.,0.,heel])})
 lo,sm,hi,sx=domain.bounds;us=np.arange(math.floor(lo/grid_in)*grid_in,math.ceil(hi/grid_in)*grid_in+grid_in/2,grid_in);vs=np.arange(math.floor(sm/grid_in)*grid_in,math.ceil(sx/grid_in)*grid_in+grid_in/2,grid_in);nodes={};active=[];cert=[]
 for i in range(len(us)-1):
  for j in range(len(vs)-1):
   cell=domain.intersection(box(us[i],vs[j],us[i+1],vs[j+1]))
   if cell.is_empty or cell.area<1e-10:continue
   heights=[]
   for c in terrain:
    clip=c['polygon'].intersection(cell)
    for pp in components(clip):
     if pp.is_empty or pp.area<1e-12:continue
     heights += [height(c['plane'],p) for p in np.asarray(pp.exterior.coords)]
   ceiling=max(heights) if heights else 0.
   if height_quantum_in is not None:ceiling=math.ceil((ceiling+1e-9)/height_quantum_in)*height_quantum_in
   ceiling+=1e-6;active.append((i,j,cell,ceiling));cert.append({'i':i,'j':j,'maximum_actual_support_bound_in':ceiling})
   for node in [(i,j),(i+1,j),(i+1,j+1),(i,j+1)]:nodes[node]=max(nodes.get(node,-1e20),ceiling)
 cells=[];slope=0.;maxbridge=0.
 for i,j,cell,ceiling in active:
  corners=[(i,j),(i+1,j),(i+1,j+1),(i,j+1)]
  for indices in [(0,1,2),(0,2,3)]:
   xy=np.array([[us[corners[k][0]],vs[corners[k][1]]] for k in indices]);zz=np.array([nodes[corners[k]] for k in indices]);plane=np.linalg.solve(np.column_stack([xy,np.ones(3)]),zz);slope=max(slope,float(np.linalg.norm(plane[:2])));region=cell.intersection(Polygon(xy))
   for pp in components(region):
    if pp.is_empty or pp.area<1e-10:continue
    cells.append({'polygon':pp,'bottom':plane,'top':plane+np.array([0,0,thickness])})
    for under in terrain:
     clip=pp.intersection(under['polygon'])
     for cp in components(clip):
      if cp.is_empty or cp.area<1e-12:continue
      maxbridge=max(maxbridge,max(height(plane-under['plane'],p) for p in np.asarray(cp.exterior.coords)))
 grouped_cells={}
 for cell in cells:
  key=tuple(np.round(np.r_[cell['bottom'],cell['top']],9));grouped_cells.setdefault(key,[]).append(cell['polygon'])
 cells=[{'polygon':p,'bottom':np.asarray(key[:3]),'top':np.asarray(key[3:])} for key,polys in grouped_cells.items() for p in components(set_precision(unary_union(polys),1e-6)) if p.area>1e-10]
 try:s=refined_sheet(cells,[])
 except (AssertionError,ValueError):s=m.Manifold.batch_boolean([prism(c['polygon'],c['bottom'],c['top']) for c in cells],m.OpType.Add)
 return s,{'grid_in':grid_in,'selected_height_bound_quantum_in':height_quantum_in,'formed_perimeter_heel_above_deck_in':heel,'formed_perimeter_heel_width_in':perimeter_heel_width_in,'raw_actual_support_patches':raw_patch_count,'terrain_cells':len(terrain),'mesh_cells':len(cells),'conservative_maximum_local_bridge_bound_in':maxbridge,'maximum_transition_slope':slope,'normal_thickness_approximation_fraction':1-1/math.sqrt(1+slope*slope),'scope':'Explicitgentlefieldformedgrosssheet envelopebridges membrane laps, notfactorybendCAD/capacityapproval. Stocknormalgauge retainedasroof-normalenvelope; tinytransitionnormalgauge difference quantified.'}
