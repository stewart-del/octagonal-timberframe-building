"""External full-roof rigid cedar/nail geometry candidate, inches internally.

No repository writes. Stock profile is explicit, factory details not invented.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent
sys.path[:0]=[str(D/'python-deps'),str(D)]
import argparse,collections,copy,gzip,hashlib,json,math,time
import numpy as np
import manifold3d as m
from scipy.optimize import minimize_scalar
from scipy.spatial import ConvexHull
from shapely.geometry import Polygon,MultiPolygon,LineString,Point
from shapely.ops import unary_union
from cupola_candidate import native_solid,I,amount
from cedar_overlap_prototype import clip_x

OUT=D/'whole-roof-cedar';L=18.;BUTT=.45;TIP=.0625;EXPOSE=5.5;GAP=.25;PLY=.703;BASE=.025+.285;TOL=1e-6
UP=np.array([0.,1.,0.]);TA=math.tan(math.pi/8);C0=164.20759220056127;PMAIN=1/3/math.cos(math.pi/8)

def load(path):return json.loads(Path(path).read_text())
def dump(path,value):
 text=json.dumps(value,separators=(',',':'),default=lambda x:x.item() if hasattr(x,'item') else x)
 if str(path).endswith('.gz'):
  with gzip.open(path,'wt') as f:f.write(text)
 else:Path(path).write_text(text+'\n')
def unit(v):v=np.asarray(v,float);return v/np.linalg.norm(v)
def keep_le(s,n,c):n=np.asarray(n,float);z=np.linalg.norm(n);return s.trim_by_plane((-n/z).tolist(),-c/z)
def pack(s):
 a=s.to_mesh64();return {'vertices':(np.asarray(a.vert_properties)[:,:3]*I).tolist(),'triangles':np.asarray(a.tri_verts).tolist(),'volume_m3':s.volume()*I**3}
def vertices(s):return np.asarray(s.to_mesh64().vert_properties)[:,:3]
def shape(record):return native_solid(record).scale([1/I,1/I,1/I])
def bounds(s):return np.array(s.bounding_box())
def bbox_overlap(a,b):return np.all(a[:3]<=b[3:]+1e-8) and np.all(b[:3]<=a[3:]+1e-8)
def poly_column(poly):
 if poly.is_empty:return m.Manifold()
 polygons=list(poly.geoms) if isinstance(poly,MultiPolygon) else [poly];pieces=[]
 for q in polygons:
  contours=[np.array(q.exterior.coords)[:-1].tolist()]+[np.array(r.coords)[:-1].tolist() for r in q.interiors]
  pieces.append(m.CrossSection(contours,m.FillRule.EvenOdd).extrude(600).transform([[1,0,0,0],[0,0,1,-100],[0,1,0,0]]))
 return m.Manifold.batch_boolean(pieces,m.OpType.Add)
def polyplan(v):return Polygon(np.asarray(v)[:,[0,2]]).convex_hull
def frame_main(k):
 a=-(k+.5)*math.pi/4;n=np.array([math.cos(a),0.,math.sin(a)]);u=np.array([-n[2],0.,n[0]]);g=math.sqrt(1+PMAIN**2);w=(UP+PMAIN*n)/g;s=(-n+PMAIN*UP)/g;q=200*math.cos(math.pi/8);o=n*q+UP*(C0-PMAIN*q)+PLY*w
 return {'id':f'MAIN{k}','face':k,'O':o,'U':u,'S':s,'W':w,'N':n,'pitch':PMAIN,'gamma':g,'qout':q,'height':(q-42)*g,'overhang':1.5}
def quad(start,b,theta):
 d=np.array([math.cos(theta),-math.sin(theta)]);n=np.array([math.sin(theta),math.cos(theta)]);p=np.array([start,b]);return np.array([p,p+L*d,p+L*d+TIP*n,p+BUTT*n])
def supported(start,prior):
 def height(theta):
  xmax=start+L*math.cos(theta);pts=[np.array([start,BASE]),np.array([xmax,BASE])]
  for old in prior:pts.extend(clip_x(old,start,xmax))
  return max(p[1]+math.tan(theta)*(p[0]-start) for p in pts)
 def objective(theta):return height(theta)-L/2*math.sin(theta)
 aa=np.linspace(0,.13,27);k=min(range(len(aa)),key=lambda i:objective(aa[i]));fit=minimize_scalar(objective,bounds=(aa[max(0,k-1)],aa[min(len(aa)-1,k+1)]),method='bounded',options={'xatol':1e-12});theta=float(fit.x);return quad(start,height(theta)+1e-9,theta),theta
def stock_wedge(f,u0,u1,profile):
 return m.Manifold.hull_points([f['O']+f['U']*u+f['S']*q+f['W']*z for u in [u0,u1] for q,z in profile])
def nail_line(f,profile,theta,u0,u1,station=7.):
 d=np.array([math.cos(theta),-math.sin(theta)]);n=np.array([math.sin(theta),math.cos(theta)]);p=profile[0]+station*d+(BUTT+(TIP-BUTT)*station/L)*n
 base=f['O']+f['S']*p[0]+f['W']*p[1];a=base+f['U']*u0;b=base+f['U']*u1
 inter=f['region'].intersection(LineString([a[[0,2]],b[[0,2]]]))
 lines=list(inter.geoms) if hasattr(inter,'geoms') else [inter];valid=[]
 for line in lines:
  if line.is_empty or line.geom_type!='LineString':continue
  us=[float(np.dot(np.array([x,base[1],z])-base,f['U'])) for x,z in line.coords];lo,hi=max(u0,min(us)),min(u1,max(us))
  if hi-lo>=2.0:valid.append((hi-lo,lo,hi))
 if not valid:return None
 _,lo,hi=max(valid);normal=math.sin(theta+math.atan((BUTT-TIP)/L))*f['S']+math.cos(theta+math.atan((BUTT-TIP)/L))*f['W']
 return {'base':base,'normal':normal,'cross':f['U'],'us':[lo+.75,hi-.75],'station':station,'actual_width_at_nails':hi-lo}

class Grid:
 def __init__(self,cell=20):self.cell=cell;self.bins=collections.defaultdict(set);self.box={}
 def keys(self,b):
  x0,z0=np.floor(b[[0,2]]/self.cell).astype(int);x1,z1=np.floor(b[[3,5]]/self.cell).astype(int)
  return [(i,j) for i in range(x0,x1+1) for j in range(z0,z1+1)]
 def add(self,pid,s):
  b=bounds(s);self.box[pid]=b
  for key in self.keys(b):self.bins[key].add(pid)
 def query(self,b):return {pid for key in self.keys(b) for pid in self.bins.get(key,[]) if bbox_overlap(b,self.box[pid])}

def make_faces(deck_parts,reliefs,porch):
 faces=[frame_main(k) for k in range(8)];O=np.array(porch['origin'])/I;U=np.array(porch['tangent']);N=np.array(porch['outward']);h=porch['roof']['halfWidthM']/I;front=porch['roof']['frontZ_M']/I;high=(porch['roof']['ridgeRoofTopY_M']-.024)/I;g=math.sqrt(1+1/9);mainlocal=C0-PMAIN*float(O@N)
 # The real fitted porch rafter tops and main common-J planes define this
 # junction. Columns partition the cedar faces without positive volume.
 def zjoin(x):return (mainlocal-high+abs(x)/3)/PMAIN
 pp=[]
 for side in [-1,1]:
  x0,x1=sorted([side*h,0]);points=[O+U*x0+N*zjoin(x0),O+U*x1+N*zjoin(x1),O+U*x1+N*front,O+U*x0+N*front];region=polyplan(points);pp.append(region)
  w=(UP+side*U/3)/g;s=(-side*U+UP/3)/g;origin=O+side*U*h+UP*(high-h/3)+PLY*w
  faces.append({'id':'PORCH'+('L' if side<0 else 'R'),'face':8+(side>0),'O':origin,'U':N,'S':s,'W':w,'N':side*U,'pitch':1/3,'gamma':g,'height':h*g,'overhang':0.,'region':region,'porch_side':side,'porch_ridge_origin':O+UP*high,'front':front,'zjoin_center':zjoin(0),'porch_basis':{'O':O,'U':U,'N':N,'high':high}})
 valley_lines=[LineString([(O+N*zjoin(0))[[0,2]],(O+side*U*h+N*zjoin(side*h))[[0,2]]]) for side in [-1,1]]
 valley_opening=unary_union([line.buffer(2.,cap_style='square',join_style='mitre') for line in valley_lines]);porch_union=unary_union(pp)
 for f in faces[:8]:
  n,u=f['N'],f['U'];q0=42;q1=f['qout']+1.5/f['gamma'];points=[n*q0-u*q0*TA,n*q1-u*q1*TA,n*q1+u*q1*TA,n*q0+u*q0*TA];region=polyplan(points)
  for r in reliefs:
   if r['face']==f['face']:
    for poly in r['relief_top_polygons_m']:region=region.difference(polyplan(np.asarray(poly)/I))
  if f['face']==2:region=region.difference(porch_union).difference(valley_opening)
  f['region']=region
 for f in faces:
  f['deck_region']=f['region'];f['deck_column']=poly_column(f['region'])
  if f['id'].startswith('PORCH'):f['region']=f['region'].difference(valley_opening)
  f['column']=poly_column(f['region']);f['valley_lines']=valley_lines
 return faces

def make_porch_decks(faces):
 result=[]
 for f in faces[8:]:
  # Split actual porch deck at <=47.875in transverse widths and <=95.875in
  # ridge runs, keeping physical1/8in joints. Structural edge support is
  # recorded separately and not asserted by this clipping operation.
  coords=[]
  for x,z in f['deck_region'].exterior.coords:
   p=np.array([x,0,z]);coords.append([float((p-f['O'])@f['U']),float((p-f['O'])@f['S'])])
  us=np.array(coords)[:,0];lo,hi=float(us.min()),float(us.max());smax=f['height'];j=0
  for u0 in np.arange(math.floor(lo/96)*96,hi,96):
   for s0 in np.arange(0,smax,48):
    q=[f['O']+f['U']*u+f['S']*s+f['W']*z for u in [max(lo,u0+.0625),min(hi,u0+95.9375)] for s in [max(0,s0+.0625),min(smax,s0+47.9375)] for z in [-PLY,0.]]
    p=m.Manifold.hull_points(q)^f['deck_column']
    if p.volume()>.001:
     result.append({'id':f['id']+f'-DECK-{j}','solid':p,'face':f['id'],'metadata':{'roof':f['id'],'thickness_in':PLY,'source':'Actual fitted porch rafter-top plane; proposed panel cuts, support/fastening unqualified.'}});j+=1
 return result

def make_field(faces):
 records=[];solids={};nails=[];problems=[];omitted=[];field_grid=Grid();record_by_id={}
 for f in faces:
  starts=[-f['overhang']];end=f['height']-9.;starts+=list(np.arange(-f['overhang'],end+1e-8,EXPOSE))
  if end-starts[-1]>.25:starts.append(end)
  profiles=[]
  for course,start in enumerate(starts):
   if course==0:profile=quad(start,BASE,0.);theta=0.
   else:profile,theta=supported(start,profiles)
   profiles.append(profile);coords=np.array(list(f['region'].exterior.coords)) if isinstance(f['region'],Polygon) else np.vstack([np.array(q.exterior.coords) for q in f['region'].geoms]);uu=(np.column_stack([coords[:,0],np.zeros(len(coords)),coords[:,1]])-f['O'])@f['U'];lo,hi=float(uu.min())-2,float(uu.max())+2;shift=(course%3)*(6.25/3)
   intervals=[[x,x+6.] for x in np.arange(math.floor((lo-shift)/6.25)*6.25+shift,hi,6.25)];live=[]
   for a,b in intervals:
    p=stock_wedge(f,a,b,profile)^f['column']
    if p.volume()>1e-7:live.append([a,b,p])
   # Merge a narrow boundary offcut into an adjacent wider selected stock
   # shingle before installation, rather than retaining unsecured slivers.
   changed=True
   while changed:
    changed=False
    for i,(a,b,p) in enumerate(live):
     if nail_line(f,profile,theta,a,b,9.5 if course==0 else 7.) is not None:continue
     candidates=[j for j in [i-1,i+1] if 0<=j<len(live) and max(b,live[j][1])-min(a,live[j][0])<=14.]
     if not candidates:continue
     # Prefer the neighboring stock that actually creates a two-nail line.
     # At a raised/diagonal porch cut, the opposite head-only fragment can
     # have a slightly narrower bounding span yet remain unfastenable.
     def merge_rank(j):
      aa=min(a,live[j][0]);bb=max(b,live[j][1]);line=nail_line(f,profile,theta,aa,bb,9.5 if course==0 else 7.)
      return (line is None,bb-aa)
     j=min(candidates,key=merge_rank);aa=min(a,live[j][0]);bb=max(b,live[j][1]);new=stock_wedge(f,aa,bb,profile)^f['column'];k=min(i,j);live[k]=[aa,bb,new];live.pop(max(i,j));changed=True;break
   for index,(a,b,p) in enumerate(live):
    pid=f"CEDAR-{f['id']}-C{course:02d}-S{index:03d}";station=9.5 if course==0 else 7.;nl=nail_line(f,profile,theta,a,b,station)
    if nl is None:
     # A diagonal valley can leave a head-only offcut, or a tiny exposed
     # fragment inside the4–8in open metal valley. Such stock is not installed
     # as an unsecured shingle. Record every omission and its actual exposed
     # extent, and require the real11in-per-side valley metal below it.
     exposed=keep_le(p,f['S'],float(f['S']@f['O']+start+EXPOSE));v=vertices(exposed) if not exposed.is_empty() and exposed.volume()>1e-9 else np.empty((0,3));dist=max([min(line.distance(Point(q[[0,2]])) for line in f['valley_lines']) for q in v] or [0.]);inside_valley=f['id']=='MAIN2' or f['id'].startswith('PORCH')
     omitted.append({'id':pid,'stock_width_in':b-a,'omitted_in3':p.volume(),'has_exposed_fragment':len(v)>0,'exposed_max_distance_to_valley_centerline_in':dist,'reason':'Uninstalled valley-boundary stock offcut; real continuous metal valley covers any exposed fragment.'})
     if not inside_valley or dist>4.+1e-6:problems.append({'id':pid,'reason':'Unnailable retained piece extends beyond permitted open valley coverage.','distance_in':dist})
     continue
    seating=0.;support_kind='mat_envelope'
    if course>0:
     prior=[solids[mid] for mid in field_grid.query(bounds(p)+np.array([-2.,-2.,-2.,2.,2.,2.])) if record_by_id[mid]['roof']==f['id'] and record_by_id[mid]['course']<course];mat_gap=float(np.min((vertices(p)-f['O'])@f['W'])-BASE);wood_gap=min([s.min_gap(p,.1) for s in prior] or[.1]);collision=any(max(0.,(old^p).volume())>TOL for old in prior)
     if collision or(mat_gap>1e-6 and wood_gap>1e-6):
      normal=math.sin(theta)*f['S']+math.cos(theta)*f['W'];d0=float(normal@(f['O']+f['S']*profile[0,0]+f['W']*profile[0,1]));v=vertices(p);bottom=v[np.abs(v@normal-d0)<1e-7];xy=np.column_stack([bottom@f['S'],bottom@f['U']]);hull=xy[ConvexHull(xy).vertices];required=BASE-float(np.min((bottom-f['O'])@f['W']))
      for old in prior:
       clip=old
       for aa,bb in zip(hull,np.roll(hull,-1,axis=0)):
        edge=bb-aa;n2=np.array([-edge[1],edge[0]]);nn=n2[0]*f['S']+n2[1]*f['U'];cc=float(n2@aa);ll=np.linalg.norm(nn);clip=clip.trim_by_plane((nn/ll).tolist(),cc/ll)
        if clip.is_empty():break
       if not clip.is_empty():required=max(required,float(np.max(vertices(clip)@normal-d0)/(normal@f['W'])))
      seating=required+1e-8;p=p.translate((seating*f['W']).tolist())
      if prior and min(s.min_gap(p,.1) for s in prior)<=1e-6:support_kind='actual_lower_course_wood'
      else:support_kind='mat_envelope_after_actual_boundary_fit'
     else:support_kind='actual_lower_course_wood' if wood_gap<=1e-6 else'mat_envelope_actual_contact'
    # Preserve actual final boundary cuts after rigid seating translation.
    p=p^f['column']
    piece_profile=profile.copy();piece_profile[:,1]+=seating;nl=nail_line(f,piece_profile,theta,a,b,station);solids[pid]=p
    rec={'id':pid,'kind':'field_shingle','roof':f['id'],'course':course,'course_butt_station_in':start,'stock':{'length_in':L,'selected_width_in':b-a,'butt_in':BUTT,'assumed_tip_in':TIP,'lower_profile_in':piece_profile.tolist(),'tilt_rad':theta},'selected_width_scope':'Random-width procurement/layout choice; allNo1edgegrain, nofixed-widthmanufacturerSKU implied.','rigid_seating_translation_in':(seating*f['W']).tolist(),'support_kind':support_kind,'actual_mat_envelope_gap_in':float(np.min((vertices(p)-f['O'])@f['W'])-BASE),'removal_normal':f['W'].tolist(),'nail_ids':[]};records.append(rec);record_by_id[pid]=rec;field_grid.add(pid,p)
    for ni,u in enumerate(nl['us']):
     nid=pid+f'-N{ni+1}';rec['nail_ids'].append(nid);nails.append({'id':nid,'owner':pid,'role':'field','sku':'T7SN7B','length_in':2.25,'diameter_in':.092,'head_diameter_in':7/32,'assumed_head_height_in':.035,'head_in':(nl['base']+nl['cross']*u).tolist(),'outward_normal':nl['normal'].tolist(),'course':course,'roof':f['id'],'nail_station_from_butt_in':station,'starter_nail_scope':'Buried innerstarter row9.5in staggers actual hardware; regular exposed courses remain7in.' if course==0 else None,'actual_retained_width_at_nail_line_in':nl['actual_width_at_nails']})
  print('FIELD',f['id'],len([r for r in records if r['roof']==f['id']]),'issues',len(problems),flush=True)
 dump(OUT/'uninstalled-valley-offcuts.json',{'scope':'Not installed cedar, not counted as pieces or nails; explicit metal valley coverage required.','offcuts':omitted})
 return records,solids,nails,problems

def cap_pair(origin,V,U,W,beta,start,theta,h,parity):
 def leaf(side,c0,c1):
  # Rotate the WHOLE two-leaf cap about its transverse axis. Both leaves
  # share one true longitudinal ridge direction; per-face independent tilt
  # would make their ridge edges diverge and create an artificial rising
  # stack, especially at the steeper porch dihedral.
  along=math.cos(theta)*V-math.sin(theta)*W;bisector=math.sin(theta)*V+math.cos(theta)*W;cross=side*math.cos(beta)*U-math.sin(beta)*bisector;normal=side*math.sin(beta)*U+math.cos(beta)*bisector;o=origin+start*V+h*W
  p=m.Manifold.hull_points([o+cross*u+along*v+normal*t for u in [c0,c1] for v,t in [(0,0),(L,0),(L,TIP),(0,BUTT)]])
  return p,{'origin':o,'along':along,'cross':cross,'normal':normal,'bottom_normal':normal,'side':side,'theta':theta,'start':start}
 side=1 if parity%2==0 else -1;a,fa=leaf(side,-.25,4.5);b,fb=leaf(-side,0,4.5);return [(a,fa),(b-a,fb)]

def fit_cap_pair(origin,V,U,W,beta,start,theta,parity,old,end,cap_column=None):
 pair=cap_pair(origin,V,U,W,beta,start,theta,0.,parity);pair=[(keep_le(s,V,float(V@origin+end)),frame) for s,frame in pair]
 if cap_column is not None:pair=[(s^cap_column,frame) for s,frame in pair]
 height=BASE/math.cos(beta)
 for leaf,frame in pair:
  n=frame['normal'];constant=float(n@frame['origin']);v=vertices(leaf);bottom=v[np.abs(v@n-constant)<1e-7]
  projected=np.column_stack([bottom@V,bottom@U]);hull=projected[ConvexHull(projected).vertices]
  basebox=bounds(leaf);basebox[1]-=10;basebox[4]+=10
  for s in old:
   if not bbox_overlap(basebox,bounds(s)):continue
   clip=s
   for a,b in zip(hull,np.roll(hull,-1,axis=0)):
    edge=b-a;n2=np.array([-edge[1],edge[0]]);nn=n2[0]*V+n2[1]*U;c=float(n2@a);length=np.linalg.norm(nn);clip=clip.trim_by_plane((nn/length).tolist(),c/length)
    if clip.is_empty():break
   if clip.is_empty():continue
   height=max(height,float(np.max(vertices(clip)@n-constant)/(n@W)))
 placed=[]
 for s,frame in pair:
  frame=copy.deepcopy(frame);frame['origin']=frame['origin']+(height+1e-8)*W;placed.append((s.translate(((height+1e-8)*W).tolist()),frame))
 return placed,height

def make_caps(faces,solids,only_runs=None):
 records=[];nails=[];issues=[];g=Grid()
 for pid,s in solids.items():g.add(pid,s)
 runs=[];beta=math.atan((TA/3)/math.sqrt(1+1/9));gamma=math.sqrt(1+PMAIN**2)
 for k in range(8):
  r=np.array([math.cos(k*math.pi/4),0.,-math.sin(k*math.pi/4)]);U=np.array([math.sin(k*math.pi/4),0.,math.cos(k*math.pi/4)]);V=unit(-r+UP/3);W=unit(UP+r/3);r0=200+1.5/math.sqrt(1+PMAIN**2)/math.cos(math.pi/8);o=r*r0+UP*(C0+PLY*gamma-r0/3);length=(r0-47)*math.sqrt(1+1/9);runs.append({'id':f'HIP{k}','O':o,'V':V,'U':U,'W':W,'beta':beta,'length':length,'termination':'Ends at radial47in before protected collar; real flashing saddle closes termination.'})
 f=faces[8];b=f['porch_basis'];origin=b['O']+b['N']*f['front']+UP*(b['high']+PLY*math.sqrt(1+1/9));runs.append({'id':'PORCH-RIDGE','O':origin,'V':-b['N'],'U':b['U'],'W':UP,'beta':math.atan(1/3),'length':f['front']-f['zjoin_center']-2,'termination':'Stops2in before geometric main/porch deck junction; valley/head flashing required.'})
 for run in runs:
  if only_runs is not None and run['id'] not in only_runs:continue
  if run['id'].startswith('HIP') and run['id']!='HIP0':
   k=int(run['id'][3:]);angle=k*math.pi/4;rotation=np.array([[math.cos(angle),0.,math.sin(angle)],[0.,1.,0.],[-math.sin(angle),0.,math.cos(angle)]])
   seedrecords=[r for r in records if r['roof']=='HIP0'];seednails=[n for n in nails if n['roof']=='HIP0']
   for r in seedrecords:
    rr=copy.deepcopy(r);rr['id']=r['id'].replace('HIP0',run['id']);rr['roof']=run['id'];rr['nail_ids']=[x.replace('HIP0',run['id']) for x in r['nail_ids']];rr['removal_normal']=(rotation@np.array(r['removal_normal'])).tolist();rr['support_scope']='Rigid family transfer from actual HIP0 field fit; actual target wood intersections and nail rays checked independently.';s=solids[r['id']].rotate([0,45*k,0]);solids[rr['id']]=s;g.add(rr['id'],s);records.append(rr)
   for n in seednails:
    nn=copy.deepcopy(n);nn['id']=n['id'].replace('HIP0',run['id']);nn['owner']=n['owner'].replace('HIP0',run['id']);nn['roof']=run['id'];nn['head_in']=(rotation@np.array(n['head_in'])).tolist();nn['outward_normal']=(rotation@np.array(n['outward_normal'])).tolist();nails.append(nn)
   print('CAP_FAMILY',run['id'],len(seedrecords),flush=True);continue
  O,V,U,W=run['O'],run['V'],run['U'],run['W'];end=run['length']-10.;starts=[0.,0.]+list(np.arange(EXPOSE,end+1e-8,EXPOSE))
  if end-starts[-1]>.25:starts.append(end)
  prior=[]
  for course,start in enumerate(starts):
   approximate=cap_pair(O,V,U,W,run['beta'],start,.06,2.,course);bb=np.r_[np.min([bounds(p)[:3] for p,_ in approximate],axis=0),np.max([bounds(p)[3:] for p,_ in approximate],axis=0)];bb[1]-=8;bb[4]+=8;old=[solids[pid] for pid in g.query(bb)]
   cap_column=(faces[8]['deck_column']+faces[9]['deck_column']) if run['id']=='PORCH-RIDGE' else None
   def obj(theta):
    pair,h=fit_cap_pair(O,V,U,W,run['beta'],start,theta,course,old,run['length'],cap_column);return h-L/2*math.sin(theta)
   aa=[0.,.025,.05,.075,.10,.125];j=min(range(len(aa)),key=lambda j:obj(aa[j]));fit=minimize_scalar(obj,bounds=(aa[max(0,j-1)],aa[min(len(aa)-1,j+1)]),method='bounded',options={'xatol':1e-5});theta=float(fit.x);pair,h=fit_cap_pair(O,V,U,W,run['beta'],start,theta,course,old,run['length'],cap_column)
   for leafindex,(s,frame) in enumerate(pair):
    # Both leaves are independent site-laid pieces; no unmodeled factory
    # joining staples are asserted. Each leaf has TWO roof nails.
    s=keep_le(s,V,float(V@O+run['length']));pid=f"CEDAR-{run['id']}-C{course:02d}-L{leafindex}";overlaps=[]
    for oldid in g.query(bounds(s)):
     vol=max(0.,(s^solids[oldid]).volume())
     if vol>TOL:overlaps.append({'other':oldid,'volume_in3':vol})
    if overlaps:issues.append({'id':pid,'reason':'Cap overlap with installed actual wood','overlaps':overlaps})
    solids[pid]=s;g.add(pid,s);nids=[];a=math.atan((BUTT-TIP)/L);normal=math.sin(a)*frame['along']+math.cos(a)*frame['normal'];station=7.5
    nail_crosses=([2.25,4.] if run['id']=='PORCH-RIDGE' else[2.,4.]) if course==0 else[1.75 if run['id']=='PORCH-RIDGE' else 1.25,3.5]
    for ni,u in enumerate(nail_crosses):
     nid=pid+f'-N{ni+1}';nids.append(nid);head=frame['origin']+u*frame['cross']+station*frame['along']+(BUTT+(TIP-BUTT)*station/L)*frame['normal'];nails.append({'id':nid,'owner':pid,'role':'cap','sku':'T16SNDB','length_in':3.5,'diameter_in':.120,'head_diameter_in':.25,'assumed_head_height_in':.04,'head_in':head.tolist(),'outward_normal':normal.tolist(),'course':course,'roof':run['id'],'nail_station_from_butt_in':station})
    records.append({'id':pid,'kind':'cap_leaf','roof':run['id'],'course':course,'stock':{'length_in':18.,'width_in':4.75 if leafindex==0 else 4.5,'butt_in':BUTT,'assumed_tip_in':TIP,'theta_rad':theta},'edge_detail':'Alternating quarter-inch cover extension; receiving edge cut exactly to cover leaf. Explicit site-made proposal, not factory profile.','assembly_joining':'Independently roof-nailed leaves; no prejoined factory unit or invisible staple count implied.','nail_ids':nids,'removal_normal':W.tolist(),'cover_leaf_first':leafindex==0,'support_height_in':h,'termination':run['termination']})
   print('CAP',run['id'],course,'h',round(h,4),'theta',round(math.degrees(theta),3),'issues',len(issues),flush=True)
 return records,nails,issues,runs

def nail_shapes(nail):
 n=unit(nail['outward_normal']);a=np.cross(n,np.eye(3)[np.argmin(abs(n))]);a=unit(a);b=np.cross(n,a);head=np.array(nail['head_in']);length=nail['length_in'];hh=nail['assumed_head_height_in'];r=nail['diameter_in']/2;hr=nail['head_diameter_in']/2;tip=.18
 transform=np.column_stack([a,b,n,head-n*length]).tolist()
 shaft=m.Manifold.cylinder(length-hh-tip,r,r,16).translate([0,0,tip]);point=m.Manifold.cylinder(tip,0,r,4);cap=m.Manifold.cylinder(hh,hr,hr,24).translate([0,0,length-hh]);metal=(shaft+point+cap).transform(transform)
 # Explicit0.0001in radial numerical fit clearance; not a factory drilling
 # tolerance. It keeps actual metal and wood occupied solids disjoint while
 # retaining the unchanged1e-6in3 verification threshold.
 cb=.0001;bore=(m.Manifold.cylinder(length+.0002,r+cb,r+cb,16).translate([0,0,-.0001])+m.Manifold.cylinder(hh+.0002,hr+cb,hr+cb,24).translate([0,0,length-hh-.0001])).transform(transform)
 return metal,bore

def ray_intervals(s,head,n,length):
 # Start above the flush head so first and final hits have unambiguous parity.
 start=np.array(head)+n*.1;end=np.array(head)-n*(length+1000.);hits=s.ray_cast(start.tolist(),end.tolist());positions=[]
 for hit in hits:
  d=float(np.dot(np.array(head)-np.array(hit.position),n))
  if not positions or abs(d-positions[-1])>1e-7:positions.append(d)
 return [(max(0.,a),min(length,b)) for a,b in zip(positions[::2],positions[1::2]) if b>0 and a<length]

def nail_and_bore(nails,records,solids,decks,out,framing):
 grid=Grid();allhosts={**solids,**decks,**framing};tools=collections.defaultdict(list);host_nails=collections.defaultdict(list);nailgeo={};issues=[];recby={r['id']:r for r in records};bores=[]
 for pid,s in allhosts.items():grid.add(pid,s)
 for index,nail in enumerate(nails):
  head=np.array(nail['head_in']);n=unit(nail['outward_normal']);length=nail['length_in'];end=head-n*(length+.1);bb=np.r_[np.minimum(head,end)-.15,np.maximum(head,end)+.15];candidates=grid.query(bb);hits=[]
  if nail.get('rays'):hits=nail['rays']
  else:
   for pid in candidates:
    intervals=ray_intervals(allhosts[pid],head,n,length)
    if intervals:hits.append({'id':pid,'intervals_in':intervals,'wood_length_in':sum(b-a for a,b in intervals),'is_deck':pid in decks})
  deckhits=[r for r in hits if r['is_deck']];own=[r for r in hits if r['id']==nail['owner']];full=False
  for r in deckhits:
   # A ray traverses the full sheet only if its exit point precedes the tip.
   if any(b<length-1e-7 and b-a>.69 for a,b in r['intervals_in']):full=True
  minwood=max([r['wood_length_in'] for r in deckhits] or[0.]);passed=bool(own) and bool(deckhits) and (minwood>=.75-1e-7 or full)
  nail['rays']=hits;nail['receivers']=[r['id'] for r in hits];nail['deck_penetration']={'maximum_continuous_deck_wood_in':minwood,'completely_through_actual_sheathing':full,'CSSB_3_4in_OR_through':passed};nail['installed_profile_scope']='Verified nominal length/shank/headdiam; headheight and diamondtip geometry illustrative. Ring pitch/profile not invented.'
  if not passed:issues.append({'id':nail['id'],'owner':nail['owner'],'role':nail['role'],'reason':'No actual owner/deck ray or insufficient full-sheathing traversal','deck_hits':deckhits,'owner_hits':own})
  metal,bore=nail_shapes(nail);nailgeo[nail['id']]=metal
  # Drill every actually intersected wood host, including underlying courses.
  for pid in candidates:
   occupied=max(0.,(bore^allhosts[pid]).volume())
   if occupied>1e-10:tools[pid].append(bore);host_nails[pid].append(nail['id']);bores.append({'nail':nail['id'],'host':pid,'removed_in3':occupied})
  if index%250==0:print('NAILS',index,'of',len(nails),'fail',len(issues),flush=True)
 dump(out/'nails-and-rays.json.gz',{'scope':'Individual nail IDs, actual occupied-wood rays, CSSB through-sheathing alternative; no framing or wind capacity claim.','nails':nails,'issues':issues})
 # Export independently itemized nails as template placements; all metal
 # instances are actual separate solids in the checks, not a package count.
 bores_done={};checks=[]
 for index,(pid,host) in enumerate(allhosts.items()):
  if pid in tools:
   tool=m.Manifold.batch_boolean(tools[pid],m.OpType.Add);result=host-tool;residual=max([max(0.,(result^nailgeo[nid]).volume()) for nid in host_nails[pid]] or[0.]);assert residual<=TOL,(pid,residual);bores_done[pid]=result;checks.append({'id':pid,'bore_count':len(tools[pid]),'removed_in3':host.volume()-result.volume(),'maximum_actual_metal_intersection_in3':residual,'same_subtraction_tool_residual_diagnostic_in3':max(0.,(result^tool).volume())})
  else:bores_done[pid]=host
  if index%250==0:print('BORED',index,'of',len(allhosts),flush=True)
 dump(out/'bore-records.json.gz',{'actual_bores':bores,'host_checks':checks})
 dump(out/'cedar-wood-parts.json.gz',{'scope':'Actual individual installed cedar solids with matching physical nail bores; units worldXYZmeters,Yup.','parts':[{**r,**pack(bores_done[r['id']]),'material':'cedar','is_timber':False,'is_fastener':False} for r in records]})
 dump(out/'roof-decks-with-nail-bores.json.gz',{'scope':'Replacement deck meshes containing cedar nail bores; geometry/support design otherwise as source.','parts':[{'id':pid,**pack(bores_done[pid]),'material':'plywood'} for pid in decks]})
 dump(out/'receiving-framing-with-nail-bores.json.gz',{'scope':'Only actual framing hit by installed roof nails, with matching bore meshes. Compose with exact source geometry before production cavity regeneration; no whole-building certificate.','parts':[{'id':pid,**pack(bores_done[pid]),'material':'wood'} for pid in framing if pid in tools]})
 return issues,checks,bores_done,nailgeo

def run(args):
 start=time.time();OUT.mkdir(exist_ok=True);deckpath=D/'roof-sheathing-candidate/roof-sheathing-parts.json';reliefpath=D/'roof-sheathing-candidate/roof-sheathing-collar-reliefs.json';decksource=load(deckpath);deckparts=decksource['parts'];reliefs=load(reliefpath)['reliefs'];porch=load(OUT/'porch-source.json');faces=make_faces(deckparts,reliefs,porch);porchdecks=make_porch_decks(faces);decks={p['id']:shape(p) for p in deckparts};decks.update({p['id']:p['solid'] for p in porchdecks});dump(OUT/'proposed-porch-decks.json',{'scope':'Actual fitted-rafter plane proposal; rear junction panel support unresolved; not a structural certificate.','parts':[{**p['metadata'],'id':p['id'],**pack(p['solid'])} for p in porchdecks]})
 if args.resume_raw:
  with gzip.open(OUT/'all-raw-wood.json.gz','rt') as f:raw=json.load(f)
  with gzip.open(OUT/('nails-and-rays.json.gz' if args.resume_rays else'all-raw-nails.json.gz'),'rt') as f:nails=json.load(f)['nails']
  records=raw['parts'];solids={p['id']:shape(p) for p in records};problems=raw['issues'];caps=[p for p in records if p['kind']=='cap_leaf'];capnails=[n for n in nails if n['role']=='cap'];runs=set(r['roof'] for r in caps)
 else:
  if args.resume_field:
   with gzip.open(OUT/'field-raw.json.gz','rt') as f:raw=json.load(f)
   records=raw['parts'];solids={p['id']:shape(p) for p in records};nails=raw['nails'];problems=raw['issues']
  else:
   records,solids,nails,problems=make_field(faces);dump(OUT/'field-raw.json.gz',{'parts':[{**r,**pack(solids[r['id']])} for r in records],'nails':nails,'issues':problems})
  if args.field_only:print('FIELD_ONLY',len(records),len(nails),len(problems),flush=True);return
  caps,capnails,capissues,runs=make_caps(faces,solids);records+=caps;nails+=capnails;problems+=capissues;dump(OUT/'all-raw-wood.json.gz',{'parts':[{**r,**pack(solids[r['id']])} for r in records],'issues':problems});dump(OUT/'all-raw-nails.json.gz',{'nails':nails})
 for nail in capnails:nail.update(sku='T20SNDB',length_in=4.,diameter_in=.131,head_diameter_in=.25,procurement_scope='Historical Simpson manufacturer C-F-2017p117 part; current procurement unconfirmed. Fixed7.5in nail station retained.')
 source=load(D/'hip-backing-candidate/frozen-roof-support-model.json');framing={p['id']:shape(p) for p in source['parts'] if p['id'].startswith(('R','J','B')) and p.get('is_timber')}
 finalhip=D/'hip-eave-miter-candidate/combined-backed-eave-R-patch.json'
 if finalhip.exists():framing.update({k:shape(p) for k,p in load(finalhip)['replace_parts'].items()})
 else:framing.update({k:shape(p) for k,p in load(D/'hip-backing-candidate/backed-R-patch.json')['replace_parts'].items()})
 blocksource=D/'roof-sheathing-curb-candidate/roof-blocking-candidate-patch.json';blockparts=load(blocksource)['add_parts'];framing.update({p['id']:shape(p) for p in (blockparts.values() if isinstance(blockparts,dict) else blockparts)})
 framing.update({p['id']:shape(p) for p in porch['framing']})
 # Broad-phase actual-volume check of every overlapping cedar AABB pair.
 grid=Grid();overlaps=[];pairchecks=0
 for pid,s in solids.items():
  for mid in grid.query(bounds(s)):
   pairchecks+=1;v=max(0.,(s^solids[mid]).volume())
   if v>TOL:overlaps.append({'a':pid,'b':mid,'overlap_in3':v})
  grid.add(pid,s)
 print('RAW_WOOD_OVERLAPS',len(overlaps),'pairs',pairchecks,flush=True)
 nailissues,borechecks,finished,nailgeo=nail_and_bore(nails,records,solids,decks,OUT,framing);problems+=nailissues
 # Compact metal template meshes and unique placement/animation records.
 templates={}
 for role in ['field','cap']:
  ref=next(n for n in nails if n['role']==role);at=copy.deepcopy(ref);at['head_in']=[0,0,0];at['outward_normal']=[0,0,1];metal,bore=nail_shapes(at);templates[ref['sku']]={'metal':pack(metal),'bore':pack(bore),'profile_scope':ref['installed_profile_scope']}
 dump(OUT/'nail-geometry-templates.json',templates)
 order=sorted(records,key=lambda r:(r['kind']=='cap_leaf',r['course'],r.get('cover_leaf_first',False)),reverse=True);route=[]
 for r in order:
  route.append({'id':'REMOVE-'+r['id'],'remove_nails_first':r['nail_ids'],'nail_motion':'Translate along each own outward normal by its full length+1in.','wood_id':r['id'],'wood_motion_m':(np.array(r['removal_normal'])*.6).tolist(),'prerequisites':'All higher courses and all caps above field; cap cover leaf before receiving leaf.','certificate_scope':'Dependency-friendly proposed route; complete building continuous replay not performed.'})
 dump(OUT/'removal-route.json.gz',route)
 report={'scope':'External actual main8+porch2 rigid cedar, cap leaves and individual nails; no local-code capacity or full-building assembly certificate.','status':'LOCAL_PASS' if not problems and not overlaps else 'LOCAL_BLOCKED','sources':{str(deckpath):hashlib.sha256(deckpath.read_bytes()).hexdigest(),str(reliefpath):hashlib.sha256(reliefpath.read_bytes()).hexdigest()},'profile':{'stock_length_in':L,'butt_in':BUTT,'assumed_tip_in':TIP,'maximum_field_exposure_in':EXPOSE,'keyway_in':GAP,'plywood_in':PLY,'VaporDry_in':.025,'CedarBreather_in':.285},'field_shingles':sum(r['kind']=='field_shingle' for r in records),'physical_cap_leaves':len(caps),'cap_pair_runs':len(runs),'field_nails':sum(n['role']=='field' for n in nails),'cap_nails':len(capnails),'wood_overlap_pair_checks':pairchecks,'wood_overlaps':overlaps,'issues':problems,'nail_bore_host_checks':len(borechecks),'elapsed_s':time.time()-start,'unresolved':['Porch rear-junction panel bearing and all roof connection/span capacities.','Actual copper/flashing saddle and air-barrier collar integration are separate assets.','No factory cap joining fasteners invented: these are independent site-laid leaves.','Assumed nail head height/point and milltip thickness remain explicit.','Cap/field removal dependency order supplied, full building continuous sweep certification excluded.']};dump(OUT/'whole-roof-cedar-report.json',report);print(report['status'],{k:report[k] for k in ['field_shingles','physical_cap_leaves','field_nails','cap_nails']},flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--field-only',action='store_true');p.add_argument('--resume-field',action='store_true');p.add_argument('--resume-raw',action='store_true');p.add_argument('--resume-rays',action='store_true');args=p.parse_args();run(args)
