"""Two physical hip strips seated over the already-installed valley SA.
Real25in stock; shortfinitebendgrossenvelopes avoid hidden interpenetration.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps')]
from roof_physical_layers import *
from roof_bridge_envelope import gently_bridged_sheet
from roof_heightfield_sheet import top_faces
from closed_roof_envelope import closed_roof_record

def run():
 p=D/'roof-physical-layers-candidate/main-membrane-checkpoint.json.gz';data=read(p);by={q['id']:q for q in data['parts']};initial=read(D/'roof-eave-starter-candidate/parts.json')['parts']+read(D/'roof-edge-flashing-candidate/drip-parts.json')['parts']+[q for q in read(D/'air-boundary-candidate/air-boundary-parts.json.gz')['parts'] if q['id'].startswith('CU-SADDLE-')];underparts=[q for q in by.values() if q['id'] not in ['VDSA-MAIN-HIP-2','VDSA-MAIN-HIP-3']]+initial;prepared=[];maximum=0.;h=2
 for k in [1,2]:
  print('HIP_PREPARE',k,flush=True)
  f=frame_main(k);dom=roof_top_region(by['VDSA-MAIN-HIP-2'],f);dom=unary_union([dom,geotranslate(dom,xoff=.15),geotranslate(dom,xoff=-.15)]);under=[tolocal(shape(q),f) for q in underparts];radial=np.array([0.,0.,-1.]);pts=[]
  for rr in [35.,210.]:
   v=radial*rr;v[1]=(f['O']@f['W']-v@f['W'])/f['W'][1];pts.append(v)
  line=LineString(np.column_stack([(np.asarray(pts)-f['O'])@f['U'],(np.asarray(pts)-f['O'])@f['S']]));heelregion=line.buffer(.75,cap_style='square');prepared.append((f,dom,under,heelregion))
  for ss in under:
   for patch in top_faces(ss,min_cosine=.99999):
    clip=patch['polygon'].intersection(dom)
    for poly in pieces(clip):
     if not poly.is_empty:maximum=max(maximum,max(height(patch['plane'],v) for v in np.asarray(poly.exterior.coords)))
 heel=math.ceil(maximum*1000.)/1000.;print('HIP_HEEL',heel,flush=True);leaves=[];receipts=[]
 for f,dom,under,heelregion in prepared:
  print('HIP_FACE_BUILD',f['id'],'area',dom.area,flush=True)
  ss,r=gently_bridged_sheet(dom,under,.025,grid_in=1.,heel_region=heelregion,heel_height_in=heel,top_options={'min_cosine':.99999},height_quantum_in=.001);leaves.append(toworld(ss,f,fold_hip=2));receipts.append(r);print('HIP_FACE_BUILT',f['id'],len(ss.to_mesh64().tri_verts),flush=True)
 ss=m.Manifold.batch_boolean(leaves,m.OpType.Add);dump(D/'roof-physical-layers-candidate/hip2-finite-raw.json',pack(ss));print('HIP_COMPOSED',len(ss.to_mesh64().tri_verts),len(ss.decompose()),flush=True)
 if '--raw-only' in sys.argv:return
 q,ss,r=closed_roof_record(ss);old=by['VDSA-MAIN-HIP-2'];by[old['id']]={**old,**q,'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier membrane','raw_mesh_status':'PASS','finite_bend_receipts':receipts,'valley_prior_layer_included':True,'profile_scope':'Oneactual25in rip, two12in legs, actualpriorvalley/fieldtops. Finitebendgrossenvelopeandnormalgaugeapproximationexplicit; no factoryradius/adhesion/sitecapacityapproval.'}
 n=frame_main(2)['N'];R=2*np.outer(n,n)-np.eye(3);R[1,:]=[0,1,0];R[:,1]=[0,1,0];qs,mirrored,mr=closed_roof_record(ss.transform(np.column_stack([R,np.zeros(3)]).tolist()));old=by['VDSA-MAIN-HIP-3'];by[old['id']]={**old,**qs,'raw_mesh_status':'PASS','material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier membrane','finite_bend_receipts':receipts,'selected_symmetric_stock_cut_source':'VDSA-MAIN-HIP-2','valley_prior_layer_included':True,'boundary_receipt':mr}
 for rec in by.values():
  if 'VaporDry' in rec.get('material','') and 'membrane' not in rec['material'].lower():rec['material']+=' membrane'
 data['parts']=list(by.values());data['issues']=[];dump(p,data);print('HIP_VALLEY_SEATS_PASS','heel',heel,'count',len(by),flush=True)
if __name__=='__main__':run()
