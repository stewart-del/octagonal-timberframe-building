"""One continuous flexible material over real layer-height steps.
Low-side25mil risers keep equal-height25mil lap steps from becoming two
disconnected pieces touching only along an edge. New geometry, no audit
relaxation. Body upstands may be taller than the ordinary sheet gauge.
"""
import sys
sys.dont_write_bytecode=True
from roof_heightfield_sheet import *
from roof_heightfield_boundary import refined_sheet

def folded_boundary(cells,gauge_z=.025,fold_width_in=.025):
 boundaries=[c['polygon'].boundary for c in cells];refined=[]
 for p in polygonize(unary_union(boundaries)):
  if p.area<1e-10:continue
  rp=p.representative_point();c=next((c for c in cells if c['polygon'].covers(rp)),None)
  if c is not None:refined.append({**c,'polygon':orient(p,sign=1.)})
 edges={};patches=[];extras=[]
 for i,c in enumerate(refined):
  for ring in [c['polygon'].exterior]+list(c['polygon'].interiors):
   v=np.asarray(ring.coords)
   for a,b in zip(v[:-1],v[1:]):
    key=tuple(sorted([tuple(np.round(a,8)),tuple(np.round(b,8))]));edges.setdefault(key,[]).append((i,a,b))
 for key,items in edges.items():
  if len(items)!=2:continue
  (ia,a,b),(ib,_,_)=items;mid=(a+b)/2;ha=height(refined[ia]['bottom'],mid);hb=height(refined[ib]['bottom'],mid)
  if abs(ha-hb)<1e-7:continue
  low,high=(ia,ib) if ha<hb else(ib,ia);_,a,b=next(q for q in items if q[0]==low);d=b-a;normal=np.array([-d[1],d[0]])/np.linalg.norm(d);foot=Polygon([a,b,b+normal*fold_width_in,a+normal*fold_width_in]).intersection(refined[low]['polygon']);upper=refined[high]['bottom']+np.array([0,0,gauge_z])
  for p in components(foot):
   if p.area<1e-10:continue
   patches.append({'polygon':p,'top':upper});extras.append(prism(p,refined[low]['bottom'],upper))
 try:ss=refined_sheet(refined,patches)
 except AssertionError:ss=m.Manifold.batch_boolean([prism(c['polygon'],c['bottom'],c['top']) for c in refined]+extras,m.OpType.Add)
 return ss,{'base_cells':len(refined),'actual_step_risers':len(patches),'selected_riser_horizontal_gauge_in':fold_width_in,'profile_scope':'Explicitflexiblefieldfolds overactualheightsteps. No factorybendradius/weathercapacityclaim.'}
