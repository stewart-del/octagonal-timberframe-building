"""Strict closed single-piece serializer for new roof material envelopes.
Input inches, output meters. Auditor/source geometry/tolerance unchanged.
Every boundary rewrite proves occupied symmetric difference<=1e-6in3.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps'),'/workspace/sites/octagonal-timberframe-building/scripts']
from whole_roof_cedar import pack,shape,I,TOL,np
from audit_cavity_fit import inspect_mesh
from collapse_mesh_debris import collapse_tiny
from regular_boundary_geos import regular_boundary_geos

def outside_surface(s):
 q=pack(s);v=np.asarray(q['vertices']);t=np.asarray(q['triangles']);by={};adj=[set() for _ in t]
 for i,tr in enumerate(t):
  for j in range(3):by.setdefault(tuple(sorted([int(tr[j]),int(tr[(j+1)%3])])),[]).append(i)
 for ids in by.values():
  for i in ids:adj[i].update(ids)
 groups=[];seen=set()
 for i in range(len(t)):
  if i in seen:continue
  todo=[i];g=[];seen.add(i)
  while todo:
   a=todo.pop();g.append(a)
   for b in adj[a]:
    if b not in seen:seen.add(b);todo.append(b)
  O=np.mean(v[np.unique(t[g])],axis=0);p=v[t[g]]-O;vol=float(np.einsum('ij,ij->i',p[:,0],np.cross(p[:,1],p[:,2])).sum()/6);groups.append((vol,g))
 g=max(groups,key=lambda q:q[0])[1];return shape({'vertices':v.tolist(),'triangles':t[g].tolist()})

def closed_roof_record(original):
 failures=[]
 def check(s,method):
  q=pack(s);audit=inspect_mesh(np.asarray(q['vertices']),np.asarray(q['triangles'],np.uint64),require_single=True);delta=max(0.,(s-original).volume())+max(0.,(original-s).volume())
  if audit['status']=='PASS' and delta<=TOL:return q,s,{'status':'PASS','method':method,'occupied_difference_in3':delta,'audit':audit}
  failures.append({'method':method,'failures':audit['failures'],'occupied_difference_in3':delta});return None
 result=check(original,'unchanged')
 if result:return result
 for eps in [1e-9,1e-8,1e-7,1e-6]:
  result=check(original.simplify(eps),'bounded_simplify_'+str(eps))
  if result:return result
 candidates=[('original',original)]
 try:
  q,steps=collapse_tiny(pack(original),maximum_edge_m=.1,max_iterations=1000);s=shape(q);candidates.insert(0,('collinear_collapse_native',s));result=check(s,'collinear_collapse_native')
  if result:return result
 except Exception as e:failures.append({'method':'collinear_collapse','error':str(e)})
 for name,s in list(candidates):
  try:
   result=check(outside_surface(s),name+'+remove_tiny_cavity')
   if result:return result
  except Exception:pass
 for name,s in candidates:
  for tol in [1e-9,1e-10,1e-11]:
   try:n=regular_boundary_geos(s.scale([I]*3),tol=tol).scale([1/I]*3)
   except Exception as e:failures.append({'method':'net_'+str(tol),'error':str(e)});continue
   method=name+'+net_'+str(tol);result=check(n,method)
   if result:return result
   try:
    q,steps=collapse_tiny(pack(n),maximum_edge_m=.1,max_iterations=1000);nn=shape(q);result=check(nn,method+'+collapse')
    if result:return result
    result=check(outside_surface(nn),method+'+collapse+remove_tiny_cavity')
    if result:return result
   except Exception:pass
 raise AssertionError(('RoofEnvelopeBoundaryUnresolved',failures[-8:]))
