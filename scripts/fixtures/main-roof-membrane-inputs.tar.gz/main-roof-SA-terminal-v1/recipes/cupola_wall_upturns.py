"""Eight actual25mil PSA cupola-wall upturns and eight12in-per-side corner patches.
External geometry; original timber and all window openings stay fixed.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps'),'/workspace/sites/octagonal-timberframe-building/scripts']
from roof_physical_layers import *
from roof_heightfield_boundary import refined_sheet
from closed_roof_envelope import closed_roof_record
from shapely.ops import polygonize
import hashlib
OUT=D/'cupola-wall-upturn-candidate';OUT.mkdir(exist_ok=True)
Y=np.array([0.,1.,0.]);R=np.array([[1.,0.,0.],[0.,0.,1.],[0.,1.,0.]])
Q=42.451;H=Q*TA;T=.025

def planpiece(k,q0,q1,t0,t1):
 f=frame_main(k);pts=[]
 for q,t in [(q0,max(t0,-q0*TA)),(q1,max(t0,-q1*TA)),(q1,min(t1,q1*TA)),(q0,min(t1,q0*TA))]:
  p=f['N']*q+f['U']*t;pts.append([p[0],p[2]])
 return Polygon(pts)
def coverage(parent,face):
 if parent==face:return[-H,H]
 if face==(parent-1)%8:return[-H,-H+12.]
 if face==(parent+1)%8:return[H-12.,H]
 return None
def canonical_terrain(support,Rloc):
 from roof_heightfield_sheet import top_faces
 groups={};slopes=[np.array([-frame_main(k)['pitch']*(frame_main(k)['N']@Rloc[:,0]),-frame_main(k)['pitch']*(frame_main(k)['N']@Rloc[:,1])]) for k in range(8)]
 for ss in support.values():
  local=ss.transform(np.column_stack([Rloc.T,np.zeros(3)]).tolist())
  for patch in top_faces(local,min_cosine=.9,min_height=145.,max_height=153.):
   p=patch['polygon'];slope=min(slopes,key=lambda s:np.linalg.norm(s-patch['plane'][:2]))
   if np.linalg.norm(slope-patch['plane'][:2])>.001:continue
   c=max(height(patch['plane'],v)-slope@v for v in np.asarray(p.exterior.coords));c=math.ceil((c+1e-6)*10000.)/10000.;key=tuple([*slope,c]);groups.setdefault(key,[]).append(p)
 terrain=[]
 for key,polys in groups.items():
  for p in pieces(set_precision(unary_union(polys),1e-6)):
   if p.area>1e-8:terrain.append(prism(p,[0,0,140],np.array(key)))
 return terrain

def run():
 src=D/'roof-physical-layers-candidate/main-membrane-checkpoint.json.gz';saved=read(src);layers=[q for q in saved['parts'] if q['id'].startswith('VDSA-MAIN')];saddles=[q for q in read(D/'air-boundary-candidate/air-boundary-parts.json.gz')['parts'] if q['id'].startswith('CU-SADDLE-')];support={q['id']:shape(q) for q in layers+saddles};records=[];stock=[];issues=[];footprints=[]
 for k in range(16):
  body=[];roof=[];segments=[]
  if k<8:layout=[(k,-H,H)];layer=0;pid=f'VDSA-CUPWALL-UPTURN-{k}';blanklength=2*H+.5
  else:
   h=k-8;layout=[(h,H-12.,H),((h-1)%8,-H,-H+12.)];layer=1;pid=f'VDSA-CUPWALL-CORNER-{h}';blanklength=24.5
  for j,lo,hi in layout:
   q0=Q+layer*T;tl=lo if lo>-H+1e-8 else -100;th=hi if hi<H-1e-8 else 100
   body.append(planpiece(j,q0,q0+T,tl,th));roof.append(planpiece(j,q0,q0+4./frame_main(j)['gamma'],tl,th));segments.append({'face':j,'t0_in':lo,'t1_in':hi,'prior_ply_count':layer,'inner_q_in':q0})
  from shapely.affinity import affine_transform
  rf=frame_main(layout[0][0]);Rloc=np.column_stack([rf['U'],rf['N'],Y]);B2=np.array([[rf['U'][0],rf['U'][2]],[rf['N'][0],rf['N'][2]]]);aff=[*B2[0],*B2[1],0.,0.]
  body=set_precision(affine_transform(unary_union(body),aff),1e-6);roof=set_precision(affine_transform(unary_union(roof),aff),1e-6);domain=body.union(roof);from roof_filtered_support import bounded_surface_support
  rawunder=[ss.transform(np.column_stack([Rloc.T,np.zeros(3)]).tolist()) for ss in support.values()];under=bounded_surface_support(rawunder,domain,min_cosine=.00001,zmin=145.,zmax=153.);basecells=[]
  for j,_,_ in layout:
   f=frame_main(j);sector=affine_transform(planpiece(j,0.,100.,-100.,100.),aff);dom=domain.intersection(sector);A=float(f['O']@f['W']/f['W'][1]);base=[-f['pitch']*(f['N']@Rloc[:,0]),-f['pitch']*(f['N']@Rloc[:,1]),A];opts={'min_cosine':.00001,'min_height':145.,'max_height':153.}
   for cell in support_cells(dom,under,base_plane=base,top_options=opts):basecells.append(cell)
  top=max(height(c['plane'],p) for c in basecells for p in np.asarray(c['polygon'].exterior.coords))+12.;cells=[]
  for c in basecells:
   for iswall,reg in [(True,c['polygon'].intersection(body)),(False,c['polygon'].difference(body))]:
    for p in pieces(reg):
     if p.area<1e-10:continue
     cells.append({'polygon':p,'bottom':c['plane'],'top':np.array([0.,0.,top]) if iswall else c['plane']+np.array([0.,0.,T/frame_main(layout[0][0])['W'][1]])})
  grouped={}
  for cell in cells:
   key=tuple(np.round(np.r_[cell['bottom'],cell['top']],8));grouped.setdefault(key,[]).append(cell['polygon'])
  cells=[{'polygon':poly,'bottom':np.asarray(key[:3]),'top':np.asarray(key[3:])} for key,polys in grouped.items() for poly in pieces(set_precision(unary_union(polys),1e-6)) if poly.area>1e-9]
  print('UPTURN_CELLS',k,len(cells),'planeclasses',len(grouped),flush=True)
  from roof_fold_boundary import folded_boundary
  ss,foldreceipt=folded_boundary(cells,T/frame_main(layout[0][0])['W'][1])
  ss=ss.transform(np.column_stack([Rloc,np.zeros(3)]).tolist())
  components=sorted(ss.decompose(),key=lambda q:-q.volume());edgeoffcuts=[]
  if len(components)>1:
   tail=components[1:]
   if all(q.volume()<.05 and bounds(q)[4]<153. for q in tail) and sum(q.volume() for q in tail)<.15:
    edgeoffcuts=[{'volume_in3':q.volume(),**pack(q)} for q in tail];ss=components[0]
  print('UPTURN_BUILT',k,len(ss.to_mesh64().tri_verts),len(ss.decompose()),'edgeoffcuts',len(edgeoffcuts),flush=True)
  dump(OUT/f'debug-raw-{k}.json',pack(ss))
  try:q,ss,receipt=closed_roof_record(ss)
  except AssertionError as e:q=pack(ss);receipt={'status':'FAIL','error':str(e)};issues.append({'id':pid,'reason':'RawBoundary','receipt':receipt})
  records.append({'id':pid,'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier','kind':'cupola_wall_self_adhered_upturn' if k<8 else 'cupola_wall_self_adhered_corner_patch','thickness_in':T,'vertical_upturn_min_in':12.,'roof_leg_min_in':4.,'corner_wrap_each_end_in':12.,'wall_front_apothem_in':Q,'upper_y_in':top,'wall_segment_recipe':segments,'parentStockId':'CUT-'+pid,'raw_mesh_status':receipt['status'],'boundary_receipt':receipt,'physical_step_fold_receipt':foldreceipt,'selected_roofleg_corner_knife_offcuts':edgeoffcuts,'selected_terrain_seat_quantum_in':.0001,'attachment':'Actualselfadheredfilm, fieldroller100%contactwhereauthorizedsubstrate exists. Testclean/dryCu/wood/previousfilmadhesion. No duplicatefictional timberboot atdefaultRbelowdeck.','assembly_prerequisites':[q['id'] for q in layers+saddles]+[r['id'] for r in records],**q});support[pid]=ss;dump(OUT/'parts-in-progress.json.gz',{'parts':records,'issues':issues});stock.append({'id':'CUT-'+pid,'product':'VaporDry SA','raw_roll_in':[57,960],'selected_blank_in':[17.,blanklength],'developed_width_scope':'Atleast12in vertical+4in roofleg plus1in selectedfold/stepallowance; cornerwings retain12in verticalwrap androoflegisnotduplicated.','installed_ids':[pid]});footprints.append({'id':pid,'body_area_in2':body.area,'roof_leg_area_in2':roof.area});print(pid,receipt['status'],len(ss.decompose()),flush=True)
  if '--one' in sys.argv:return
 # Only new GPwall bottom seats are cut, no originalwood source modifications.
 boxwood=read(D/'physical-closure-candidate/cupola-box-wood-raw-parts.json.gz')['add_parts'];tools={};newwalls={};allfilm=m.Manifold.batch_boolean(list(support.values()),m.OpType.Add)
 for pid,rec in boxwood.items():
  if not pid.endswith('-WALL-PLY'):continue
  wood=shape(rec);tool=wood^allfilm
  if tool.is_empty() or tool.volume()<1e-10:continue
  tools[pid]=pack(allfilm^wood);newwalls[pid]={'id':pid,**{k:v for k,v in rec.items() if k not in ['vertices','triangles','volume_m3']},**pack(wood-allfilm)}
 pairs=[];grid=Grid();allshapes={**{q['id']:shape(q) for q in layers+saddles},**{q['id']:shape(q) for q in records}}
 for pid,ss in allshapes.items():
  for mid in grid.query(bounds(ss)):
   if not(pid.startswith('VDSA-CUPWALL') or mid.startswith('VDSA-CUPWALL')):continue
   v=max(0.,(ss^allshapes[mid]).volume())
   if v>TOL:pairs.append({'a':pid,'b':mid,'overlap_in3':v})
  grid.add(pid,ss)
 dump(OUT/'parts.json.gz',{'parts':records});dump(OUT/'new-GPwall-seat-tools.json.gz',{'cutting_tools_by_host':tools,'scope':'ApplyonlytoNEWGPcupolawallparts; exactfilmoccupiedvolumes, originalC/CC/Rjointsunchanged.'});dump(OUT/'new-GPwall-readback-reference.json.gz',{'parts':newwalls});dump(OUT/'stock.json',{'cuts':stock,'parent_roll_width_in':57,'parent_roll_length_in':960});dump(OUT/'report.json',{'status':'UPTURN_GEOMETRY_PASS' if not issues and not pairs else'BLOCKED','source_layer_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'parts':len(records),'issues':issues,'intersections':pairs,'new_GP_hosts':list(tools),'footprints':footprints,'scope':'Actualnewwallupturnenvelopes, stockcuts/cornerwraps andNEWGPonlyseattools. Matmustbutt/reseatoutsidetheseactuallegs. Fullweathercertificate/factoryfoldradius/adhesiontoCu qualificationnotclaimed.'});print('DONE',len(records),'issues',len(issues),'pairs',len(pairs),flush=True)
if __name__=='__main__':run()
