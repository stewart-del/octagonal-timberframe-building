"""External physical AC48 icebarrier and nominal CedarBreather sheet envelopes.
All dimensions inside this recipe are inches. Product widths remain fixed.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps'),'/workspace/sites/octagonal-timberframe-building/scripts']
from whole_roof_cedar import *
from roof_heightfield_sheet import sheet,support_cells,prism,height,regular_boundary_geos
from shapely.geometry.polygon import orient
from shapely.geometry import box
from shapely.affinity import translate as geotranslate
from shapely import set_precision
from audit_cavity_fit import inspect_mesh
from collapse_mesh_debris import collapse_tiny
OUTL=D/'roof-physical-layers-candidate';OUTL.mkdir(exist_ok=True)
TH=.025;CB=.285;TOL=1e-6

def read(p):return json.load(gzip.open(p,'rt')) if str(p).endswith('.gz') else json.load(open(p))
def pieces(g):return [g] if isinstance(g,Polygon) else [p for p in getattr(g,'geoms',[]) if isinstance(p,Polygon)]
def region(v,f):return Polygon(np.column_stack([(np.asarray(v)-f['O'])@f['U'],(np.asarray(v)-f['O'])@f['S']])).convex_hull

def tolocal(s,f):
 R=np.column_stack([f['U'],f['S'],f['W']]);return s.transform(np.column_stack([R.T,-R.T@f['O']]).tolist())
def toworld(s,f,fold_hip=None,fold_ridge=False):
 s=s.transform(np.column_stack([f['U'],f['S'],f['W'],f['O']]).tolist())
 if f['id'].startswith(('MAIN','CUP')):
  k=f['face']
  for h in [k,k+1]:
   a=-h*math.pi/4;n=np.array([-math.sin(a),0.,math.cos(a)])
   if n@f['N']<0:n=-n
   s=s.trim_by_plane(n.tolist(),-.0001 if h==fold_hip else 0.)
 if f['id'].startswith('PORCH'):
  nn=f['porch_side']*f['porch_basis']['U'];s=s.trim_by_plane(nn.tolist(),float(nn@f['porch_basis']['O'])-(.0001 if fold_ridge else 0.))
 return s

def roof_top_region(q,f):
 v=np.asarray(q['vertices'])/I;t=np.asarray(q['triangles']);out=[]
 for tri in t:
  p=v[tri];n=np.cross(p[1]-p[0],p[2]-p[0]);ln=np.linalg.norm(n)
  if ln>1e-12 and n@f['W']/ln>.999999:
   pp=region(p,f)
   if pp.area>1e-12:out.append(pp)
 return unary_union(out)

def run():
 main=read(D/'roof-sheathing-curb-candidate/roof-sheathing-parts.json')['parts'];rel=read(D/'roof-sheathing-curb-candidate/roof-sheathing-collar-reliefs.json')['reliefs'];pd=read(D/'porch-roof-support-candidate/revised-porch-decks.json')['parts'];porch=read(D/'whole-roof-cedar/porch-source.json');cup=read(D/'cupola-copper-candidate/roof-raw-wood.json')['parts'];closures=read(D/'porch-flashing-substrate-candidate/parts.json')['parts'];vf=read(D/'raised-valley-flashing-candidate/interface-frames.json')['frames'];valley=read(D/'raised-valley-flashing-candidate/parts.json')['parts'];faces=make_faces(main,rel,porch);starters=read(D/'roof-eave-starter-candidate/parts.json')['parts'];drips=read(D/'roof-edge-flashing-candidate/drip-parts.json')['parts'];saddles=[q for q in read(D/'air-boundary-candidate/air-boundary-parts.json.gz')['parts'] if q['id'].startswith('CU-SADDLE-')];interface=read(D/'porch-roof-support-candidate/porch-support-interface-polygons.json');substrate=read(D/'porch-flashing-substrate-candidate/interface.json')['frames']
 domains={};stock=[];records=[];solids={};issues=[];receipts=[];foldreceipts=[];lapreceipts=[];matreceipts=[];initial={q['id']:shape(q) for q in starters+drips+saddles};external={q['id']:shape(q) for q in valley};support_by_roof={}
 def add(pid,s,meta,cut=None):
  if s.is_empty() or s.volume()<1e-9:return []
  installed=[]
  for j,ss in enumerate(sorted(s.decompose(),key=lambda q:-q.volume())):
   if ss.volume()<1e-9:continue
   aid=pid if j==0 else pid+f'-P{j:02d}';cleanup=0.
   from closed_roof_envelope import closed_roof_record
   try:
    q,ss,receipt=closed_roof_record(ss);cleanup=receipt.get('occupied_difference_in3',0.);audit={'status':'PASS'}
   except AssertionError as error:
    q=pack(ss);audit=inspect_mesh(np.asarray(q['vertices']),np.asarray(q['triangles'],np.uint64),require_single=True);issues.append({'id':aid,'reason':'raw_closed_boundary','error':str(error),'audit':audit})
   records.append({'id':aid,**meta,**q,'raw_mesh_status':audit['status'],'cleanup_difference_in3':cleanup});solids[aid]=ss;installed.append(aid)
  if cut:stock.append({'id':'CUT-'+pid,'installed_ids':installed,**cut})
  print(pid,len(installed),'issues_total',len(issues),flush=True);return installed
 # Actual roof domains, filling only the authored1/8in plywood seams with
 # flexible adhered sheet; retained wood-bearing feet are explicit cutouts.
 for f in faces[:8]:
  vv=np.vstack([np.asarray(q['panel_top_polygon_m'])/I for q in main if q['roof_face']==f['face']]);q0,q1=min(vv@f['N']),max(vv@f['N']);pts=[]
  for q,u in [(q0,-q0*TA),(q1,-q1*TA),(q1,q1*TA),(q0,q0*TA)]:
   p=f['N']*q+f['U']*u;p[1]=(f['O']@f['W']-p@f['W'])/f['W'][1];pts.append(p)
  dom=region(pts,f)
  for rr in rel:
   if rr['face']==f['face']:
    for p in rr['relief_top_polygons_m']:dom=dom.difference(region(np.asarray(p)/I,f))
  if f['face']==2:
   for mem in interface['main_plywood_supported_members']:
    for rr in mem['actual_main_plywood_bearing']:
     dom=dom.difference(region(np.asarray(rr['outer_world_m'])/I,f).buffer(.001,join_style='mitre'))
  if f['face']==2:
   # Film is knife-fitted around real load-bearing wood feet, including
   # the new solid weather cleats, rather than occupying their bearing.
   support_patch=read(D/'porch-roof-support-candidate/porch-support-patch.json')
   fitwood=list(support_patch['add_parts'].values())+list(support_patch['receiver_readback_snapshots_for_local_proof_only'].values())+closures
   slab=toworld(prism(dom.convex_hull,[0,0,-.0001],[0,0,.20]),f);knife=[]
   for wood in fitwood:
    cut=shape(wood)^slab
    if cut.is_empty() or cut.volume()<1e-10:continue
    mesh=cut.to_mesh64();vv=np.asarray(mesh.vert_properties)[:,:3];polys=[region(vv[np.asarray(tri)],f) for tri in mesh.tri_verts];plan=unary_union([p for p in polys if p.area>1e-10])
    if not plan.is_empty:knife.append(plan.buffer(1/128,join_style='mitre'))
   if knife:dom=dom.difference(unary_union(knife))
  domains[f['id']]=dom
 for f in faces[8:]:
  roofq=[q for q in pd+closures if q.get('roof')==f['id'] and q['id'].startswith(('PORCH','MUD')) and 'WEB' not in q['id']];dom=unary_union([roof_top_region(q,f) for q in roofq]).convex_hull;dom=dom.intersection(box(-1000.,0.,1000.,1000.));domains[f['id']]=dom # Upperfieldsstopat actualporch deckeave; extendedapronstarterrunsbelowCu.
 for k in range(8):
  old=frame_main(k);q=next(q for q in cup if q['id']==f'CUP-ROOF-DECK-{k}');v=np.asarray(q['vertices'])/I;W=old['W'];level=max(v@W);qo=max(v@old['N']);O=old['N']*qo;O[1]=(level-O@W)/W[1];f={**old,'id':f'CUP{k}','O':O};faces.append(f);top=roof_top_region(q,f);lo,smin,hi,smax=top.bounds;# film bridges real1/8in hip gaps
  qi=7.+.703*float(W@old['N']);pts=[]
  for qq,u in [(qi,-qi*TA),(qo,-qo*TA),(qo,qo*TA),(qi,qi*TA)]:
   p=old['N']*qq+old['U']*u;p[1]=(level-p@W)/W[1];pts.append(p)
  domains[f['id']]=region(pts,f)
 checkpoint=OUTL/('cupola-membrane-checkpoint.json.gz' if '--cup-only' in sys.argv else 'main-membrane-checkpoint.json.gz' if '--main-only' in sys.argv else 'membrane-checkpoint.json.gz')
 if '--resume' in sys.argv and checkpoint.exists():
  saved=read(checkpoint);records=saved['parts'];stock=saved['stock'];issues=saved['issues'];foldreceipts=saved['foldreceipts'];lapreceipts=saved['lapreceipts'];solids={q['id']:shape(q) for q in records};print('RESUMED',len(records),flush=True)
 else:
  field_checkpoint=OUTL/'field-checkpoint.json.gz'
  if '--resume-fields' in sys.argv and field_checkpoint.exists():
   saved=read(field_checkpoint);records=saved['parts'];stock=saved['stock'];issues=saved['issues'];foldreceipts=saved['foldreceipts'];lapreceipts=saved['lapreceipts'];solids={q['id']:shape(q) for q in records};valley_bands={};print('RESUMED_FIELDS',len(records),flush=True)
  else:
   # Real36in rip from the57in roll. Three supported facets follow all
   # actual starter/drip steps; no constant extrusion passes through them.
   from roof_valley_membrane import construct_valley
   valley_bands={};valley_upper_bands={};mf=faces[2];B=faces[8]['porch_basis']
   for frame in substrate:
    side=frame['side'];f=faces[8 if side=='L' else 9];ss,proof,bands=construct_valley(frame,mf,f,domains,initial);pid='VDSA-VALLEY-'+side
    add(pid,ss,{'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier','kind':'continuous_folded_valley_icebarrier','thickness_in':TH,'parentStockId':'CUT-'+pid,**proof,'profile_scope':'One actual36in flexible sheet, supported three-facet fold following physical starter/drip steps. Custom corner/fold envelope, weather qualification remains open.'},{'product':'VaporDry SA','blank_width_in':36.,'blank_length_in':proof['blank_length_in'],'roll_width_in':57.,'roll_length_in':960.})
    for roof,band in bands.items():valley_bands[roof]=valley_bands.get(roof,Polygon()).union(band)
   if '--valley-only' in sys.argv:return
   # Main/porch fields, sequential eave-up4in laps, offset from plywood rows.
   for f in faces:
    dom=domains[f['id']];dom=dom.difference(valley_bands.get(f['id'],Polygon()));lo,smin,hi,smax=dom.bounds;s0=smin;course=0
    while s0<smax-1e-7:
     s1=min(s0+56.,smax);strip=dom.intersection(box(lo-1,s0,hi+1,s1));from roof_filtered_support import bounded_surface_support
     nearby={pid:s for pid,s in {**initial,**solids}.items() if bbox_overlap(bounds(s),bounds(toworld(prism(strip.convex_hull,[0,0,-.1],[0,0,.5]),f)))};copper=[tolocal(s,f) for pid,s in nearby.items() if pid.startswith('CU-')];film=[tolocal(s,f) for pid,s in nearby.items() if not pid.startswith('CU-')];under=bounded_surface_support(copper,strip,min_cosine=.00001)+bounded_surface_support(film,strip,min_cosine=.99999);pid=f'VDSA-{f["id"]}-FIELD-{course:02d}';ss,proof=sheet(strip,under,TH,pid,top_options={'min_cosine':.00001});foldreceipts.append(proof);ids=add(pid,toworld(ss,f),{'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier','kind':'self_adhered_roof_icebarrier','roof':f['id'],'course':course,'thickness_in':TH,'parentStockId':'CUT-'+pid,'projected_strip_width_in':s1-s0,'minimum_horizontal_lap_in':4. if course else None,'numerical_support_clearance_in':1e-6,'new_flexible_cut_planar_precision_in':1e-6,'profile_scope':'Physical25mil sheet follows actual starter, copper and previous sheet tops. Fixed57in stock with1in reserved fold allowance; no affine stretch. Main feet/R collar holes remain explicit.'},{'product':'VaporDry SA','blank_width_in':57.,'blank_length_in':strip.bounds[2]-strip.bounds[0]+.5,'roll_width_in':57.,'roll_length_in':960.});lapreceipts.append({'id':pid,'roof':f['id'],'s0_in':s0,'s1_in':s1,'horizontal_lap_in':4. if course else None,'maximum_actual_fold_height_in':sum(x['height_jump_in'] for x in proof['folds'])});s0+=52.;course+=1
   dump(OUTL/'field-checkpoint.json.gz',{'parts':records,'stock':stock,'issues':issues,'foldreceipts':foldreceipts,'lapreceipts':lapreceipts})
   if '--field-only' in sys.argv:print('FIELD_ONLY',len(records),'issues',len(issues),flush=True);return
  if '--resume-fields' in sys.argv:
   mf=faces[2];B=faces[8]['porch_basis']
   for fr in substrate:
    sf=faces[8 if fr['side']=='L' else 9];Wp,Wm=sf['W'],mf['W'];axis=np.asarray(fr['axis']);width=np.asarray(fr['outer_web_plane_normal']);c=fr['outer_web_plane_constant_in'];t0,t1=fr['axis_min_in'],fr['axis_max_in'];O=np.linalg.solve(np.array([width,Wm,axis]),[c,float(Wm@mf['O']),t0]);upper=np.linalg.solve(np.array([width,Wp,axis]),[c,float(Wp@sf['O']),t0]);hh=float((upper-O)@Wp);leg=(35.5-hh)/2;out=unit(-width+(width@Wm)*Wm)
    for rf,vec,point in [(mf,out,O),(sf,width,upper)]:valley_bands[rf['id']]=valley_bands.get(rf['id'],Polygon()).union(region([point+axis*u+vec*v for u in [0,t1-t0] for v in [0,leg-6.]],rf))
  # Independent12in per-face corner/hip strips. Each successive piece follows
  # prior overlaps, including near narrow cupola apex, rather than interpenetrating.
  for family in (['CUP'] if '--cup-only' in sys.argv else ['MAIN'] if '--main-only' in sys.argv else ['MAIN','CUP']):
   for h in range(8):
    leaves=[];length=0.;members=[]
    for k in [(h-1)%8,h]:
     f=next(q for q in faces if q['id']==family+str(k));dom=domains[f['id']].difference(valley_bands.get(f['id'],Polygon()).buffer(-.125,join_style='mitre'));r=np.array([math.cos(-h*math.pi/4),0.,math.sin(-h*math.pi/4)]);pts=[]
     for rr in ([6.,55.] if family=='CUP' else[40.,205.]):
      p=r*rr;p[1]=(f['O']@f['W']-p@f['W'])/f['W'][1];pts.append(p)
     ln=LineString(np.column_stack([(np.asarray(pts)-f['O'])@f['U'],(np.asarray(pts)-f['O'])@f['S']]));band=unary_union([dom,geotranslate(dom,xoff=.15),geotranslate(dom,xoff=-.15)]).intersection(ln.buffer(12.,cap_style='flat'));testbox=bounds(toworld(prism(band.convex_hull,[0,0,-.1],[0,0,.5]),f));recordmap={q['id']:q for q in records};under0=[tolocal(s,f) for pid,s in {**initial,**solids}.items() if bbox_overlap(bounds(s),testbox) and(pid in initial or recordmap[pid].get('roof')==f['id'] or recordmap[pid].get('kind')=='folded_hip_icebarrier')];under=under0+[q.translate([dx,0,0]) for q in under0 for dx in [-.10,.10]];ss,proof=sheet(band,under,TH,f'{family}-HIP-{h}-{k}',top_options={'min_cosine':.99999,'flat_height_quantum':.001,'flat_support_clearance':.00001});foldreceipts.append(proof);leaves.append(toworld(ss,f,fold_hip=h));length=max(length,ln.length);members.append(f['id'])
    pid=f'VDSA-{family}-HIP-{h}';add(pid,m.Manifold.batch_boolean(leaves,m.OpType.Add),{'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier','kind':'folded_hip_icebarrier','roof_family':family,'hip':h,'thickness_in':TH,'parentStockId':'CUT-'+pid,'face_lap_in':12.,'profile_scope':'Actual24in minimum developed-width cut with additional1in fold allowance, individually heightfitted over prior fields/hips.'},{'product':'VaporDry SA','blank_width_in':25.,'blank_length_in':length+.5,'roll_width_in':57.,'roll_length_in':960.})
  if '--cup-only' in sys.argv:
   dump(checkpoint,{'parts':records,'stock':stock,'issues':issues,'foldreceipts':foldreceipts,'lapreceipts':lapreceipts});print('CUPOLA_MEMBRANE_READY',len(records),'issues',len(issues),flush=True);return
  # Porch ridge strip, two12in legs, stopped at actual raised rear boundary.
  leaves=[];length=0.
  for f in faces[8:10]:
   dom=domains[f['id']].difference(valley_bands.get(f['id'],Polygon()));lo,smin,hi,smax=dom.bounds;band=unary_union([dom,geotranslate(dom,yoff=.6)]).intersection(box(lo-1,smax-12.,hi+1,smax+.6));recordmap={q['id']:q for q in records};under0=[tolocal(s,f) for pid,s in solids.items() if recordmap[pid].get('roof')==f['id'] or recordmap[pid].get('kind')=='continuous_folded_valley_icebarrier'];ss,proof=sheet(band,under0+[q.translate([0,.6,0]) for q in under0],TH,f'PORCH-RIDGE-{f["id"]}',top_options={'min_cosine':.99999,'flat_height_quantum':.001,'flat_support_clearance':.00001});foldreceipts.append(proof);leaves.append(toworld(ss,f,fold_ridge=True));length=max(length,hi-lo)
  add('VDSA-PORCH-RIDGE',m.Manifold.batch_boolean(leaves,m.OpType.Add),{'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier','kind':'folded_ridge_icebarrier','thickness_in':TH,'parentStockId':'CUT-VDSA-PORCH-RIDGE','face_lap_in':12.,'profile_scope':'Two actual12in legs meeting at roofridge; physical ridgegap bridge/open rear transition must compose against valley head.'},{'product':'VaporDry SA','blank_width_in':25.,'blank_length_in':length+.5,'roll_width_in':57.,'roll_length_in':960.})
  dump(checkpoint,{'parts':records,'stock':stock,'issues':issues,'foldreceipts':foldreceipts,'lapreceipts':lapreceipts})
 if '--cup-only' in sys.argv or '--membrane-only' in sys.argv:print('MEMBRANE_CHECKPOINT',len(records),'issues',len(issues),flush=True);return
 # Nominal mat follows actual SA; local fixed pan seats select compression
 # only beneath valley felt, at any unavoidable extra membrane head lap.
 cedar=read(D/'porch-roof-covering-revision/all-raw-wood.json.gz')['parts'];cedar_by=collections.defaultdict(list)
 for q in cedar:
  if q.get('roof') in ['MAIN'+str(k) for k in range(8)]+['PORCHL','PORCHR']:cedar_by[q['roof']].append(q)
 for f in faces[:10]:
  dom=domains[f['id']]
  if f['id'].startswith('MAIN'):dom=unary_union([dom,geotranslate(dom,xoff=.15),geotranslate(dom,xoff=-.15)])
  else:dom=unary_union([dom,geotranslate(dom,yoff=.6)])
  if f['id']=='MAIN2':
   exposed=unary_union([polyplan(np.asarray(q['vertices'])/I) for q in cedar_by[f['id']]])
   # Felt main apron extends beyond the shingles' open valley cut.
   for q in valley:
    if q.get('kind')=='valley_felt_strip':
     pass
   plan=poly_column(exposed);slab=toworld(prism(dom,[0,0,0],[0,0,.1]),f)^plan;dom=unary_union([region(np.asarray(slab.to_mesh64().vert_properties)[np.asarray(t)] ,f) for t in slab.to_mesh64().tri_verts if abs(np.cross(*(np.diff(np.asarray(slab.to_mesh64().vert_properties)[np.asarray(t)],axis=0)))@f['W'])>0]) if False else dom
   # Correct planar projection uses exposed plan at the actual sloped roof.
   ppol=[]
   for p in pieces(exposed):
    coords=np.asarray(p.exterior.coords);v=np.column_stack([coords[:,0],np.zeros(len(coords)),coords[:,1]]);v[:,1]=(f['O']@f['W']-v@f['W'])/f['W'][1];ppol.append(region(v,f))
   dom=dom.intersection(unary_union(ppol+[roof_top_region(q,f) for q in valley if q.get('kind')=='valley_felt_strip']))
  lo,smin,hi,smax=dom.bounds;under=[tolocal(s,f) for pid,s in {**initial,**solids}.items() if not pid.startswith('CB-') and not s.is_empty()];feltcells=[]
  for q in valley:
   if q.get('kind')=='valley_felt_strip':
    p=roof_top_region(q,f)
    if not p.is_empty:feltcells.append(p)
  fixed=set_precision(unary_union(feltcells).buffer(0),1e-9);cells=support_cells(dom,under)
  for course,s0 in enumerate(np.arange(smin,smax,39.)):
   strip=dom.intersection(box(lo-1,s0,hi+1,min(s0+39.,smax)));bits=[];mins=[];maxs=[]
   for c in cells:
    p=set_precision(c['polygon'].intersection(strip),1e-9)
    if p.is_empty or p.area<1e-10:continue
    for fixedtop,zone in [(False,p if fixed.is_empty else p.difference(fixed)),(True,Polygon() if fixed.is_empty else p.intersection(fixed))]:
     for poly in pieces(zone):
      if poly.area<1e-10:continue
      low=c['plane'];top=np.array([0.,0.,.310]) if fixedtop else low+np.array([0.,0.,CB]);vv=np.asarray(poly.exterior.coords)[:-1];th=[height(top-low,z) for z in vv];mins.extend(th);maxs.extend(th)
      if min(th)<.25-1e-6:issues.append({'id':f'CB-{f["id"]}-{course}','reason':'Morethan.035inselectedcompression','minimum_thickness_in':min(th)})
      bits.append(prism(poly,low,top))
   ss=m.Manifold.batch_boolean(bits,m.OpType.Add);pid=f'CB-{f["id"]}-FIELD-{course:02d}';add(pid,toworld(ss,f),{'material':'Benjamin Obdyke Cedar Breather','kind':'porous_roof_ventilation_mat_envelope','roof':f['id'],'course':course,'parentStockId':'CUT-'+pid,'nominal_thickness_in':CB,'minimum_local_thickness_in':min(mins) if mins else None,'maximum_local_thickness_in':max(maxs) if maxs else None,'butt_course_no_lap':True,'profile_scope':'Porous gross envelope, not solid fibers. Nominal.285 thickness follows actual SA height except local fixed valley-felt seat; selectedcompression remainsinstallationqualification, no loadclaim.'},{'product':'Cedar Breather','blank_width_in':39.,'blank_length_in':strip.bounds[2]-strip.bounds[0]+.5,'roll_width_in':39.,'roll_length_in':738.});matreceipts.append({'id':pid,'minimum_in':min(mins) if mins else None,'maximum_in':max(maxs) if maxs else None})
 # Physical layer-only intersections and underlay/Cu contact checks. Cedar
 # must be rigidly reseated later, so old cedar is not a false final PASS.
 overlaps=[];grid=Grid();checks=0
 allshapes={**initial,**external,**solids}
 for pid,s in allshapes.items():
  for mid in grid.query(bounds(s)):
   if pid in initial and mid in initial:continue
   checks+=1;v=max(0.,(s^allshapes[mid]).volume())
   if v>TOL:overlaps.append({'a':pid,'b':mid,'overlap_in3':v})
  grid.add(pid,s)
 rolls=[]
 for cut in sorted(stock,key=lambda q:(q['product'],-q['blank_length_in'])):
  if cut['blank_width_in']>cut['roll_width_in']+1e-8 or cut['blank_length_in']>cut['roll_length_in']+1e-8:issues.append({'id':cut['id'],'reason':'Blankexceedsrealstock'})
  options=[r for r in rolls if r['product']==cut['product'] and r['used_length_in']+cut['blank_length_in']<=r['length_in']+1e-8];roll=min(options,key=lambda r:r['length_in']-r['used_length_in']) if options else None
  if roll is None:roll={'id':'ROLL-'+cut['product'].replace(' ','')+'-'+str(sum(q['product']==cut['product'] for q in rolls)+1),'product':cut['product'],'width_in':cut['roll_width_in'],'length_in':cut['roll_length_in'],'used_length_in':0.,'cuts':[]};rolls.append(roll)
  cut['parentRollId']=roll['id'];cut['start_length_in']=roll['used_length_in'];roll['cuts'].append(cut['id']);roll['used_length_in']+=cut['blank_length_in']
 for r in rolls:r['end_offcut_length_in']=r['length_in']-r['used_length_in']
 dump(OUTL/'parts.json.gz',{'parts':records,'scope':'UNBORED physical flexible roof layer envelopes; final copper/cedar/fastener composition pending.'});dump(OUTL/'stock.json',{'cuts':stock,'rolls':rolls,'stock_by_product':dict(collections.Counter(q['product'] for q in rolls)),'nesting_scope':'Conservative fullwidth allocations; unused rip width is explicit offcut, not reused invisibly.'});dump(OUTL/'report.json',{'status':'LAYER_GEOMETRY_PASS_PENDING_CEDAR_AND_FINAL_COPPER' if not issues and not overlaps else'BLOCKED','parts':len(records),'counts':dict(collections.Counter(q['kind'] for q in records)),'issues':issues,'intersections':overlaps,'checks':checks,'laps':lapreceipts,'mat_receipts':matreceipts,'sources':{'icebarrier':'https://benjaminobdyke.com/wp-content/uploads/2024/02/2024-VDSA-IRC-Compliance-Tech-Bulletin.pdf','guide':'https://benjaminobdyke.com/wp-content/uploads/2023/04/VaporDrySA-InstallGuide_08.2026.pdf'},'scope':['Allrawwoodunbored; onlyintendednail/screwpenetrationsallowed.','Cedar must reseat rigidly over actualnominalmat/Cu stack; currentoldpose isnotqualified.','Solder/fold/headseam/siteweatherqualification remainsopen; positive physical envelopes donotcertifyweathercapacity.']});dump(OUTL/'fold-receipts.json',{'receipts':foldreceipts});print('DONE',len(records),'issues',len(issues),'overlaps',len(overlaps),flush=True)
if __name__=='__main__':run()
