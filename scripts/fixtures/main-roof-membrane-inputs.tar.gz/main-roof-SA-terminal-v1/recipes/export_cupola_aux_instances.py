"""Exact compact auxiliary cupola nail placements and causal Cu head covers."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps')]
from whole_roof_cedar import *
from export_roof_nail_instances import basis
from scipy.spatial import cKDTree
OUT=D/'cupola-physical-copper-candidate'
def read(p):return json.load(gzip.open(p,'rt')) if str(p).endswith('.gz') else json.load(open(p))
def swept(s,d):
 d=np.asarray(d,float);mesh=s.to_mesh64();v=np.asarray(mesh.vert_properties)[:,:3];solids=[s,s.translate(d.tolist())];discard=0.;fv=np.array([[0,2,1],[3,4,5],[0,1,4],[0,4,3],[1,2,5],[1,5,4],[2,0,3],[2,3,5]],np.uint64);base=m.Manifold(m.Mesh64(np.array([[0,0,0],[1,0,0],[0,1,0],[0,0,1],[1,0,1],[0,1,1]],float),fv))
 for tri in mesh.tri_verts:
  pts=v[tri];M=np.column_stack([pts[1]-pts[0],pts[2]-pts[0],d,np.zeros(3)]);vol=abs(np.linalg.det(M[:,:3]))/2
  if vol<1e-12:discard+=vol;continue
  q=base.transform(M.tolist()).translate(pts[0].tolist());discard+=abs(q.volume()-vol);solids.append(q)
 return m.Manifold.batch_boolean(solids,m.OpType.Add),discard

def run():
 rows=read(OUT/'roof-hardware-and-rays.json')['hardware'];copper={q['id']:shape(q) for q in read(OUT/'copper-parts-with-fresh-holes.json')['parts']};protos={};refs={};instances=[];cutters=[];paths=[];maxdist=0.
 for n in rows:
  sku=n['sku']
  if sku in protos:continue
  nn=copy.deepcopy(n);nn['head_in']=[0,0,0];nn['outward_normal']=[0,0,1];metal,tool=nail_shapes(nn);refs[sku]=(metal,tool);protos[sku]={'id':sku,'metal':pack(metal),'bore_tool':pack(tool),'material':'Type316 stainless steel','nominal_length_in':n['length_in'],'diameter_in':n['diameter_in'],'head_diameter_in':n['head_diameter_in'],'assumed_head_height_in':n['assumed_head_height_in'],'assumed_point_in':.18,'origin':'Headtopcenter, local+Zoutward; meters','profile_scope':'Publishednominaldimensions, explicitdiamondpoint/head-heightenvelopes, no inventedfactoryringCAD. HistoricalT20currentprocurementunconfirmed.'}
 for n in rows:
  rot=basis(n['outward_normal'])@basis([0,0,1]).T;h=np.asarray(n['head_in']);M=np.column_stack([rot,h*I]);M4=np.eye(4);M4[:3,:]=M;body,tool=nail_shapes(n);trans=refs[n['sku']][0].transform(np.column_stack([rot,h]).tolist());av=np.asarray(body.to_mesh64().vert_properties);bv=np.asarray(trans.to_mesh64().vert_properties);dist=max(cKDTree(av).query(bv)[0].max(),cKDTree(bv).query(av)[0].max());maxdist=max(maxdist,float(dist));assert dist<1e-8
  delta=unit(n['outward_normal'])*(n['length_in']+1.);sweep,error=swept(body,delta);cover=[]
  for pid,cu in copper.items():
   if not bbox_overlap(bounds(sweep),bounds(cu)):continue
   vol=max(0.,(sweep^cu).volume())
   if vol+error>TOL:cover.append({'id':pid,'swept_overlap_in3':vol})
  row={**n,'receiverIds':n['receiver_ids'],'causalReceivingIds':n['receiver_ids'],'laterHeadCoverContactIds':[],'extractionBlockedBy':[q['id'] for q in cover],'mesh_instance':{'prototype_id':n['sku'],'geometry_field':'metal','transform':M.tolist()},'world_matrix_column_major':M4.T.reshape(-1).tolist(),'withdrawal_translation_m':(delta*I).tolist(),'assembly_rule':'Seatownerwood/clip, drivethisnail; installlistedlaterCu coversaftertheirunderlyingnails. Reverseprerequisitesforextraction.','is_fastener':True,'material':'Type316 stainless steel'};instances.append(row);cutters.append({'id':'CUT-'+n['id'],'nail_id':n['id'],'prototype_id':n['sku'],'geometry_field':'bore_tool','transform':M.tolist(),'world_matrix_column_major':M4.T.reshape(-1).tolist(),'apply_to':'FreshfinalMETALonlywhereactualoccupiedintersection; intendedauthoredwoodpenetrationallowed.','wood_receiver_ids':n['receiver_ids']});paths.append({'id':n['id'],'actual_swept_triangle_prism_residual_in3':error,'cover_prerequisites':cover,'scope':'Actualcontinuousnailtranslationagainst57finalCucomponents. Othernailsandwholebuildingroutecheckedseparately.'})
 dump(OUT/'aux-nail-shared-prototypes.json',{'units':'meters','prototypes':protos});dump(OUT/'aux-nail-instances.json.gz',{'instances':instances});dump(OUT/'aux-nail-cutters.json.gz',{'tools':cutters});dump(OUT/'aux-nail-cover-prerequisites.json',{'status':'PASS','nails':len(rows),'maximum_prototype_vertex_error_in':maxdist,'rows':paths});print('DONE',len(rows),'prototypes',len(protos),'maxerror',maxdist,'cover-prerequisites',sum(len(r['cover_prerequisites']) for r in paths),flush=True)
if __name__=='__main__':run()
