"""RealVaporDry eavestarters and12inverticalcorneroverlaps; externalonly."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps'),'/workspace/sites/octagonal-timberframe-building/scripts']
from whole_roof_cedar import *
from roof_heightfield_sheet import regular_boundary_geos
from audit_cavity_fit import inspect_mesh
OUTE=D/'roof-eave-starter-candidate';OUTE.mkdir(exist_ok=True)
T=.025;TAPE=.00035/I
def read(p):return json.load(gzip.open(p,'rt')) if str(p).endswith('.gz') else json.load(open(p))
def extrude(poly,O,U,N,V,lo,hi):return m.CrossSection([np.asarray(poly.exterior.coords)[:-1].tolist()],m.FillRule.EvenOdd).extrude(hi-lo).transform(np.column_stack([N,V,U,O+U*lo]).tolist())
def partition(s,k,N):
 for h in [k,k+1]:
  a=-h*math.pi/4;n=np.array([-math.sin(a),0.,math.cos(a)])
  if n@N<0:n=-n
  s=s.trim_by_plane(n.tolist(),0.)
 return s
def run():
 parts=[];shapes={};frames=[];stock=[];issues=[];cleanup=[]
 def add(pid,s,meta):
  q=pack(s);a=inspect_mesh(np.asarray(q['vertices']),np.asarray(q['triangles'],np.uint64),require_single=True)
  if a['status']!='PASS':
   try:
    old=s.scale([I]*3);ss=regular_boundary_geos(old);mm=ss.to_mesh64();q={'vertices':np.asarray(mm.vert_properties)[:,:3].tolist(),'triangles':np.asarray(mm.tri_verts).tolist(),'volume_m3':ss.volume()};s=shape(q);cleanup.append({'id':pid,'occupied_difference_in3':(max(0.,(ss-old).volume())+max(0.,(old-ss).volume()))/I**3});a=inspect_mesh(np.asarray(q['vertices']),np.asarray(q['triangles'],np.uint64),require_single=True)
   except Exception as e:issues.append({'id':pid,'cleanup_error':str(e)})
  if a['status']!='PASS':issues.append({'id':pid,'audit':a})
  shapes[pid]=s;parts.append({'id':pid,**meta,**q,'raw_mesh_status':a['status']})
 inputs=[('MAIN',k,frame_main(k),200*math.cos(math.pi/8)+.451) for k in range(8)]
 cup=read(D/'cupola-copper-candidate/roof-raw-wood.json')['parts']
 for k in range(8):
  q=next(q for q in cup if q['id']==f'CUP-ROOF-DECK-{k}');ff=frame_main(k);vv=np.asarray(q['vertices'])/I;level=float(max(vv@ff['W']));qout=float(max(vv@ff['N']));O=ff['N']*qout;O[1]=(level-O@ff['W'])/ff['W'][1];ff={**ff,'O':O};inputs.append(('CUP',k,ff,52.244937352+.451))
 for family,k,f,qfront in inputs:
  N,U,W=f['N'],f['U'],f['W'];O=f['O'];qtop=float(O@N);delta=qfront-qtop;p=f['pitch'];g=f['gamma'];fy=-.703*g-p*delta;path=LineString([[-8/g,8*p/g],[0,0],[-.703*W[0]/N[0] if abs(N[0])>.1 else-.703*(W@N),-.703*W[1]],[delta,fy],[delta,fy-2],[delta+TAPE,fy-2],[delta+TAPE,fy-4]])
  # WdotN isface-invariant; avoidcoordinateaxisdivision inexactprofile.
  coords=list(path.coords);coords[2]=[-.703*float(W@N),-.703*float(W@UP)];path=LineString(coords);profile=path.buffer(T,single_sided=True,cap_style='flat',join_style='mitre');half=(qfront+TAPE+2*T+.1)*TA;fr={'family':family,'k':k,'O':O,'N':N,'U':U,'W':W,'profile':profile,'path':path,'half':half,'fascia_top_relative_y_in':fy,'delta':delta};frames.append(fr);pid=f'VDSA-EAVE-STARTER-{family}{k}';s=partition(extrude(profile,O,U,N,UP,-half,half),k,N);add(pid,s,{'material':'BenjaminObdykeVaporDrySA25milAC48icebarrier','kind':'eave_icebarrier_starter','roof':f'{family}{k}','thickness_in':T,'parentStockId':'CUT-'+pid,'roof_leg_in':8.,'fascia_return_vertical_in':4.,'tape_thickness_beneath_lower_return_in':TAPE,'profile_scope':'Flexiblefieldfoldfollowsactualdeckedge/.451fasciatopand4infrontreturn. Lower2inconformsto.35mmtape, upperreturnonbarefascia. Cornerpatchseparate12inlap.','air_water_scope':'Sourceproducticebarrierapproval; customoctagoneavefold/weatherassemblyqualificationnotclaimed.'});stock.append({'id':'CUT-'+pid,'product':'VaporDrySA','blank_width_in':path.length+.1,'blank_length_in':2*half+.1,'roll_width_in':57.,'roll_length_in':960.})
 for corner in range(16):
  family='MAIN' if corner<8 else'CUP';h=corner%8;frame_offset=0 if family=='MAIN' else 8;leaves=[]
  for k,end in [((h-1)%8,-1),(h,1)]:
   fr=frames[k+frame_offset];delta,fy=fr['delta'],fr['fascia_top_relative_y_in'];path=LineString([[delta,fy],[delta,fy-2],[delta+TAPE,fy-2],[delta+TAPE,fy-4]]);offset_path=path.parallel_offset(T,'left',join_style='mitre');profile=offset_path.buffer(T,single_sided=True,cap_style='flat',join_style='mitre');half=fr['half'];lo,hi=(half-12.1,half) if end>0 else(-half,-half+12.1);leaves.append(partition(extrude(profile,fr['O'],fr['U'],fr['N'],UP,lo,hi),k,fr['N']))
  pid=f'VDSA-EAVE-CORNER-{family}-{h}';s=m.Manifold.batch_boolean(leaves,m.OpType.Add);add(pid,s,{'material':'BenjaminObdykeVaporDrySA25milAC48icebarrier','kind':'vertical_eave_corner_icebarrier_patch','corner':h,'roof_family':family,'thickness_in':T,'parentStockId':'CUT-'+pid,'face_lap_in':12.,'profile_scope':'Onefieldfoldedverticalcornerpatchwith12inlegs aboveactualeavestarters; roofcornercoveredseparatelyby12inhipstrip. Exactfoldradius/pleat/tabfabricationunqualified.','roof_normal_stack_added_in':0.});stock.append({'id':'CUT-'+pid,'product':'VaporDrySA','blank_width_in':4.2,'blank_length_in':25.,'roll_width_in':57.,'roll_length_in':960.})
 porch=read(D/'whole-roof-cedar/porch-source.json');porchfaces=make_faces([],[],porch)[8:];patch=read(D/'porch-roof-support-candidate/porch-support-patch.json');mainW=UP+PMAIN*np.asarray(porch['outward']);rearC=patch['rear_panel_cut_plane_constant_in']+PMAIN*float(np.asarray(porch['outward'])@(np.asarray(porch['origin'])/I));fascias=read(D/'physical-closure-candidate/porch-eave-fascia-final.json.gz')['add_parts'];plateTop=min(min(np.asarray(q['vertices'])[:,1]/I) for q in fascias.values());roofclosures=read(D/'porch-flashing-substrate-candidate/parts.json')['parts'];porchdecks=read(D/'porch-roof-support-candidate/revised-porch-decks.json')['parts']
 for f in porchfaces:
  N,U,W,O=f['N'],f['U'],f['W'],f['O'];qtop=float(O@N);delta=54.25-qtop;plateDelta=54.5-qtop;g=f['gamma'];p=f['pitch'];fy=-.703*g-p*delta;py=plateTop-O[1];endY=fy-4.;path=LineString([[-8/g,8*p/g],[0,0],[-.703*float(W@N),-.703*float(W@UP)],[delta,fy],[delta,py],[plateDelta,py],[plateDelta,endY]]);profile=path.buffer(T,single_sided=True,cap_style='flat',join_style='mitre');lo=float(porch['roof']['mainEaveZ_M']/I);hi=f['front'];s=extrude(profile,O,U,N,UP,lo,hi);s=s.trim_by_plane((mainW/np.linalg.norm(mainW)).tolist(),rearC/np.linalg.norm(mainW));topplans=[]
  for q in porchdecks+roofclosures:
   if q.get('roof')!=f['id']:continue
   vv=np.asarray(q['vertices'])/I;tt=np.asarray(q['triangles'])
   for tr in tt:
    pp=vv[tr]
    if max(abs((pp-O)@W))<1e-6 and np.cross(pp[1]-pp[0],pp[2]-pp[0])@W>0:topplans.append(polyplan(pp))
  roofplan=unary_union(topplans).convex_hull;roofleg=m.Manifold.hull_points([O+U*u+f['S']*v+W*z for u in [lo,hi] for v in [-2.,8.] for z in [0.,T]])^poly_column(roofplan)
  # Actual rear flashing-apron stock extends across the normal fascia fold.
  # Knife-relieve that buried return and continue the SAME starter above
  # the real apron, beneath the unchanged .025in-raised copper plate cover.
  actualapron=m.Manifold.batch_boolean([shape(q) for q in roofclosures if q.get('roof')==f['id']],m.OpType.Add);buried=s^actualapron;s=s-actualapron;s=s+roofleg;side='L' if f['porch_side']<0 else'R';pid='VDSA-EAVE-STARTER-PORCH'+side
  add(pid,s,{'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier','kind':'eave_icebarrier_starter','roof':f['id'],'thickness_in':T,'parentStockId':'CUT-'+pid,'roof_leg_in':8.,'fascia_return_vertical_in':4.,'roof_only_extension_over_real_flashing_apron':True,'declared_buried_return_knife_relief_in3':max(0.,buried.volume()),'apron_roof_extension_outside_normal_eave_in':2.,'actual_fascia_front_local_x_in':54.25,'actual_plate_outer_local_x_in':54.5,'profile_scope':'Physical film follows actual beveledfasciatop/verticalfront, then crosses actual.25in platetopledge and continues downplate. Rear cut follows exact retainedmainroof/porch supportjunction. Customcompoundendcornerdetails unqualified.','support_source':'physical-closure-candidate/porch-eave-fascia-final.json.gz'});stock.append({'id':'CUT-'+pid,'product':'VaporDrySA','blank_width_in':path.length+.1,'blank_length_in':hi-lo+.1,'roll_width_in':57.,'roll_length_in':960.})
 grid=Grid();pairs=[];checks=0
 for pid,s in shapes.items():
  for mid in grid.query(bounds(s)):
   checks+=1;v=max(0.,(s^shapes[mid]).volume())
   if v>TOL:pairs.append({'a':pid,'b':mid,'overlap_in3':v})
  grid.add(pid,s)
 dump(OUTE/'parts.json',{'parts':parts});dump(OUTE/'stock.json',{'cuts':stock,'scope':'Real57x960VaporDrystock; flexiblefoldallowancesexplicit, finalrollnestingwithfieldcuts.'});dump(OUTE/'report.json',{'status':'GEOMETRY_PASS_PENDING_ACTUAL_ENCLOSURE_AND_CU' if not issues and not pairs else'BLOCKED','parts':len(parts),'issues':issues,'intersections':pairs,'checks':checks,'cleanups':cleanup,'main2_under_porch_continuous':True,'Cu_required_base_roof_normal_lift_in':.025,'Cu_required_base_fascia_outward_lift_in':.050,'qualification':['Eightmainfull eavestarters includemain2underporch; nofalseexposeddripthere.','Verticalpatch12inlaps; roofcornershaveindependent12inhipstrips; exactcompoundeavefoldremainsfielddetail.','Noadditionalpermanentmembranefasteners; adhesiveandentire-surfacepressureactivationpermanufacturer.','Allotherwood/enclosureandnewCuintersections mustbecomposedbeforefinalselection.']});print('DONE',len(parts),'issues',len(issues),'pairs',len(pairs),flush=True)
if __name__=='__main__':run()
