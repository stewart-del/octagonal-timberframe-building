"""Actual new-film edge slots around fixed porch wood and existing Cu.
No framing/metal is cut. All new termini are named for the adjoining
physical boot/metal weather detail, not called invisibly watertight.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps')]
from roof_physical_layers import *
from closed_roof_envelope import closed_roof_record

def run():
 root=D/'roof-eave-starter-candidate';raw=read(root/'parts.json');parts=raw['parts'];patch=read(D/'porch-roof-support-candidate/porch-support-patch.json');wood={**patch['add_parts'],**patch['receiver_readback_snapshots_for_local_proof_only']};wood.update({q['id']:q for q in read(D/'porch-flashing-substrate-candidate/parts.json')['parts']});cu={q['id']:q for q in read(D/'roof-edge-flashing-candidate/drip-parts.json')['parts'] if 'PORCH' in q['id']};obstacles={pid:shape(q) for pid,q in {**wood,**cu}.items()};output=[];receipts=[];stock=read(root/'stock.json')
 for q in parts:
  pid=q['id']
  if pid not in ['VDSA-EAVE-STARTER-MAIN2','VDSA-EAVE-STARTER-PORCHL','VDSA-EAVE-STARTER-PORCHR']:
   if 'CUP' not in pid:q={**q,'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier membrane'}
   output.append(q);continue
  ss=shape(q);hits=[]
  for oid,s in obstacles.items():
   if not bbox_overlap(bounds(ss),bounds(s)):continue
   vol=max(0.,(ss^s).volume())
   if vol>TOL:
    knives=[]
    for contact in (ss^s).decompose():
     vv=vertices(contact);delta=.015625;points=np.vstack([vv]+[vv+np.eye(3)[axis]*sign*delta for axis in range(3) for sign in [-1,1]]);knives.append(m.Manifold.hull_points(points))
    knife=m.Manifold.batch_boolean(knives,m.OpType.Add);before=ss;ss=ss-knife;hits.append({'id':oid,'original_occupied_intersection_in3':vol,'actual_selected_knife_offcut_in3':max(0.,(before-ss).volume()),'selected_edge_clearance_in':.015625,'knife_profile':'Convexfieldknifeoutlineperactualcontactcomponent; sourcewoodandmetalunchanged.'})
  installed=[]
  for i,part in enumerate(sorted(ss.decompose(),key=lambda s:-s.volume())):
   if part.volume()<1e-8:continue
   aid=pid if i==0 else pid+f'-P{i:02d}';rec,part,r=closed_roof_record(part);output.append({**q,**rec,'id':aid,'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier membrane','raw_mesh_status':'PASS','boundary_receipt':r,'actual_porch_edge_knife_fit_hosts':hits,'field_cut_scope':'Onlynewflexiblestockedgeisrelievedaroundactualretainedwood/Cu. Valleymembrane+actualporchCucoverroof-sidejoint; porch-plate/fasciabootjoinsrequiretheenclosureagentactualoverlaps. No invisibleweatherproofclaim.'});installed.append(aid)
  for c in stock['cuts']:
   if c['id']=='CUT-'+pid:c['installed_ids']=installed
  receipts.append({'id':pid,'installed_ids':installed,'edge_notches':hits});print(pid,len(installed),len(hits),flush=True)
 dump(root/'parts.json',{'parts':output});dump(root/'stock.json',stock);dump(root/'porch-edge-knife-fit-receipts.json',{'status':'RAW_PASS','receipts':receipts,'scope':'Newstockonly; originalframe/decks/Cupstarters/Cudripsunchanged. Cup16startersretainedbyteexact.'});print('DONE',len(output),flush=True)
if __name__=='__main__':run()
