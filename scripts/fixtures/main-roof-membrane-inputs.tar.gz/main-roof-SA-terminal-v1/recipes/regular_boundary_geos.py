"""Closed net planar boundary, GEOS triangulation; no source/auditor changes."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE/'python-deps'))
import numpy as np,manifold3d as m
from shapely.geometry import Polygon,MultiPolygon
from shapely.ops import unary_union
from shapely import constrained_delaunay_triangles
from scipy.spatial import cKDTree
def regular_boundary_geos(shape,tol=1e-9,max_difference_in3=1e-6):
 mm=shape.to_mesh64();v=np.asarray(mm.vert_properties)[:,:3];t=np.asarray(mm.tri_verts);groups=[]
 for tri in t:
  pts=v[tri];n=np.cross(pts[1]-pts[0],pts[2]-pts[0]);ln=np.linalg.norm(n)
  if ln<1e-20:continue
  n/=ln;sign=1
  pivot=next((i for i in range(3) if abs(n[i])>1e-8),int(np.argmax(abs(n))))
  if n[pivot]<0:n=-n;sign=-1
  g=next((q for q in groups if np.linalg.norm(q['n']-n)<1e-9 and max(abs((pts-q['O'])@q['n']))<tol),None)
  if g is None:
   u=np.cross(n,np.eye(3)[np.argmin(abs(n))]);u/=np.linalg.norm(u);g={'n':n,'O':pts[0],'B':np.column_stack([u,np.cross(n,u)]),'positive':[],'negative':[]};groups.append(g)
  poly=Polygon((pts-g['O'])@g['B'])
  if poly.area>1e-24:g['positive' if sign>0 else'negative'].append(poly)
 regions=[];pool=[]
 for g in groups:
  pos=unary_union(g['positive']);neg=unary_union(g['negative'])
  for sign,region in [(1,pos.difference(neg)),(-1,neg.difference(pos))]:
   polys=list(region.geoms) if hasattr(region,'geoms') else[region]
   for p in polys:
    if p.is_empty or p.area<1e-24:continue
    if p.geom_type!='Polygon':continue
    loops=[np.asarray(p.exterior.coords)[:-1]]+[np.asarray(r.coords)[:-1] for r in p.interiors];world=[g['O']+loop@g['B'].T for loop in loops];regions.append((g,sign,world))
    pool.extend(x for loop in world for x in loop)
 pool=np.array(pool);unique=[];ids=[]
 for p in pool:
  if unique:
   ds=np.linalg.norm(np.array(unique)-p,axis=1);i=int(ds.argmin())
   if ds[i]<=tol:ids.append(i);continue
  ids.append(len(unique));unique.append(p)
 points=np.array(unique);faces=[]
 for g,sign,loops in regions:
  splitloops=[]
  for loop in loops:
   out=[]
   for a,b in zip(loop,np.roll(loop,-1,axis=0)):
    d=b-a;l2=d@d
    if l2<=tol*tol:continue
    tt=(points-a)@d/l2;dist=np.linalg.norm(points-(a+tt[:,None]*d),axis=1);idx=np.flatnonzero((tt>1e-10)&(tt<1-1e-10)&(dist<=tol));out.append(a);out.extend(points[i] for i in sorted(idx,key=lambda i:tt[i]))
   dedup=[]
   for point in out:
    if not dedup or np.linalg.norm(point-dedup[-1])>tol:dedup.append(point)
   if len(dedup)>1 and np.linalg.norm(dedup[0]-dedup[-1])<=tol:dedup.pop()
   if len(dedup)>=3:splitloops.append((np.array(dedup)-g['O'])@g['B'])
  if not splitloops:continue
  poly=Polygon(splitloops[0],splitloops[1:])
  if not poly.is_valid:poly=poly.buffer(0)
  tris=constrained_delaunay_triangles(poly)
  for tr in tris.geoms:
   xyz=g['O']+np.asarray(tr.exterior.coords)[:3]@g['B'].T;index=[]
   for p in xyz:
    ds=np.linalg.norm(points-p,axis=1);i=int(ds.argmin())
    if ds[i]>tol:points=np.vstack([points,p]);i=len(points)-1
    index.append(i)
   q=points[index]
   if np.cross(q[1]-q[0],q[2]-q[0])@g['n']*sign<0:index=index[::-1]
   faces.append(index)
 result=m.Manifold(m.Mesh64(points,np.asarray(faces,np.uint64)));assert str(result.status())=='Error.NoError',('GEOSnetboundary',str(result.status()),len(points),len(faces))
 error=max(0.,(result-shape).volume())+max(0.,(shape-result).volume());assert error<=max_difference_in3*.0254**3,('GEOSoccupieddifferencein3',error/.0254**3)
 return result
