"""Shared renderer/cutting prototypes plus exact rigid nail placements."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
import copy,gzip,hashlib,json,collections,numpy as np
from scipy.spatial import cKDTree
from whole_roof_cedar import OUT,nail_shapes,shape,pack,unit,dump,I,TOL

def load(p):
    return json.load(gzip.open(p,'rt')) if str(p).endswith('.gz') else json.load(open(p))

def basis(n):
    n=unit(n);a=unit(np.cross(n,np.eye(3)[np.argmin(abs(n))]));b=np.cross(n,a)
    return np.column_stack([a,b,n])

def run():
    src=OUT/'nails-and-rays.json.gz';nails=load(src)['nails'];boredata=load(OUT/'bore-records.json.gz');hosts=collections.defaultdict(list)
    for r in boredata['actual_bores']:hosts[r['nail']].append({'host_id':r['host'],'removed_in3':r['removed_in3']})
    prototypes={};refs={}
    for n in nails:
        sku=n['sku']
        if sku in prototypes:continue
        ref=copy.deepcopy(n);ref['head_in']=[0,0,0];ref['outward_normal']=[0,0,1];metal,tool=nail_shapes(ref);refs[sku]=(metal,tool)
        prototypes[sku]={'id':sku,'origin':'Head top center; outward axis +Z. World transform uses meters.','material':'Type316 stainless steel','length_in':n['length_in'],'shank_diameter_in':n['diameter_in'],'head_diameter_in':n['head_diameter_in'],'assumed_head_height_in':n['assumed_head_height_in'],'assumed_point_length_in':.18,'profile_scope':'Verified nominal length/shank/head diameter. Head height and four-sided diamond point are explicit geometric assumptions; microscopic ring profile is not fabricated.','metal':pack(metal),'bore_tool':pack(tool),'bore_fit_scope':'.0001in radial numerical clearance and .0001in axial overshoot; tool is an occupied-space construction subtraction, not a manufacturer-required pilot hole.','source':('Historical Simpson manufacturer C-F-2017p117; current procurement unconfirmed.' if sku=='T20SNDB' else 'Simpson Type316 shake/shingle siding nail manufacturer product table.')}
    instances=[];tools=[];equivalence=[];maxdiff=0.;proto_basis=basis([0,0,1])
    for i,n in enumerate(nails):
        B=basis(n['outward_normal']);R=B@proto_basis.T;t=np.array(n['head_in'])*I
        matrix=np.eye(4);matrix[:3,:3]=R;matrix[:3,3]=t;column_major=matrix.T.reshape(-1).tolist()
        # The independent physical reference is generated directly at the
        # actual head/axis, rather than borrowing the placement transform.
        direct_metal,direct_tool=nail_shapes(n)
        T=np.column_stack([R,np.array(n['head_in'])]);proto_metal,proto_tool=refs[n['sku']]
        metal=proto_metal.transform(T.tolist());tool=proto_tool.transform(T.tolist())
        md=max(0.,(metal-direct_metal).volume())+max(0.,(direct_metal-metal).volume());td=max(0.,(tool-direct_tool).volume())+max(0.,(direct_tool-tool).volume());maxdiff=max(maxdiff,md,td)
        
        # Coincident Boolean subtraction can return sliver diagnostics even
        # for identical coordinate sets; compare the actual rigid vertices.
        av=np.asarray(tool.to_mesh64().vert_properties)[:,:3];bv=np.asarray(direct_tool.to_mesh64().vert_properties)[:,:3];hd=max(float(cKDTree(av).query(bv)[0].max()),float(cKDTree(bv).query(av)[0].max()));vd=abs(tool.volume()-direct_tool.volume())
        am=np.asarray(metal.to_mesh64().vert_properties)[:,:3];bm=np.asarray(direct_metal.to_mesh64().vert_properties)[:,:3];mhd=max(float(cKDTree(am).query(bm)[0].max()),float(cKDTree(bm).query(am)[0].max()));mvd=abs(metal.volume()-direct_metal.volume())
        assert max(hd,mhd)<=1e-8 and max(vd,mvd)<=TOL,(n['id'],mhd,hd,mvd,vd)
        row={'id':n['id'],'parent_id':n['owner'],'prototype_id':n['sku'],'product':n['sku'],'role':n['role'],'roof':n['roof'],'course':n['course'],'world_matrix_column_major':column_major,'outward_axis_world':unit(n['outward_normal']).tolist(),'withdrawal_translation_m':(unit(n['outward_normal'])*(n['length_in']+1)*I).tolist(),'ray_receipts':n['rays'],'CSSB_receipt':n['deck_penetration'],'bore_tool_id':'CUT-'+n['id'],'actual_bore_hosts':hosts[n['id']],'procurement_scope':n.get('procurement_scope','Current manufacturer product; verify project purchasing selection.')}
        instances.append(row);tools.append({'id':'CUT-'+n['id'],'nail_id':n['id'],'prototype_id':n['sku'],'geometry_field':'bore_tool','world_matrix_column_major':column_major,'actual_receiver_ids':[x['host_id'] for x in hosts[n['id']]],'compose_rule':'Apply to the fresh final receiving actor geometry by stable ID. Do not import an older bored framing snapshot over newer curb/joinery geometry.'})
        equivalence.append({'id':n['id'],'metal_coincident_boolean_diagnostic_in3':md,'metal_maximum_vertex_distance_in':mhd,'metal_volume_difference_in3':mvd,'tool_coincident_boolean_diagnostic_in3':td,'tool_maximum_vertex_distance_in':hd,'tool_volume_difference_in3':vd})
        if i%1000==0:print('INSTANCES',i,'of',len(nails),flush=True)
    dump(OUT/'nail-shared-prototypes.json',{'units':'meters','prototypes':prototypes})
    dump(OUT/'nail-instances.json.gz',{'units':'meters','matrix_layout':'Three.js column-major rigid4x4; determinant+1, no scaling.','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'instances':instances})
    dump(OUT/'nail-cutting-tool-instances.json.gz',{'scope':'Separate prototype geometry and placement for fresh final roof receiver bores; individual fastener and host IDs remain itemized.','tools':tools})
    dump(OUT/'nail-prototype-equivalence.json.gz',{'status':'PASS','count':len(nails),'tolerance_in3':TOL,'maximum_coincident_boolean_diagnostic_in3':maxdiff,'maximum_vertex_tolerance_in':1e-8,'equivalence_method':'Every metal/tool rigidly transformed vertex set and volume checked against independently generated placement. CoincidentBoolean diagnostics are retained, not used as geometry changes.','checks':equivalence})
    print('PASS',len(nails),'maxdiff',maxdiff,flush=True)
if __name__=='__main__':run()
