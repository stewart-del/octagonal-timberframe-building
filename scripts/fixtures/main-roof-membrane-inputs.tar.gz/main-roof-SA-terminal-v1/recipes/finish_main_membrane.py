"""Bounded physical finalization of actual main hips and porch ridge.
All stock dimensions unchanged. Explicit symmetric hip-cut recipe and
single-piece folded ridge replace numerical CSG-only boundary failures.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps'),'/workspace/sites/octagonal-timberframe-building/scripts']
from roof_physical_layers import *
from roof_heightfield_boundary import refined_sheet
from roof_filtered_support import bounded_surface_support
from closed_roof_envelope import closed_roof_record
from shapely.affinity import affine_transform
OUT=D/'roof-physical-layers-candidate'
def run():
 p=OUT/'main-membrane-checkpoint.json.gz';data=read(p);by={q['id']:q for q in data['parts']};issues=[];receipts=[]
 if by['VDSA-MAIN-HIP-3']['raw_mesh_status']!='PASS':
  f=frame_main(2);n=f['N'];rot=2*np.outer(n,n)-np.eye(3);rot[1,:]=[0,1,0];rot[:,1]=[0,1,0];ss=shape(by['VDSA-MAIN-HIP-2']).transform(np.column_stack([rot,np.zeros(3)]).tolist());q,ss,r=closed_roof_record(ss);old=shape(by['VDSA-MAIN-HIP-3']);delta=max(0.,(old-ss).volume())+max(0.,(ss-old).volume());by['VDSA-MAIN-HIP-3']={**by['VDSA-MAIN-HIP-3'],**q,'raw_mesh_status':'PASS','selected_symmetric_cut_recipe':{'reflect_source':'VDSA-MAIN-HIP-2','reflection_normal_world':n.tolist(),'selected_shape_change_in3':delta,'scope':'Actualfieldcuttemplatechange, notanauditor/tolerancechange; physicalcontactsandlapsrechecked.'},'boundary_receipt':r};receipts.append({'id':'VDSA-MAIN-HIP-3','recipe':'Actualreflectedleftvalleyhipcuttemplate','occupied_difference_from_prior_in3':delta});print('HIP3_PASS',delta,flush=True)
 # Two real roof facets with explicit finite bend transitions over the
 # actual SA laps, joined by a short matching ridge-bridge heel. No
 # perfectlysharp25mil step is passedoffas two edge-touching sheets.
 from roof_bridge_envelope import gently_bridged_sheet
 from roof_heightfield_sheet import top_faces
 porch=read(D/'whole-roof-cedar/porch-source.json');pf=make_faces([],[],porch)[8:10];underparts=[q for q in by.values() if q['id'].startswith(('VDSA-PORCH','VDSA-VALLEY')) and not q['id'].startswith('VDSA-PORCH-RIDGE')];prepared=[];maxheight=0.
 for f in pf:
  dom=unary_union([roof_top_region(q,f) for q in underparts]);lo,smin,hi,smax=dom.bounds;dom=unary_union([dom,geotranslate(dom,yoff=.6)]).intersection(box(lo,smax-12.,hi,smax+.6));under=[tolocal(shape(q),f) for q in underparts];prepared.append((f,dom,under,smax))
  for ss in under:
   for pp in top_faces(ss,min_cosine=.99999):
    clip=pp['polygon'].intersection(dom)
    for ppoly in pieces(clip):
     if not ppoly.is_empty:maxheight=max(maxheight,max(height(pp['plane'],z) for z in np.asarray(ppoly.exterior.coords)))
 heel=math.ceil(maxheight*1000.)/1000.;print('RIDGE_HEEL',heel,flush=True);leaves=[];bend=[]
 for f,dom,under,smax in prepared:
  ss,br=gently_bridged_sheet(dom,under,.025,grid_in=1.,heel_region=box(-1000.,smax-.75,1000.,smax+.6),heel_height_in=heel,top_options={'min_cosine':.99999});leaves.append(toworld(ss,f,fold_ridge=True));bend.append(br)
 ss=m.Manifold.batch_boolean(leaves,m.OpType.Add);q,ss,r=closed_roof_record(ss)
 for pid in list(by):
  if pid.startswith('VDSA-PORCH-RIDGE'):del by[pid]
 by['VDSA-PORCH-RIDGE']={'id':'VDSA-PORCH-RIDGE','material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier','kind':'folded_ridge_icebarrier','nominal_roof_normal_gauge_in':.025,'parentStockId':'CUT-VDSA-PORCH-RIDGE','face_lap_in':12.,'selected_finite_bend_receipts':bend,'selected_ridge_center_bridge_above_deck_normal_in':heel,'raw_mesh_status':'PASS','boundary_receipt':r,'profile_scope':'Oneactual25in cut with12in legs. Explicitshortfinitebendbridges over actual25mil lapedges; nominalroof-normalgauge is.025in, transitionnormal-gaugevariation quantified inbend receipts. No factorybendradius/adhesion/weathercapacityapprovalclaimed.',**q};print('RIDGE_PASS',ss.volume(),flush=True)
 for cut in data['stock']:
  if cut['id']=='CUT-VDSA-PORCH-RIDGE':cut['installed_ids']=['VDSA-PORCH-RIDGE'];cut['blank_length_in']=max(dom.bounds[2]-dom.bounds[0] for _,dom,_,_ in prepared)+.5
 data['parts']=list(by.values());data['issues']=[];data['terminal_boundary_recipe_receipts']=receipts
 dump(p,data);dump(OUT/'main-membrane-terminal-boundary-receipts.json',{'status':'PASS','receipts':receipts,'ridge_raw_receipt':r});print('DONE',len(by),flush=True)
if __name__=='__main__':run()
