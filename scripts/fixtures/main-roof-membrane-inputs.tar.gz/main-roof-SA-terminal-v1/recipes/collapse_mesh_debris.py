"""Collapse only tiny-facet edges, with unchanged occupied-volume threshold."""
import numpy as np,manifold3d as m
from cupola_candidate import native_solid,I

def collapse_tiny(record,tolerance_in3=1e-6,maximum_edge_m=1e-5,max_iterations=150):
 source=native_solid(record);v=np.array(record['vertices']);t=np.array(record['triangles'],dtype=np.uint64);steps=[]
 for iteration in range(max_iterations):
  a=np.linalg.norm(np.cross(v[t[:,1]]-v[t[:,0]],v[t[:,2]]-v[t[:,0]]),axis=1)/2;bad=np.flatnonzero(a<=1e-12)
  if not len(bad):break
  edges=sorted({tuple(sorted((int(q[i]),int(q[(i+1)%3])))) for q in t[bad] for i in range(3)},key=lambda e:np.linalg.norm(v[e[0]]-v[e[1]]));chosen=None
  for i,j in edges:
   if np.linalg.norm(v[i]-v[j])>maximum_edge_m:continue
   for keep,drop in [(i,j),(j,i)]:
    tt=t.copy();tt[tt==drop]=keep;tt=tt[np.array([len(set(q))==3 for q in tt])]
    q={'vertices':v.tolist(),'triangles':tt.tolist()};s=native_solid(q)
    if str(s.status())!='Error.NoError':continue
    delta=max(0.,(s-source).volume())+max(0.,(source-s).volume())
    if delta>tolerance_in3*I**3:continue
    chosen=(tt,keep,drop,delta);break
   if chosen:break
  assert chosen,('No topology-preserving tiny-facet edge collapse',len(bad),float(a.min()))
  t,keep,drop,delta=chosen;steps.append({'kept_vertex':keep,'removed_vertex':drop,'occupied_difference_in3':delta/I**3})
 else:raise AssertionError('Tiny-facet collapse did not converge')
 used=np.unique(t);index=np.full(len(v),-1,dtype=int);index[used]=np.arange(len(used));q={'vertices':v[used].tolist(),'triangles':index[t].tolist()};s=native_solid(q);assert str(s.status())=='Error.NoError';q['volume_m3']=s.volume();return q,steps
