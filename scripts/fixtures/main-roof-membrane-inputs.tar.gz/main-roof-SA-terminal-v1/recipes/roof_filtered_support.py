"""Physical top-surface selection for a specific roof sheet.
A different roof or a tall vertical valley web is not a bearing surface
for a sheet remaining on this roof. Copper's real positive sidefaces are
retained to fit its edge, then clipped to the bounded local stack band.
"""
import sys
sys.dont_write_bytecode=True
from roof_heightfield_sheet import *

def bounded_surface_support(solids,domain,min_cosine=.99999,zmin=-.0001,zmax=.5):
 groups={}
 def clip(poly,plane,level,sign):
  src=list(np.asarray(poly.exterior.coords)[:-1]);out=[]
  for a,b in zip(src,src[1:]+src[:1]):
   da=sign*(height(plane,a)-level);db=sign*(height(plane,b)-level);ina=da>=-1e-10;inb=db>=-1e-10
   if ina:out.append(a)
   if ina!=inb:out.append(a+(b-a)*(da/(da-db)))
  return Polygon(out) if len(out)>=3 else Polygon()
 for s in solids:
  for patch in top_faces(s,min_cosine=min_cosine,min_height=zmin,max_height=zmax):
   p=clip(clip(patch['polygon'],patch['plane'],zmin,1),patch['plane'],zmax,-1).intersection(domain)
   if p.is_empty or p.area<1e-10:continue
   key=tuple(np.round(patch['plane'],8));groups.setdefault(key,[]).append(p)
 result=[]
 for key,polys in groups.items():
  for p in components(set_precision(unary_union(polys),1e-6)):
   if p.area>1e-10:result.append(prism(p,[0,0,zmin-.1],np.asarray(key)))
 return result
