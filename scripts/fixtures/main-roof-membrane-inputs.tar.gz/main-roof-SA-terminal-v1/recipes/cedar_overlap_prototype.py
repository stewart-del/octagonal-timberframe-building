#!/usr/bin/env python3
"""Read-only research prototype. Inches throughout; no repository imports/edits.

Rigid 18-inch taper placement with a planar lower face. Analytic upper support
planes, followed by independent solid intersections. Cap pairs use physical
orthonormal stock frames, alternate edge ownership, and collision seating.
This is a repeatable local geometry experiment, not a completed roof design.
"""
from pathlib import Path
import json, math
import numpy as np
from scipy.optimize import minimize_scalar
import manifold3d as m
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

OUT=Path(__file__).resolve().parent
L=18.0
EXPOSURE=5.5
BUTT=.45  # CSSB five butts = 2.25 inches; uniform prototype choice.
TIP=.0625 # Explicit unsourced mill-profile assumption, not a CSSB rule.
FELT=.04  # Explicit placeholder, replace with selected actual product.
VENT=.285 # Current Benjamin Obdyke Cedar Breather product thickness.
PLY=.75  # True-thickness generic plywood experiment; GP .703 cannot give .75 wood.
BASE=FELT+VENT
TOL=2e-7 # cubic inches; does not redefine repository tolerances.

def clip_x(poly, lo, hi):
    out=[np.array(p,float) for p in poly]
    for bound,side in [(lo,1),(hi,-1)]:
        inp,out=out,[]
        if not inp:break
        for p,q in zip(inp,inp[1:]+inp[:1]):
            a,b=side*(p[0]-bound),side*(q[0]-bound)
            if a>=0:out.append(p)
            if a*b<0:out.append(p+(q-p)*(-a)/(b-a))
    return out

def quad(start,b,theta):
    d=np.array([math.cos(theta),-math.sin(theta)])
    n=np.array([math.sin(theta),math.cos(theta)])
    p=np.array([start,b])
    return np.array([p,p+L*d,p+L*d+TIP*n,p+BUTT*n])

def supported(start,prior):
    """Minimize mean lower-plane height subject to every prior vertex below it.

    The lower edge is exactly L inches long; its roof-plane projection is shorter.
    Constraints include clipped polygon intersections, not only regular samples.
    """
    def required(theta):
        xmax=start+L*math.cos(theta)+BUTT*math.sin(theta)
        pts=[np.array([start,BASE]),np.array([xmax,BASE])]
        for p in prior:pts.extend(clip_x(p,start,xmax))
        b=max(v[1]+math.tan(theta)*(v[0]-start) for v in pts)
        return b
    def objective(theta):return required(theta)-.5*L*math.sin(theta)
    angles=np.linspace(0,.13,131)
    k=min(range(len(angles)),key=lambda i:objective(angles[i]))
    lo,hi=angles[max(0,k-1)],angles[min(len(angles)-1,k+1)]
    fit=minimize_scalar(objective,bounds=(lo,hi),method='bounded',options={'xatol':1e-13})
    theta=float(fit.x)
    return quad(start,required(theta),theta),theta

def prism(poly,width=6):
    pts=[[float(x),y,float(z)] for y in [0,width] for x,z in poly]
    return m.Manifold.hull_points(pts)

def top_at(poly,theta,station):
    # station is distance along the actual 18-inch lower face from its butt.
    p=poly[0]+station*np.array([math.cos(theta),-math.sin(theta)])
    t=BUTT+(TIP-BUTT)*station/L
    return p+t*np.array([math.sin(theta),math.cos(theta)])

def nail_info(poly,theta,station,length):
    p=top_at(poly,theta,station)
    # Nail normal to the actual sloping upper face, including the sawn taper.
    phi=theta+math.atan((BUTT-TIP)/L)
    nz=math.cos(phi)
    distance=float(p[1]/nz)
    return {'head_height_above_plywood_in':float(p[1]),
            'distance_to_plywood_along_nail_in':distance,
            'available_length_after_top_of_plywood_in':length-distance,
            'wood_segment_length_in':min(max(0,length-distance),PLY/nz),
            'full_plywood_traversed':length>=distance+PLY/nz,
            'nail_length_in':length,'nail_station_from_butt_in':station}

def cap_leaf(start,b,theta,beta,side,cross0,cross1):
    # Orthonormal exact stock frame: v is along ridge/hip, u across roof face.
    cross=np.array([0,side*math.cos(beta),-math.sin(beta)])
    face_n=np.array([0,side*math.sin(beta),math.cos(beta)])
    along=np.array([math.cos(theta),0,0])-math.sin(theta)*face_n
    normal=np.array([math.sin(theta),0,0])+math.cos(theta)*face_n
    origin=np.array([start,0,0])+b*face_n
    pts=[]
    for u in [cross0,cross1]:
        for v,t in [(0,0),(L,0),(L,TIP),(0,BUTT)]:
            pts.append(origin+u*cross+v*along+t*normal)
    return m.Manifold.hull_points(pts),{'origin':origin.tolist(),'along':along.tolist(),
           'cross':cross.tolist(),'normal':normal.tolist(),'theta':theta,
           'side':side,'beta':beta,'start':start,'b':b}

def pair(start,b,theta,beta,parity):
    # Site-made edge lap: one leaf extends .25 in across the nominal seam;
    # trim the receiving leaf to the cover leaf, exactly. No positive joint volume.
    cover_side=1 if parity%2==0 else -1
    a,fa=cap_leaf(start,b,theta,beta,cover_side,-.25,4.5)
    raw,fb=cap_leaf(start,b,theta,beta,-cover_side,0,4.5)
    return [(a,fa),(raw-a,fb)]

def union_all(parts):
    out=m.Manifold()
    for p in parts:out=out+p
    return out

def pack(s):
    mesh=s.to_mesh64()
    return {'vertices_in':np.asarray(mesh.vert_properties)[:,:3].tolist(),
            'triangles':np.asarray(mesh.tri_verts).tolist(),'volume_in3':s.volume()}

def cap_nail(frame,station,length):
    p=np.array(frame['origin'])+2*np.array(frame['cross'])
    p+=station*np.array(frame['along'])
    p+=(BUTT+(TIP-BUTT)*station/L)*np.array(frame['normal'])
    a=math.atan((BUTT-TIP)/L)
    upper_n=math.sin(a)*np.array(frame['along'])+math.cos(a)*np.array(frame['normal'])
    beta=frame['beta'];side=frame['side']
    deck_n=np.array([0,side*math.sin(beta),math.cos(beta)])
    nz=float(np.dot(upper_n,deck_n))
    distance=float(np.dot(p,deck_n)/nz)
    return {'head_xyz_in':p.tolist(),'outward_normal':upper_n.tolist(),
            'distance_to_plywood_along_nail_in':distance,
            'available_length_after_top_of_plywood_in':length-distance,
            'wood_segment_length_in':min(max(0,length-distance),PLY/nz),
            'full_plywood_traversed':length>=distance+PLY/nz,
            'nail_length_in':length,'nail_station_from_butt_in':station}

def run():
    profiles=[];angles=[];field=[]
    starter=quad(0,BASE,0);profiles.append(starter);angles.append(0)
    for j in range(14):
        p,t=supported(j*EXPOSURE,profiles)
        profiles.append(p);angles.append(t)
    field=[prism(p) for p in profiles]
    overlaps=[]
    for i,a in enumerate(field):
        for j in range(i):
            v=(a^field[j]).volume()
            if v>TOL:overlaps.append([i,j,v])
    lengths=[float(np.linalg.norm(p[1]-p[0])) for p in profiles]
    field_nails=[nail_info(p,t,EXPOSURE+1.5,2.25) for p,t in zip(profiles,angles)]
    # A local V-shaped cap test patch. Field courses are longitudinal in this
    # synthetic test; actual roof integration must feed actual field solids.
    cap_results={};cap_mesh=[]
    for label,beta in [('main_hip',math.atan((1/3)*math.tan(math.pi/8)/math.sqrt(1+(1/3)**2))),
                       ('porch_ridge',math.atan(1/3))]:
        base_parts=[]
        for p,t in zip(profiles,angles):
            for side in [-1,1]:
                s,_=cap_leaf(float(p[0][0]),float(p[0][1]),t,beta,side,0,5)
                base_parts.append(s)
        occupied=union_all(base_parts)
        pieces=[];infos=[];pair_overlaps=[];support_overlaps=[]
        # Six cap courses incl a same-position cap starter pair.
        for k,start in enumerate([0,0,5.5,11,16.5,22]):
            theta=angles[min(k+1,len(angles)-1)]
            def candidate(b):return pair(start,b,theta,beta,k)
            def collision(b):return sum((p^occupied).volume() for p,f in candidate(b))
            low,high=BASE,BASE+6
            while collision(high)>TOL:high+=2
            # Search from a known clear placement downward; collision windows
            # are contiguous around supporting surfaces for this local patch.
            lo=high
            while lo>low and collision(lo)<=TOL:lo-=.05
            if collision(lo)<=TOL:raise RuntimeError('No supporting contact found')
            hi=lo+.05
            for _ in range(40):
                mid=(lo+hi)/2
                if collision(mid)>1e-11:lo=mid
                else:hi=mid
            new=candidate(hi+1e-8)
            support_overlaps.extend((p^occupied).volume() for p,f in new)
            self_overlap=(new[0][0]^new[1][0]).volume()
            if self_overlap>TOL:pair_overlaps.append([k,self_overlap])
            for side_idx,(p,f) in enumerate(new):
                for old in pieces:
                    v=(p^old).volume()
                    if v>TOL:pair_overlaps.append([k,'prior_cap',v])
                n=cap_nail(f,EXPOSURE+2,3.5)
                infos.append(n)
                pieces.append(p)
                cap_mesh.append({'id':f'{label}_cap_{k}_{side_idx}',**pack(p)})
            occupied=occupied+union_all([p for p,f in new])
        cap_results[label]={'cross_slope_degrees':math.degrees(beta),'pair_count':6,
            'physical_leaf_count':12,'roof_attachment_nails_if_2_per_leaf':24,
            'maximum_positive_overlap_in3':max([v[-1] for v in pair_overlaps],default=0),
            'maximum_overlap_with_underlying_field_or_caps_in3':max(support_overlaps),
            'overlaps':pair_overlaps,'nail_checks_3_5_in':infos}
    fig,ax=plt.subplots(figsize=(14,5))
    for i,p in enumerate(profiles):
        ax.fill(p[:,0],p[:,1],alpha=.38,edgecolor='black',linewidth=.5)
        if i<8:ax.text(p[0,0]+.6,p[0,1]+.03,str(i),fontsize=8)
    ax.axhspan(-PLY,0,color='#cda66e',alpha=.7,label='True 0.750-in plywood')
    ax.axhspan(0,FELT,color='gray',alpha=.7,label='Felt .040-in placeholder')
    ax.axhspan(FELT,BASE,color='#89baba',alpha=.7,label='Cedar Breather .285 in')
    ax.set(xlim=(-1,45),ylim=(-.8,2.4),xlabel='Distance upslope on roof plane (in)',
           ylabel='Height above plywood (in)',title='Full 18-inch rigid tapers: starter + supported overlapping field courses')
    ax.legend(loc='upper right');fig.tight_layout();fig.savefig(OUT/'cedar-overlap-section.png',dpi=170)
    fig=plt.figure(figsize=(14,5))
    for i,label in enumerate(['main_hip','porch_ridge']):
        ax=fig.add_subplot(1,2,i+1,projection='3d')
        for j,p in enumerate(v for v in cap_mesh if v['id'].startswith(label)):
            verts=np.array(p['vertices_in']);tris=np.array(p['triangles'])
            ax.add_collection3d(Poly3DCollection(verts[tris],alpha=.85,
                facecolor=plt.cm.tab20(j%20),edgecolor=(.2,.15,.1,.5),linewidth=.2))
        ax.set(xlim=(0,42),ylim=(-5.5,5.5),zlim=(-2,4),xlabel='Along cap (in)',
               ylabel='Across cap (in)',zlabel='Height (in)',title=label.replace('_',' ').title())
        ax.set_box_aspect((42,11,8));ax.view_init(elev=25,azim=-65)
    fig.tight_layout();fig.savefig(OUT/'cedar-cap-pairs.png',dpi=170)
    result={'units':'inches','scope':'Local stock/overlap prototype; not whole-building roof certification',
        'assumptions':{'length':L,'exposure':EXPOSURE,'uniform_butt':BUTT,'assumed_tip':TIP,
          'assumed_felt':FELT,'published_vent_thickness':VENT,'generic_true_plywood_thickness':PLY},
        'selected_fasteners':{'field':{'sku':'T7SN7B','length_in':2.25,'shank_in':.092,
              'head_diameter_in':7/32,'material':'Type 316 stainless steel'},
           'cap_roof_attachment':{'sku':'T16SNDB','length_in':3.5,'shank_in':.120,
              'head_diameter_in':.25,'material':'Type 316 stainless steel'}},
        'field':{'physical_shingles':len(field),'two_nails_each':2*len(field),
          'full_lower_edge_lengths_in':lengths,'angles_degrees':[math.degrees(v) for v in angles],
          'positive_overlaps':overlaps,'nail_checks_2_25_in':field_nails,
          'highest_butt_top_above_plywood_in':max(float(p[3,1]) for p in profiles)},
        'caps':cap_results,
        'pass':not overlaps and all(abs(v-L)<1e-10 for v in lengths)
          and all(v['wood_segment_length_in']>=.75 for v in field_nails)
          and all(not c['overlaps'] and c['maximum_overlap_with_underlying_field_or_caps_in3']<TOL
             and all(v['wood_segment_length_in']>=.75
            for v in c['nail_checks_3_5_in']) for c in cap_results.values())}
    (OUT/'cedar-overlap-proof.json').write_text(json.dumps(result,indent=2)+'\n')
    (OUT/'cedar-overlap-local-meshes.json').write_text(json.dumps({'field':[
        {'id':f'field_{i}',**pack(p)} for i,p in enumerate(field)],'cap_leaves':cap_mesh})+'\n')
    print(json.dumps({'pass':result['pass'],'field_positive_overlaps':overlaps,
          'field_min_2_25in_wood_embed':min(v['wood_segment_length_in'] for v in field_nails),
          'field_max_distance_to_plywood':max(v['distance_to_plywood_along_nail_in'] for v in field_nails),
          'cap_max_distances':{k:max(v['distance_to_plywood_along_nail_in'] for v in c['nail_checks_3_5_in'])
             for k,c in cap_results.items()},'cap_overlaps':{k:c['overlaps'] for k,c in cap_results.items()}},indent=2))
    assert result['pass'],'Prototype assumptions failed; inspect proof JSON'

if __name__=='__main__':run()
