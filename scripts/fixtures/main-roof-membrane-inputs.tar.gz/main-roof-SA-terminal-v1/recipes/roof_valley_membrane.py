"""Actual three-facet valley icebarrier fitted to prior roof edge layers.
External prototype, inches. Stock and selected fold clearances explicit.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps')]
from roof_physical_layers import *
from roof_heightfield_sheet import top_faces
from shapely.geometry import mapping

def construct_valley(fr,mf,f,domains,initial,thickness=.025,developed_width=35.5):
 from roof_heightfield_boundary import refined_sheet
 Wp,Wm=f['W'],mf['W'];axis=np.asarray(fr['axis']);width=np.asarray(fr['outer_web_plane_normal']);c=fr['outer_web_plane_constant_in'];t0,t1=fr['axis_min_in'],fr['axis_max_in'];L=t1-t0
 O=np.linalg.solve(np.array([width,Wm,axis]),[c,float(Wm@mf['O']),t0]);upper=np.linalg.solve(np.array([width,Wp,axis]),[c,float(Wp@f['O']),t0]);h=float((upper-O)@Wp);leg=(developed_width-h)/2;out=unit(-width+(width@Wm)*Wm);R=np.column_stack([width,axis,Wp]);local=[s.transform(np.column_stack([R.T,-R.T@O]).tolist()) for s in initial.values()];mainlocal=[s.transform(np.column_stack([R.T,-R.T@O]).tolist()) for pid,s in initial.items() if 'MAIN' in pid or pid.startswith('CU-SADDLE-')];porchlocal=[s.transform(np.column_stack([R.T,-R.T@O]).tolist()) for pid,s in initial.items() if 'PORCH' in pid];bands={};zone_domains={}
 def tocommon(poly,rf):
  def loop(ring):
   uv=np.asarray(ring.coords);world=rf['O']+uv[:,0,None]*rf['U']+uv[:,1,None]*rf['S'];return (world-O)@R[:,:2]
  return unary_union([Polygon(loop(p.exterior),[loop(r) for r in p.interiors]) for p in pieces(poly)])
 for rf,vec,start,name in [(mf,out,O,'MAIN'),(f,width,upper,'PORCH')]:
  pts=[start+axis*u+vec*v for u in [0,L] for v in [0,leg]];dom=region(pts,rf).intersection(domains[rf['id']]);common=tocommon(dom,rf)
  if name=='MAIN':common=common.union(box(-.15,0,-thickness,L)).intersection(box(-1000,-1,-thickness,L+1))
  else:common=common.union(box(0,0,.50,L)).intersection(box(0,-1,1000,L+1))
  zone_domains[name]=common;bands[rf['id']]=region([start+axis*u+vec*v for u in [0,L] for v in [0,leg-6.]],rf)
 lowbase=np.array([-float(Wm@width)/float(Wm@Wp),0,0]);lowopts={'min_cosine':.00001,'min_height':-.2,'max_height':20.};highopts={'min_cosine':.00001,'min_height':h-.2,'max_height':h+.6};cells=[]
 for name,base,opts,gauge in [('MAIN',lowbase,lowopts,thickness/float(Wm@Wp)),('PORCH',np.array([0.,0.,h]),highopts,thickness)]:
  for q in support_cells(zone_domains[name],mainlocal if name=='MAIN' else porchlocal,base_plane=base,top_options=opts):cells.append({'polygon':q['polygon'],'bottom':q['plane'],'top':q['plane']+np.array([0,0,gauge])})
 webdom=box(-thickness,0,0,L);low=support_cells(webdom,mainlocal,base_plane=lowbase,top_options=lowopts);high=support_cells(webdom,porchlocal,base_plane=[0,0,h],top_options=highopts)
 for a in low:
  for b in high:
   for poly in pieces(a['polygon'].intersection(b['polygon'])):
    if poly.area>1e-10:cells.append({'polygon':poly,'bottom':a['plane'],'top':b['plane']+np.array([0,0,thickness])})
 try:ss=refined_sheet(cells,[])
 except AssertionError:ss=m.Manifold.batch_boolean([prism(q['polygon'],q['bottom'],q['top']) for q in cells],m.OpType.Add)
 ss=ss.transform(np.column_stack([R,O]).tolist());n=f['porch_side']*f['porch_basis']['U'];ss=ss.trim_by_plane(n.tolist(),float(n@f['porch_basis']['O']));ss=ss.trim_by_plane((-mf['N']).tolist(),-mf['qout']) # Valleyends at actual main eave, not a virtual extension. Porcheave starter/drip takes over.
 dump(D/'roof-physical-layers-candidate'/('valley-direct-debug-'+fr['side']+'.json'),{'solid':pack(ss),'components':[{'volume_in3':q.volume(),'bounds':[np.asarray(b).tolist() for b in bounds(q)]} for q in ss.decompose()],'cells':[{'polygon':mapping(q['polygon']),'bottom':q['bottom'].tolist(),'top':q['top'].tolist()} for q in cells]});return ss,{'developed_profile_width_in':developed_width,'blank_width_in':36.,'blank_length_in':L+.5,'roof_apron_in':leg,'actual_web_height_in':h,'actual_web_plane_constant_in':c,'piecewise_material_cells':len(cells),'web_bottom_cells':len(low),'web_top_cells':len(high),'stock_fold_allowance_in':.5,'fold_scope':'Single continuous material boundary: main and porch thicknesses along their actual normals, actual25mil vertical web, fitted actual prior-layer steps.'},bands
