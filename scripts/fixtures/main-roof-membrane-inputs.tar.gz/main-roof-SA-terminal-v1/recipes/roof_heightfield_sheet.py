"""Sparse exact planar support heightfields for flexible roofsheet envelopes.

Localcoordinates inches u,s,roofnormalz. Rightanglefoldprofiles aredeclared
grossenvelopes, not factorybendradius/fiberCAD. No source/auditor changes.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path[:0]=[str(HERE),str(HERE/'python-deps'),'/workspace/sites/octagonal-timberframe-building/scripts']
import numpy as np,manifold3d as m,math
from shapely.geometry import Polygon,MultiPolygon,LineString
from shapely.ops import unary_union,polygonize
from shapely.geometry.polygon import orient
from shapely import constrained_delaunay_triangles,set_precision
from regular_boundary_geos import regular_boundary_geos
from audit_cavity_fit import inspect_mesh
I=.0254
def components(p):
 if isinstance(p,Polygon):return[p]
 return [q for g in getattr(p,'geoms',[]) for q in components(g)]
def top_faces(s,min_cosine=.90,min_height=-1e-6,max_height=.5,flat_height_quantum=None,flat_support_clearance=1e-6):
 mm=s.to_mesh64();v=np.asarray(mm.vert_properties)[:,:3];t=np.asarray(mm.tri_verts);out=[]
 for tri in t:
  p=v[tri];n=np.cross(p[1]-p[0],p[2]-p[0]);ln=np.linalg.norm(n)
  if ln<1e-15 or n[2]/ln<min_cosine or max(p[:,2])<min_height or min(p[:,2])>max_height:continue
  poly=Polygon(p[:,:2]);a,b,c=-n[0]/n[2],-n[1]/n[2],float(n@p[0])/n[2]
  if poly.area<1e-8:continue
  # New construction heightfield support has an explicit1e-6in numerical
  # seating clearance. Canonicalize nearlyflat roofpatches so tiny serialized
  # coplanar triangles cannot manufacture thousands of false supportplanes.
  a=0. if abs(a)<1e-5 else round(float(a),8);b=0. if abs(b)<1e-5 else round(float(b),8)
  c=round(max(float(z-a*x-b*y) for x,y,z in p),6)+1e-6
  if flat_height_quantum is not None and a==0. and b==0.:c=round(c/flat_height_quantum)*flat_height_quantum+flat_support_clearance
  out.append({'polygon':poly,'plane':np.array([a,b,c])})
 return out
def height(plane,p):return float(np.dot(plane,[p[0],p[1],1]))
def prism(poly,bottom,top):
 # A direct triangulated planarwedge, withallholes andboundaryvertices.
 poly=orient(poly,sign=1.);loops=[np.asarray(poly.exterior.coords)[:-1]]+[np.asarray(r.coords)[:-1] for r in poly.interiors];verts=[];index={}
 def vertex(p,side):
  key=(round(float(p[0]),13),round(float(p[1]),13),side)
  if key not in index:index[key]=len(verts);verts.append([p[0],p[1],height(top if side else bottom,p)])
  return index[key]
 triangles=[]
 for tr in constrained_delaunay_triangles(poly).geoms:
  pts=np.asarray(tr.exterior.coords)[:3];a=[vertex(p,0) for p in pts];b=[vertex(p,1) for p in pts]
  if np.cross(np.r_[pts[1]-pts[0],0.],np.r_[pts[2]-pts[0],0.])[2]<0:a=a[::-1];b=b[::-1]
  triangles.extend([a[::-1],b])
 for loop in loops:
  for a,b in zip(loop,np.roll(loop,-1,axis=0)):
   aa,bb,cc,dd=vertex(a,0),vertex(b,0),vertex(b,1),vertex(a,1);triangles.extend([[aa,bb,cc],[aa,cc,dd]])
 result=m.Manifold(m.Mesh64(np.asarray(verts),np.asarray(triangles,np.uint64)));assert str(result.status())=='Error.NoError',str(result.status());return result
def support_cells(domain,supports,base_plane=None,top_options=None):
 domain=set_precision(domain,1e-9);planes=[];boundaries=[domain.boundary];groups={}
 for s in supports:
  for p in top_faces(s,**(top_options or {})):
   clipped=set_precision(p['polygon'].intersection(domain),1e-9)
   if clipped.is_empty or clipped.area<1e-12:continue
   key=tuple(np.round(p['plane'],8));groups.setdefault(key,[]).append(clipped)
 for key,polys in groups.items():
  merged=unary_union(polys);p={'polygon':merged,'plane':np.asarray(key)};planes.append(p);boundaries.append(merged.boundary)
 # A patch boundary alone is insufficient: two overlapping affine roofs
 # can cross inside the overlap. Node every actualplane equality segment
 # before selecting the max, so a representativepoint never hides a higher
 # receiving surface elsewhere in the same cell.
 allplanes=[{'polygon':domain,'plane':np.asarray(base_plane if base_plane is not None else[0.,0.,0.])}]+planes
 for i,a in enumerate(allplanes):
  for b in allplanes[i+1:]:
   d=a['plane']-b['plane'];normal=d[:2];nn=float(normal@normal)
   if nn<1e-20:continue
   overlap=a['polygon'].intersection(b['polygon'])
   if overlap.is_empty or overlap.area<1e-10:continue
   x0,y0,x1,y1=overlap.bounds;center=np.array([(x0+x1)/2,(y0+y1)/2]);on=center-normal*(float(normal@center)+d[2])/nn;direction=np.array([-normal[1],normal[0]])/math.sqrt(nn);length=math.hypot(x1-x0,y1-y0)+1.;line=LineString([on-direction*length,on+direction*length]).intersection(overlap)
   if not line.is_empty:boundaries.append(line)
 cells=[]
 for p in polygonize(unary_union(boundaries)):

  rp=p.representative_point()
  if not domain.covers(rp) or p.area<1e-10:continue
  point=[rp.x,rp.y];options=[{'plane':np.asarray(base_plane if base_plane is not None else [0.,0.,0.])}]+[q for q in planes if q['polygon'].covers(rp)];plane=max(options,key=lambda q:height(q['plane'],point))['plane'] if options else np.array([0.,0.,0.]);cells.append({'polygon':orient(p,sign=1.),'plane':plane})
 return cells
def sheet(domain,supports,thickness=.025,label='sheet',top_options=None):
 cells=support_cells(domain,supports,top_options=top_options);solids=[];edges={};jumps=[];patches=[]
 for i,c in enumerate(cells):
  p=c['polygon'];lo=c['plane'];hi=lo+np.array([0,0,thickness]);solids.append(prism(p,lo,hi))
  for ring in [p.exterior]+list(p.interiors):
   v=np.asarray(ring.coords)
   for a,b in zip(v[:-1],v[1:]):
    ka=tuple(np.round(a,9));kb=tuple(np.round(b,9));key=tuple(sorted([ka,kb]));edges.setdefault(key,[]).append((i,a,b))
 for key,items in edges.items():
  if len(items)!=2:continue
  (ia,a,b),(ib,_,_)=items;mid=(a+b)/2;ha=height(cells[ia]['plane'],mid);hb=height(cells[ib]['plane'],mid)
  if abs(ha-hb)<1e-8:continue
  low,high=(ia,ib) if ha<hb else(ib,ia);entry=next(x for x in items if x[0]==low);a,b=entry[1:];d=b-a;n=np.array([-d[1],d[0]])/np.linalg.norm(d);fold=Polygon([a,b,b+n*thickness,a+n*thickness]).intersection(cells[low]['polygon']);lower=cells[low]['plane'];upper=cells[high]['plane']+np.array([0,0,thickness])
  for p in components(fold):
   if p.is_empty or p.area<1e-12:continue
   solids.append(prism(p,lower,upper));patches.append({'polygon':p,'top':upper})
  jumps.append({'a':a.tolist(),'b':b.tolist(),'height_jump_in':abs(ha-hb),'fold_plan_width_in':thickness})
 from roof_heightfield_boundary import refined_sheet
 try:result=refined_sheet([{'polygon':c['polygon'],'bottom':c['plane'],'top':c['plane']+np.array([0,0,thickness])} for c in cells],patches)
 except AssertionError:result=m.Manifold.batch_boolean(solids,m.OpType.Add)
 mm=result.scale([I]*3);a=inspect_mesh(np.asarray(mm.to_mesh64().vert_properties)[:,:3],np.asarray(mm.to_mesh64().tri_verts,np.uint64),require_single=False);cleanup=0.
 if a['status']!='PASS':
  try:
   clean=regular_boundary_geos(mm);cleanup=(max(0.,(clean-mm).volume())+max(0.,(mm-clean).volume()))/I**3;result=clean.scale([1/I]*3);a=inspect_mesh(np.asarray(clean.to_mesh64().vert_properties)[:,:3],np.asarray(clean.to_mesh64().tri_verts,np.uint64),require_single=False)
  except Exception as e:a={**a,'cleanup_failure':str(e)}
 return result,{'label':label,'status':a['status'],'audit':a,'cells':len(cells),'folds':jumps,'cleanup_difference_in3':cleanup,'profile_scope':'Rightanglethin-sheetfoldgrossenvelope, exactfactoryradiusunverified.'}
