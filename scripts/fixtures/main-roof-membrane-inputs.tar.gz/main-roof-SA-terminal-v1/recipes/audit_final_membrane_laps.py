"""Independent actual panel-edge/course-lap and fixed-roll takeoff audit."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps')]
from roof_physical_layers import *
import hashlib

def run():
 root=D/'roof-physical-layers-candidate';data=read(root/'main-membrane-checkpoint.json.gz');source=data['parts'];kept=[q for q in source if not q['id'].startswith('VDSA-CUP')];ids={q['id'] for q in kept};ds=read(D/'roof-sheathing-curb-candidate/roof-sheathing-parts.json')['parts'];pd=read(D/'porch-roof-support-candidate/revised-porch-decks.json')['parts'];faces=make_faces(ds,read(D/'roof-sheathing-curb-candidate/roof-sheathing-collar-reliefs.json')['reliefs'],read(D/'whole-roof-cedar/porch-source.json'));rows=[];fail=[]
 for f in faces:
  parts=[q for q in ds if q['roof_face']==f['face']] if f['id'].startswith('MAIN') else[q for q in pd if q['roof']==f['id']];edges=[]
  for panel in parts:
   regions=roof_top_region(panel,f)
   for poly in pieces(regions):
    for ring in [poly.exterior]+list(poly.interiors):
     uv=np.asarray(ring.coords)
     for a,b in zip(uv[:-1],uv[1:]):
      if abs(a[1]-b[1])<1e-6 and abs(a[0]-b[0])>1 and .5<(a[1]+b[1])/2<f['height']-.5:edges.append({'panel':panel['id'],'s_in':float((a[1]+b[1])/2),'u_interval_in':sorted([float(a[0]),float(b[0])])})
  for strip in data['lapreceipts']:
   if strip.get('roof')!=f['id']:continue
   stations=[]
   if strip['horizontal_lap_in'] is not None:stations.append(('lower_overlap_edge',strip['s0_in']))
   if strip['s1_in']<f['height']-1:stations.append(('upper_overlap_edge',strip['s1_in']))
   for kind,s in stations:
    if not edges:continue
    near=min(edges,key=lambda q:abs(q['s_in']-s));distance=abs(near['s_in']-s);row={'roof':f['id'],'strip':strip['id'],'edge':kind,'station_s_in':s,'closest_parallel_plywood_joint':near,'parallel_joint_offset_in':distance};rows.append(row)
    if distance<1e-6:fail.append(row)
 # Every physical split piece retains its single actualstockcut parent.
 cuts=[dict(c) for c in data['stock'] if any(pid in ids for pid in c.get('installed_ids',[]))];starters=read(D/'roof-eave-starter-candidate/parts.json')['parts'];starters=[q for q in starters if 'CUP' not in q['id']];starterids={q['id'] for q in starters};cuts += [dict(c) for c in read(D/'roof-eave-starter-candidate/stock.json')['cuts'] if c['id'][4:] in starterids]
 rolls=[];badstock=[]
 for cut in sorted(cuts,key=lambda q:-q['blank_length_in']):
  cut['product']='VaporDry SA';cut['roll_width_in']=57.;cut['roll_length_in']=960.
  if cut['blank_width_in']>57+1e-8 or cut['blank_length_in']>960+1e-8:badstock.append(cut['id'])
  options=[r for r in rolls if r['used_length_in']+cut['blank_length_in']<=960+1e-8];r=min(options,key=lambda q:960-q['used_length_in']) if options else None
  if r is None:r={'id':f'ROLL-VDSA-MAINPORCH-{len(rolls)+1:02d}','dimensions_in':[57.,960.,.025],'used_length_in':0.,'cut_ids':[]};rolls.append(r)
  cut['parentRollId']=r['id'];cut['start_length_in']=r['used_length_in'];cut['unreused_rip_offcut_width_in']=57-cut['blank_width_in'];r['cut_ids'].append(cut['id']);r['used_length_in']+=cut['blank_length_in']
 for r in rolls:r['end_offcut_length_in']=960-r['used_length_in']
 report={'status':'PASS' if not fail and not badstock else'BLOCKED','main_porch_SA_parts':len(kept),'main_porch_starter_parts':len(starters),'lap_minimum_projected_horizontal_in':4.,'required_end_lap_in':6.,'field_end_joints':0,'end_joint_scope':'Eachfullcoursecutisfarshorterthan80ftroll. Cutoutsaroundactualwoodfeet areflashingterminations, notexposedbuttjointseams. Hip/ridge/cornerfoldlapsarespecificcustomdetails, notautomaticmanufacturerassemblyapproval.','panel_joint_rows':rows,'parallel_collinear_failures':fail,'minimum_parallel_joint_offset_in':min([q['parallel_joint_offset_in'] for q in rows] or[0]),'bad_stock_cuts':badstock,'takeoff_scope':'Conservativefull57inwidthallocationpercutevenwhenrippednarrow; no unprovenripnestingreuse. Stockparentsitemizeallsplitphysicalpieces. CupolafrozenSA/roofseparate.','source_sha256':hashlib.sha256((root/'main-membrane-checkpoint.json.gz').read_bytes()).hexdigest(),'ice_barrier_source':'https://benjaminobdyke.com/wp-content/uploads/2024/02/2024-VDSA-IRC-Compliance-Tech-Bulletin.pdf','qualification':'ManufacturerAC48icebarrierapproval+ASTMD1970nailsealtest; notanunsupportedfullASTMD1970bituminouscertificationclaim. Productcedar+CedarBreatherguidepublished; customcompoundjunctionadhesion/radius/siteweathercapacityunqualified.'};dump(root/'independent-final-lap-stock-audit.json',report);dump(root/'main-porch-SA-stock-rolls.json',{'cuts':cuts,'rolls':rolls,'roll_count':len(rolls),'stock_product':'VaporDry SA25mil57inx80ft','source_sha256':report['source_sha256']});print('DONE',report['status'],'parts',len(kept),'starters',len(starters),'rolls',len(rolls),'minimum_joint_offset',report['minimum_parallel_joint_offset_in'],flush=True)
if __name__=='__main__':run()
