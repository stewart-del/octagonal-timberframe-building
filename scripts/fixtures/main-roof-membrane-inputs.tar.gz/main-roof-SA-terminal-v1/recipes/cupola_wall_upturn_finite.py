"""Actual fixed-stock cupwall flashings with finite bends at lap steps.
Eight L base sheets plus eight12in-per-side corner patches; roof legs use
short explicit flexible bridges, not zero-radius edge-touching solids.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps'),'/workspace/sites/octagonal-timberframe-building/scripts']
from roof_physical_layers import *
from roof_bridge_envelope import gently_bridged_sheet
from roof_heightfield_sheet import top_faces
from cupola_wall_upturns import planpiece,coverage,Q,H,T
from closed_roof_envelope import closed_roof_record
OUT=D/'cupola-wall-finite-bend-candidate';OUT.mkdir(exist_ok=True)
def run():
 source=D/'roof-physical-layers-candidate/main-membrane-checkpoint.json.gz';raw=read(source);base=[q for q in raw['parts'] if q['id'].startswith('VDSA-MAIN')];saddles=[q for q in read(D/'air-boundary-candidate/air-boundary-parts.json.gz')['parts'] if q['id'].startswith('CU-SADDLE-')];support={q['id']:shape(q) for q in base+saddles};records=[];stocks=[];issues=[]
 for k in range(16):
  if k<8:layout=[(k,-H,H)];layer=0;pid=f'VDSA-CUPWALL-UPTURN-{k}';length=40.
  else:h=k-8;layout=[(h,H-12,H),((h-1)%8,-H,-H+12)];layer=1;pid=f'VDSA-CUPWALL-CORNER-{h}';length=28.
  qi=Q+layer*T+(.0001 if layer else 0.);prepared=[];maximum=0.;bodyplans=[]
  for j,lo,hi in layout:
   f=frame_main(j);tl=lo if lo>-H+1e-8 else -100.;th=hi if hi<H-1e-8 else 100.;bodyplans.append(planpiece(j,qi,qi+T,tl,th));plan=planpiece(j,qi-.1,qi+4/f['gamma'],tl,th);xz=np.asarray(plan.exterior.coords);ww=np.column_stack([xz[:,0],np.zeros(len(xz)),xz[:,1]]);ww[:,1]=(f['O']@f['W']-ww@f['W'])/f['W'][1];dom=region(ww,f);under=[tolocal(ss,f) for ss in support.values()];prepared.append((j,f,tl,th,under))
   for ss in under:
    for p in top_faces(ss,min_cosine=.90):
     hit=p['polygon'].intersection(dom)
     for poly in pieces(hit):
      if not poly.is_empty:maximum=max(maximum,max(height(p['plane'],v) for v in np.asarray(poly.exterior.coords)))
  heel=math.ceil(maximum*1000.)/1000.+.00001;leaves=[];bends=[]
  for j,f,tl,th,under in prepared:
   qbase=qi-heel*float(f['W']@f['N']);plan=planpiece(j,qbase,qi+4/f['gamma'],tl,th);xz=np.asarray(plan.exterior.coords);ww=np.column_stack([xz[:,0],np.zeros(len(xz)),xz[:,1]]);ww[:,1]=(f['O']@f['W']-ww@f['W'])/f['W'][1];dom=region(ww,f);lo,sm,hi,sx=dom.bounds;ss,proof=gently_bridged_sheet(dom,under,T,grid_in=1.,heel_region=box(lo-1,sx-.75,hi+1,sx+1),heel_height_in=heel,top_options={'min_cosine':.90},height_quantum_in=.001);leaves.append(toworld(ss,f,fold_hip=k-8 if k>=8 else None));bends.append(proof)
  bodyplan=unary_union(bodyplans);f=frame_main(layout[0][0]);y0=(float(f['O']@f['W'])+heel-float(f['W']@f['N'])*qi)/f['W'][1]-.0001;polys=[]
  for p in pieces(bodyplan):
   contours=[np.asarray(p.exterior.coords)[:-1].tolist()]+[np.asarray(r.coords)[:-1].tolist() for r in p.interiors];polys.append(m.CrossSection(contours,m.FillRule.EvenOdd).extrude(12.0001).transform([[1,0,0,0],[0,0,1,y0],[0,1,0,0]]))
  ss=m.Manifold.batch_boolean(leaves+polys,m.OpType.Add);print('UPTURN_FINITE_BUILT',k,len(ss.decompose()),len(ss.to_mesh64().tri_verts),'heel',heel,flush=True)
  dump(OUT/f'raw-{k}.json',pack(ss))
  try:q,ss,receipt=closed_roof_record(ss)
  except AssertionError as e:q=pack(ss);receipt={'status':'FAIL','error':str(e)};issues.append({'id':pid,'receipt':receipt})
  rec={'id':pid,'material':'Benjamin Obdyke VaporDry SA25mil AC48 ice barrier membrane','kind':'cupola_wall_self_adhered_upturn' if k<8 else'cupola_wall_self_adhered_corner_patch','roof':'MAIN'+str(layout[0][0]),'nominal_roof_normal_gauge_in':T,'vertical_face_normal_gauge_in':T,'wall_front_apothem_in':Q,'wall_vertical_upturn_min_in':12.,'roof_leg_min_in':4.,'corner_wrap_each_face_in':12. if k>=8 else 0.,'parentStockId':'CUT-'+pid,'stock_blank_in':[17.,length],'finite_bend_receipts':bends,'selected_corner_wall_normal_fit_clearance_in':.0001 if layer else 0.,'selected_nearwall_bridge_width_in':.75,'selected_nearwall_bridge_height_above_deck_normal_in':heel,'raw_mesh_status':receipt['status'],'boundary_receipt':receipt,'scope':'Fixed25mil stockgrossenvelope withshortfinitebendbridges overlapsteps. Roofnormalnominalgauge.025, localtransitiongaugeapproximation quantified. Actualadheredflatwallfaces; fieldradius/bonding/weatherqualification remainsopen.',**q};records.append(rec);support[pid]=ss;stocks.append({'id':'CUT-'+pid,'product':'VaporDry SA','blank_width_in':17.,'blank_length_in':length,'roll_width_in':57.,'roll_length_in':960.,'installed_ids':[pid]});dump(OUT/'parts-in-progress.json.gz',{'parts':records,'issues':issues});print(pid,receipt['status'],flush=True)
  if '--one' in sys.argv:return
 dump(OUT/'parts.json.gz',{'parts':records});dump(OUT/'stock.json',{'cuts':stocks});dump(OUT/'report.json',{'status':'RAW_PASS_PENDING_COMPOSITION' if not issues else'BLOCKED','issues':issues,'count':len(records)})
if __name__=='__main__':run()
