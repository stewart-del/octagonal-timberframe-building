"""Reproducible guillotine-shelf cuts on actual57in x80ft VDSA rolls."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps')]
from roof_physical_layers import *

def run():
 root=D/'roof-physical-layers-candidate';data=read(root/'main-membrane-checkpoint.json.gz');ids={q['id'] for q in data['parts'] if not q['id'].startswith('VDSA-CUP')};cuts=[dict(q) for q in data['stock'] if any(p in ids for p in q.get('installed_ids',[]))];starters=[q for q in read(D/'roof-eave-starter-candidate/parts.json')['parts'] if 'CUP' not in q['id']];sids={q['id'] for q in starters};cuts += [dict(q) for q in read(D/'roof-eave-starter-candidate/stock.json')['cuts'] if q['id'][4:] in sids];cuts += [dict(q) for q in read(D/'cupola-wall-finite-bend-candidate/stock.json')['cuts']];allids=ids|sids|{q['id'] for q in read(D/'cupola-wall-finite-bend-candidate/parts.json.gz')['parts']};bindings={};shelves=[]
 for c in cuts:
  c.setdefault('installed_ids',[c['id'][4:]]);c['product']='VaporDry SA';w=float(c['blank_width_in']);length=float(c['blank_length_in']);assert 0<w<=57+1e-8 and 0<length<=960+1e-8,c
  for pid in c['installed_ids']:bindings[pid]=c['id']
 # Eachshelf is a rectangular57in-wide crosscut, then parallel straight
 # rips. Shorterrectangles leave visible endoffcuts inside their shelf.
 for c in sorted(cuts,key=lambda q:(-q['blank_length_in'],-q['blank_width_in'],q['id'])):
  opts=[s for s in shelves if s['used_width_in']+c['blank_width_in']<=57+1e-8 and s['length_in']>=c['blank_length_in']-1e-8];s=min(opts,key=lambda s:(s['length_in']-c['blank_length_in'],57-s['used_width_in']-c['blank_width_in'])) if opts else None
  if s is None:s={'id':f'SHELF-VDSA-{len(shelves)+1:03d}','length_in':c['blank_length_in'],'used_width_in':0.,'cuts':[]};shelves.append(s)
  c['shelf_id']=s['id'];c['shelf_rip_x_in']=s['used_width_in'];s['cuts'].append(c['id']);s['used_width_in']+=c['blank_width_in']
 rolls=[]
 for s in sorted(shelves,key=lambda q:(-q['length_in'],q['id'])):
  opts=[r for r in rolls if r['used_length_in']+s['length_in']<=960+1e-8];r=min(opts,key=lambda r:960-r['used_length_in']-s['length_in']) if opts else None
  if r is None:r={'id':f'ROLL-VDSA-MAINPORCH-{len(rolls)+1:02d}','width_in':57.,'length_in':960.,'nominal_thickness_in':.025,'used_length_in':0.,'shelves':[]};rolls.append(r)
  s['parent_roll_id']=r['id'];s['start_roll_length_in']=r['used_length_in'];s['unreused_rip_offcut_width_in']=57-s['used_width_in'];r['shelves'].append(s['id']);r['used_length_in']+=s['length_in']
 sb={s['id']:s for s in shelves}
 for c in cuts:
  s=sb[c['shelf_id']];c['parentRollId']=s['parent_roll_id'];c['roll_x_in']=c['shelf_rip_x_in'];c['roll_y_in']=s['start_roll_length_in'];c['unreused_shelf_end_offcut_in']=s['length_in']-c['blank_length_in']
 for r in rolls:r['end_offcut_length_in']=960-r['used_length_in']
 overlaps=[]
 for i,a in enumerate(cuts):
  for b in cuts[:i]:
   if a['parentRollId']!=b['parentRollId']:continue
   ax,ay=a['roll_x_in'],a['roll_y_in'];bx,by=b['roll_x_in'],b['roll_y_in'];area=max(0.,min(ax+a['blank_width_in'],bx+b['blank_width_in'])-max(ax,bx))*max(0.,min(ay+a['blank_length_in'],by+b['blank_length_in'])-max(ay,by))
   if area>1e-8:overlaps.append([a['id'],b['id'],area])
 missing=sorted(allids-set(bindings));assert not missing,(missing,'Unboundphysicalpiece');assert not overlaps,overlaps
 result={'status':'PASS','physical_SA_parts':len(allids),'cut_blanks':len(cuts),'roll_count':len(rolls),'real_stock_product':'Benjamin Obdyke VaporDry SA25mil57inx80ft','rolls':rolls,'shelves':shelves,'cuts':cuts,'part_to_cut':bindings,'rectangle_overlap_failures':overlaps,'missing_stock_bindings':missing,'scope':'Actualnonoverlappingrectangularcutplan withfixedblankdimensionsandguillotine shelves. Selectedblankdevelopmentallowancesexplicit; factorycornerfoldradius/shopdevelopmentnotinvented. No90degrotationofrollwidth/length. CuproofSAandcupstartersremainseparatefrozeninventory.'};dump(root/'main-SA-optimized-roll-cut-plan.json',result);print('PASS','parts',len(allids),'blanks',len(cuts),'rolls',len(rolls),flush=True)
if __name__=='__main__':run()
