"""Direct closed boundary of piecewise-planar roofsheet; no CSG cellfaces.
Local inches. Emits only exterior interval differences, never duplicated
opposed internal faces. Sourcewood/audit tolerances are unchanged.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path[:0]=[str(D),str(D/'python-deps')]
import numpy as np,manifold3d as m,math
from shapely.geometry import Polygon,LineString
from shapely.ops import unary_union,polygonize
from shapely.geometry.polygon import orient
from shapely import constrained_delaunay_triangles,set_precision

def parts(g):
 if isinstance(g,Polygon):return[g]
 return[q for p in getattr(g,'geoms',[]) for q in parts(p)]
def h(plane,p):return float(np.dot(plane,[*p,1]))
def boundary(cells):
 # First refine all XY boundaries globally. All horizontal/vertical faces
 # use the same actual snappedvertices, eliminating T-junction ownership.
 points=np.vstack([np.asarray(r.coords)[:-1] for c in cells for r in [c['polygon'].exterior]+list(c['polygon'].interiors)]);points=np.unique(np.round(points,9),axis=0)
 def noded(ring):
  out=[];xy=np.asarray(ring.coords)
  for a,b in zip(xy[:-1],xy[1:]):
   a=np.round(a,9);b=np.round(b,9);d=b-a;l2=d@d
   if l2<1e-18:continue
   tt=(points-a)@d/l2;dist=np.linalg.norm(points-(a+tt[:,None]*d),axis=1);ix=np.flatnonzero((tt>1e-10)&(tt<1-1e-10)&(dist<2e-9));out.append(a);out.extend(points[i] for i in sorted(ix,key=lambda i:tt[i]))
  return out
 refined=[];edges={};faces=[]
 for i,c in enumerate(cells):
  loops=[noded(r) for r in [c['polygon'].exterior]+list(c['polygon'].interiors)];p=orient(Polygon(loops[0],loops[1:]),sign=1.);refined.append({**c,'polygon':p});loops=[np.asarray(r.coords)[:-1] for r in [p.exterior]+list(p.interiors)]
  # Facesare represented by3D boundary loops, not pretriangulated yet.
  faces.append({'loops':[np.column_stack([r,[h(c['bottom'],v) for v in r]]) for r in loops],'normal':np.r_[c['bottom'][:2],-1.]})
  faces.append({'loops':[np.column_stack([r,[h(c['top'],v) for v in r]]) for r in loops],'normal':np.r_[-c['top'][:2],1.]})
  for r in loops:
   for a,b in zip(r,np.roll(r,-1,axis=0)):
    key=tuple(sorted([tuple(a),tuple(b)]));edges.setdefault(key,[]).append((i,a,b))
 for key,items in edges.items():
  for ia,a,b in items:
   A=refined[ia];other=[q for q in items if q[0]!=ia];B=refined[other[0][0]] if other else None;planes=[A['bottom'],A['top']]+([B['bottom'],B['top']] if B else[]);ts=[0.,1.]
   for j,pa in enumerate(planes):
    for pb in planes[j+1:]:
     da=h(pa-pb,a);db=h(pa-pb,b)
     if da*db<0 and abs(da-db)>1e-12:ts.append(da/(da-db))
   ts=sorted(set(round(float(t),12) for t in ts))
   for ta,tb in zip(ts[:-1],ts[1:]):
    aa=a+(b-a)*ta;bb=a+(b-a)*tb;mid=(aa+bb)/2;bottom,top=A['bottom'],A['top'];intervals=[]
    if B is None:intervals=[(bottom,top)]
    else:
     if h(bottom,mid)<h(B['bottom'],mid)-1e-10:intervals.append((bottom,min([top,B['bottom']],key=lambda p:h(p,mid))))
     if h(top,mid)>h(B['top'],mid)+1e-10:intervals.append((max([bottom,B['top']],key=lambda p:h(p,mid)),top))
    for lo,hi in intervals:
     if h(hi-lo,mid)<1e-10:continue
     q=np.array([[*aa,h(lo,aa)],[*bb,h(lo,bb)],[*bb,h(hi,bb)],[*aa,h(hi,aa)]]);d=bb-aa;normal=np.array([d[1],-d[0],0.]);faces.append({'loops':[q],'normal':normal})
 # Nodeface edges againstall3D surfacecorners, so a verticalface interval
 # can legally have multiple real intermediate heightvertices at one end.
 pool=np.unique(np.round(np.vstack([r for f in faces for r in f['loops']]),9),axis=0);verts=[];indices={};triangles=[]
 def vertex(p):
  distances=np.linalg.norm(pool-p,axis=1);j=int(distances.argmin());canonical=pool[j] if distances[j]<5e-8 else np.round(p,9);key=tuple(canonical)
  if key not in indices:indices[key]=len(verts);verts.append(key)
  return indices[key]
 for f in faces:
  n=f['normal']/np.linalg.norm(f['normal']);u=np.cross(n,np.eye(3)[np.argmin(abs(n))]);u/=np.linalg.norm(u);v=np.cross(n,u);B=np.column_stack([u,v]);O=f['loops'][0][0];loops=[]
  for ring in f['loops']:
   out=[]
   for a,b in zip(ring,np.roll(ring,-1,axis=0)):
    d=b-a;l2=d@d
    if l2<1e-18:continue
    tt=(pool-a)@d/l2;dist=np.linalg.norm(pool-(a+tt[:,None]*d),axis=1);ix=np.flatnonzero((tt>1e-10)&(tt<1-1e-10)&(dist<2e-9));out.append(a);out.extend(pool[i] for i in sorted(ix,key=lambda i:tt[i]))
   if len(out)>=3:loops.append((np.asarray(out)-O)@B)
  if not loops:continue
  p=Polygon(loops[0],loops[1:])
  if not p.is_valid:p=p.buffer(0)
  for po in parts(p):
   if po.area<1e-12:continue
   for tr in constrained_delaunay_triangles(po).geoms:
    xyz=O+np.asarray(tr.exterior.coords)[:3]@B.T;idx=[vertex(q) for q in xyz];q=np.asarray([verts[j] for j in idx])
    if len(set(idx))<3 or np.linalg.norm(np.cross(q[1]-q[0],q[2]-q[0]))<1e-15:continue
    if np.cross(q[1]-q[0],q[2]-q[0])@n<0:idx=idx[::-1]
    triangles.append(idx)
 result=m.Manifold(m.Mesh64(np.asarray(verts),np.asarray(triangles,np.uint64)))
 if str(result.status())!='Error.NoError':
  import json
  (D/'heightfield-boundary-debug.json').write_text(json.dumps({'vertices':verts,'triangles':triangles}))
 assert str(result.status())=='Error.NoError',('Directheightfieldboundary',str(result.status()),len(verts),len(triangles));return result

def refined_sheet(cells,patches):
 cells=[{**c,'polygon':set_precision(c['polygon'],1e-6)} for c in cells if not set_precision(c['polygon'],1e-6).is_empty]
 patches=[{**c,'polygon':set_precision(c['polygon'],1e-6)} for c in patches if not set_precision(c['polygon'],1e-6).is_empty]
 boundaries=[c['polygon'].boundary for c in cells]+[p['polygon'].boundary for p in patches];out=[]
 for p in polygonize(unary_union(boundaries)):
  if p.area<1e-10:continue
  r=p.representative_point();base=next((c for c in cells if c['polygon'].covers(r)),None)
  if base is None:continue
  point=[r.x,r.y];options=[base['top']]+[q['top'] for q in patches if q['polygon'].covers(r)];out.append({'polygon':orient(p,sign=1.),'bottom':base['bottom'],'top':max(options,key=lambda q:h(q,point))})
 return boundary(out)
