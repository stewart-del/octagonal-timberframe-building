This frozen version contains 85 physical VaporDry SA membrane pieces, eight open-bottom seats for the NEW cupola wall plywood, and an actual rectangular cut plan using five 57-inch ×80-foot rolls. All85 raw pieces and all8 plywood readbacks pass; the bounded937-part context has zero prohibited intersections in2,637 tested pairs.

Use `manifest.json` as the entry point. It names every frozen asset, source guard, recipe, stock cut, replacement ID, assembly phase and remaining interface. The85 pieces comprise49 main/porch field/valley/hip/ridge sheets,20 eave starter cut pieces and16 cupola wall upturn/corner pieces. The16 cupola ROOF membranes and16 cupola starters belong to the separate `cupola-roof-terminal-v1` package and must remain distinct.

Apply the eight GP wall seat tools compositionally to the fresh NEW GP wall panels. Do not overwrite newer enclosure cuts with the reference readbacks. The original C/CC/R timbers, their joints and all window rough openings remain fixed. The seat profiles use actual occupied boundary faces, including steep membrane risers; they are open at the panel bottom.

The product approval is the manufacturer's AC48 ice-barrier approval and ASTM D1970 nail-sealing test, with published cedar/CedarBreather use. This is not a claim of full bituminous ASTM D1970 certification. Short finite-bend envelopes and their small transition gauge approximation are declared in each relevant part. Field fabrication, copper adhesion, corner details and site loads require qualification.

The separate upper porch boot kit, final ventmat, felt/Cu valleys, roof-wall counterflashings, rigid cedar reseating and full roof hardware composition remain subsequent stages. This version does not silently certify those interfaces or a complete building replay. The real stock dimensions must be re-tiled and re-seated when the linked main/cupola pitch3–8 or cupola lift9–36 changes; affine scaling of product meshes is invalid.

`python reproduce.py --verify-only` checks the frozen hashes. `python reproduce.py` writes into a NEW research scratch directory and runs the saved recipe sequence; it never writes into this frozen directory or the repository.
