# VaporDry SA is a verified self-adhered ice-barrier candidate

**Retain the actual25mil VaporDry SA product for the requested ice-and-water barrier role.** The manufacturer explicitly approves it as an ice barrier at eaves/valleys and for full roof deck coverage through **ICC-ES AC48**, the alternative acceptance route for polymeric self-adhered membranes. Its documented cedar/Cedar Breather compatibility is retained.

The primary [January2024 IRC-compliance technical bulletin](https://benjaminobdyke.com/wp-content/uploads/2024/02/2024-VDSA-IRC-Compliance-Tech-Bulletin.pdf) says:

> VaporDry SA passed all the AC48 testing protocols as well as the nail sealabilty test used in ASTM D1970. VaporDry SA is code compliant when used as an ice barrier at all eaves, valleys, and approved for full roof deck coverage.

The same bulletin explains that AC48 provides an alternative means to qualify roof underlayments that the IBC/IRC require to comply with ASTM D1970. It lists eight AC48 protocols, including ponding, cycling/elongation, aging and UV exposure. This is stronger evidence than the nail-water-seal test alone.

Use precise labeling: **“Benjamin Obdyke VaporDry SA25mil self-adhered roof ice barrier; manufacturer-declared AC48 compliance; D1970 nail-sealing test.”** Do not call it GRACE-branded Ice&Water Shield, an impermeable bituminous membrane, or full ASTM D1970 product certification. A product-specific independent ICC-ES evaluation-report number was not identified in this bounded lookup; local approval and installed climate/assembly performance are not certified here.

The [April2026 physical-property sheet](https://benjaminobdyke.com/wp-content/uploads/2024/02/VaporDrySA-Physical-Properties-Data-Sheet-04.2026.pdf) explicitly states it meets/exceeds AC48, provides25mil thickness,14perms, and passes AC48§4.4.1 ponding at61cm water for48hours. The [October2026 detail sheet](https://benjaminobdyke.com/wp-content/uploads/2023/04/VaporDrySA_ProductDetailSheet_10.2026-web.pdf) confirms full-roof applications and all roofing types at3:12or greater. The [August2026 installation guide](https://benjaminobdyke.com/wp-content/uploads/2023/04/VaporDrySA-InstallGuide_08.2026.pdf) explicitly illustrates cedar with Cedar Breather,4in horizontal/6in end/12in corner laps and12in wall upturns.

Individual physical courses retain real57in×80ft stock parents and manufacturer laps. The previous131-piece prototype remains historical until its seam-offset audit and actual drip-edge/valley seating are updated. New membrane seams must be compared to actual plywood joints; merely offsetting a sketch grid is insufficient. Crossing an underlying joint is unavoidable in a continuous roofing sheet, but no membrane seam should be routed along a plywood seam without an explicit offset/crossing receipt.
