from stock_positive_waste_chunks import *
def wedge(u0,u1,v,z0,z1,dv):
 vertices=[[u0,v,z0],[u1,v,z0],[u1,v+dv,z0],[u0,v,z1],[u1,v,z1],[u1,v+dv,z1]];faces=[[2,1,0],[3,4,5],[0,1,4],[0,4,3],[1,2,5],[1,5,4],[2,0,3],[2,3,5]]
 if dv<0:faces=[f[::-1]for f in faces]
 return m.Manifold(m.Mesh64(np.array(vertices,float),np.array(faces,np.uint64)))
def main():
 c=json.loads(gzip.decompress((DEST/'closure-final-raw-wood-patch.json.gz').read_bytes()));raw=json.loads(gzip.decompress((OUT/'main-wall-raw-unbored-wood.json.gz').read_bytes()));P={**raw['add_parts'],**c['replace_new_envelope_parts'],**c['add_parts']};S={**c['stock'],**c['sourceStockRecordOverrides']};out=DEST/'fur-wedge-waste-tests';out.mkdir(exist_ok=True)
 for sid in ['STOCK-W-FUR-01','STOCK-W-FUR-09']:
  rec=S[sid];o,B=stock_frame(rec['blank']);lb=native_local(rec['blank'],o,B);ls=union([native_local(P[k],o,B)for k in rec['children']]);waste=lb-ls;base=[]
  for cell in [waste.trim_by_plane([0,0,1],0),waste.trim_by_plane([0,0,-1],0)]:
   q,pr=candidates_for_cell(cell,o,B);assert q is not None,pr;base.append(q)
  lw=union([native_local(q,o,B)for q in base]);missing=lb-(ls+lw);missingRows=[]
  for cell in missing.decompose():
   missingRows.append({'volumeIn3':cell.volume(),'boundsIn':cell.bounding_box(),'vertices':mesh(cell)['vertices']})
  print('MISSING',sid,missingRows,flush=True);bv=in_local(rec['blank'],o,B).v;lo,hi=bv.min(0),bv.max(0);iv=np.vstack([in_local(P[k],o,B).v for k in rec['children']]);end=min(iv.max(0)[0]-.01,hi[0]);attempts=[];fixed=None
  for side in [-1,1]:
   for thick_m in [1.01e-9,1.05e-9,1.1e-9,1.2e-9,1.5e-9,2e-9]:
    for length in [20,30,40,50,60]:
     ribbon=wedge(end-length,end,lo[1]if side==-1 else hi[1],lo[2],hi[2],-side*thick_m/I);q=mesh(affine(ribbon,np.column_stack([B*I,o])));a=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64),require_single=True)
     if a['status']!='PASS':attempts.append({'side':side,'thicknessM':thick_m,'lengthIn':length,'rawFailures':a['failures']});continue
     pieces=[{'id':sid+f'-WASTE-{i:02}','wasteOnly':True,**p}for i,p in enumerate(base+[q])];pr=pieces_proof(rec,P,pieces);attempts.append({'side':side,'thicknessM':thick_m,'lengthIn':length,'metrics':pr});print(sid,side,thick_m,length,pr['status'],pr['worldPartitionDifferenceIn3'],pr['worldWasteInstalledOverlapIn3'],pr['worldBetweenWastePiecesOverlapIn3'],flush=True)
     if pr['status']=='PASS':
      fixed={k:v for k,v in rec.items()if k!='declared_exterior_offcut'};fixed.update(declared_exterior_offcut_pieces=pieces,wasteRepresentation='independent_positive_closed_chunks',serializedWasteReadbackRepair={'method':'Waste-only source-bound thin ribbon numerical boundary representation','explicitApproximation':True,'wedgeSide':side,'wedgeThicknessM':thick_m,'wedgeLengthIn':length,'installedChildrenAndBlankUnchanged':True,'final':pr});break
    if fixed:break
   if fixed:break
  write_gz(out/(sid+'.json.gz'),{'stockId':sid,'stockRecordOverride':fixed,'proof':{'status':'PASS'if fixed else'BLOCKED','missingGeometryDiagnostic':missingRows,'attempts':attempts}})
if __name__=='__main__':main()
