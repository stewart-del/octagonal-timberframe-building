"""Standard-library consumer: only waste fields, exact current geometry guards.
Geometry auditing is independent and recorded in core290-independent-readback.
Changing a current child requires fresh waste generation, never a stale override.
"""
import copy,hashlib,json
ALLOWED={'declared_exterior_offcut','declared_exterior_offcut_pieces','wasteRepresentation','serializedWasteReadbackRepair','outside_in3','reconstruction_in3'}
def fingerprint(record):
 assert record.get('triangles'),'Materialize actual CURRENT geometry before binding a waste correction'
 return hashlib.sha256(json.dumps({k:record.get(k)for k in ['vertices','triangles']},sort_keys=True,separators=(',',':')).encode()).hexdigest()
def apply(stock_by_id,current_parts,asset):
 result=dict(stock_by_id);receipts=[]
 for sid,patch in asset['corrections'].items():
  assert sid in result,('Missing current stock row',sid)
  record=result[sid];assert fingerprint(record['blank'])==patch['sourceBlankGeometrySHA256'],('Current blank differs; regenerate waste',sid)
  expected=patch['sourceInstalledChildGeometrySHA256'];assert set(record['children'])==set(expected),('Current physical children differ; regenerate waste',sid)
  for pid,expected_hash in expected.items():
   assert pid in current_parts and fingerprint(current_parts[pid])==expected_hash,('Current child differs; regenerate waste',sid,pid)
  assert set(patch['setWasteFields'])<=ALLOWED and set(patch['removeWasteFields'])<=ALLOWED,('Forbidden nonwaste mutation',sid)
  before={k:v for k,v in record.items()if k not in ALLOWED};after=dict(record)
  for field in patch['removeWasteFields']:after.pop(field,None)
  after.update(copy.deepcopy(patch['setWasteFields']));assert before=={k:v for k,v in after.items()if k not in ALLOWED},('Blank/product/children/stock metadata changed',sid)
  assert ('declared_exterior_offcut'in after)^('declared_exterior_offcut_pieces'in after),('Exactly one waste representation required',sid)
  if 'declared_exterior_offcut_pieces'in after:assert after['declared_exterior_offcut_pieces'],('Empty waste piece list',sid)
  result[sid]=after;receipts.append({'stockId':sid,'blankAndInstalledChildBindingsMatched':True,'onlyWasteFieldsChanged':True,'multiplePositiveChunks':'declared_exterior_offcut_pieces'in after})
 return result,receipts
