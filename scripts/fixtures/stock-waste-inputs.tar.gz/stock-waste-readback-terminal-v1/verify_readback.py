#!/usr/bin/env python3
"""Replay all290 against the immutable core package in a fresh process."""
from pathlib import Path
import argparse,gzip,hashlib,json,sys
PACKAGE=Path(__file__).resolve().parent
CORE=PACKAGE.parent/'closure-core-terminal-v1'
sys.path[:0]=[str(PACKAGE/'recipes'),str(CORE/'recipes'),str(CORE/'reference-repository/scripts')]
from stock_positive_waste_chunks import pieces_proof,proof,inspect_mesh,np
from apply_waste_corrections import apply
def load(p):return json.loads(gzip.decompress(p.read_bytes()))if p.suffix=='.gz'else json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path);args=parser.parse_args()
 paths=[Path(__file__),PACKAGE/'apply_waste_corrections.py',PACKAGE/'assets/core-waste-corrections.json.gz',CORE/'manifest.json',CORE/'assets/closure-final-raw-wood-patch.json.gz',CORE/'recipes/lap-siding-candidate/main-wall-raw-unbored-wood.json.gz'];assert sha(paths[3])=='841d073466a0d998f0f54d3998771c54a7889606d385710c8ab5c311096aeded';c=load(paths[4]);r=load(paths[5]);P={**r['add_parts'],**c['replace_new_envelope_parts'],**c['add_parts']};S={**c['stock'],**c['sourceStockRecordOverrides']};fixed,receipts=apply(S,P,load(paths[2]))
 for module in list(sys.modules.values()):
  p=getattr(module,'__file__',None)
  if p and str(p).endswith('.py')and(str(p).startswith(str(PACKAGE))or str(p).startswith(str(CORE))):paths.append(Path(p))
 paths=list(dict.fromkeys(paths));start={str(p):sha(p)for p in paths};rows=[];bad=[]
 for sid,rec in fixed.items():
  metrics=pieces_proof(rec,P,rec['declared_exterior_offcut_pieces'])if'declared_exterior_offcut_pieces'in rec else proof(rec,P,rec['declared_exterior_offcut']);blank=inspect_mesh(np.array(rec['blank']['vertices']),np.array(rec['blank']['triangles'],np.uint64),require_single=True)['status'];children={pid:inspect_mesh(np.array(P[pid]['vertices']),np.array(P[pid]['triangles'],np.uint64),require_single=True)['status']for pid in rec['children']};status='PASS'if metrics['status']=='PASS'and blank=='PASS'and all(x=='PASS'for x in children.values())else'BLOCKED';rows.append({'stockId':sid,'status':status,'blankRAW':blank,'childrenRAW':children,'metrics':metrics})
  if status!='PASS':bad.append(sid)
 end={str(p):sha(p)for p in paths};out={'status':'PASS'if not bad and start==end else'BLOCKED','rows':rows,'count':len(rows),'failed':bad,'correctionsApplied':len(receipts),'sourceGuardsAtStart':start,'sourceGuardsAtEnd':end,'sourcesUnchangedDuringRun':start==end,'kernelAndAuditors':'Immutable core v1 reference import closure; original1e-6in3 stock bounds, no shared helper or source edits','scope':'Fresh isolated serialized native world/local replay ofall290 against frozen blank/current child geometry, including188 waste-only corrections. No installed or blank edit.'}
 if args.output:args.output.write_text(json.dumps(out,indent=2)+'\n')
 print(out['status'],len(rows),bad)
if __name__=='__main__':main()
