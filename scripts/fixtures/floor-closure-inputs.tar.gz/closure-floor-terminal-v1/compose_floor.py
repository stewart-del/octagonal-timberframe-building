#!/usr/bin/env python3
"""Default-only negative cuts on CURRENT NEW envelope, cork and four feet.
Installed source snapshots are proof bounds, never replacement geometry.
Use with the immutable closure-core-terminal-v1 import closure.
"""
from pathlib import Path
import argparse,copy,gzip,hashlib,json,sys
PACKAGE=Path(__file__).resolve().parent
CORE=PACKAGE.parent/'closure-core-terminal-v1'
sys.path[:0]=[str(PACKAGE/'recipes'),str(CORE/'recipes'),str(CORE/'reference-repository/scripts')]
from closure_common import native_solid,amount,diff,union,mesh,I,TOL,np,affine,inspect_mesh
from floor_surface_normalization import normalize_one
def load(path):return json.loads(gzip.decompress(path.read_bytes()))if path.suffix=='.gz'else json.loads(path.read_text())
def shape(p):
 assert p.get('triangles'),'Materialize actual CURRENT receiver; no stale geometry substitution'
 return native_solid(p)
def apply(current,include_cork=False):
 out=dict(current);aslist=isinstance(current['parts'],list);P={p['id']:p for p in current['parts']}if aslist else dict(current['parts']);fr=load(PACKAGE/'assets/floor-return-final-raw-wood-patch.json.gz');f=load(PACKAGE/'assets/floor-return-physical-films-v2.json.gz');old=load(PACKAGE/'assets/floor-films-229-frozen.json.gz');feet=load(PACKAGE/'assets/book-foot-film-seats.json.gz');ctx=load(CORE/'assets/construction-local-frames.json');receipts=[]
 # Only actual new purchased return pieces may be added. Existing actors
 # are never replaced and an existing later cut must survive.
 for pid,p0 in fr['add_parts'].items():
  p=f['replaceNewEnvelopeParts_READBACK_ONLY'].get(pid,p0)
  if pid not in P:P[pid]=copy.deepcopy(p)
  else:assert amount(shape(P[pid])-shape(p))<=TOL,('Existing return must already include declared final cuts; never replace current geometry',pid)
 templates={**fr['replace_new_envelope_parts'],**fr['add_parts'],**f['replaceNewEnvelopeParts_READBACK_ONLY']}
 tools={}
 for pid,seq in fr['requiredAdditionalNewEnvelopeFilmSeatToolSequence'].items():
  assert pid.startswith(('ENV-','AIR-')),('Protected primary target',pid)
  for rid in fr['splitConstructionGroups'].get(pid,[pid]):
   if rid not in fr['add_parts']:tools.setdefault(rid,[]).extend(seq)
 for pid,seq in f['requiredAdditionalNewEnvelopeToolSequence'].items():
  if pid not in fr['add_parts']:tools.setdefault(pid,[]).extend(seq)
 for pid,seq in tools.items():
  assert pid in P and pid in templates,('Missing current or reference receiver',pid)
  name=pid.split('-')[1];frame=np.array(next(q['basis']for q in ctx['mainFaces']if q['face']==name));L=np.column_stack([frame[:,:3].T,-frame[:,:3].T@frame[:,3]]);W=frame;before=shape(P[pid]);afterLocal=affine(before,L);active=[]
  for tool in seq:
   s=shape(tool)
   if amount(before^s)>TOL:afterLocal=afterLocal-affine(s,L);active.append(s)
  after=affine(afterLocal,W)if active else before
  assert amount(after-shape(templates[pid]))<=TOL,('Current negative-cut result outside default bound',pid)
  positive=[s for s in after.decompose()if s.volume()>TOL]
  assert len(positive)==1,('Current void deleted/split a physical actor; never fill it from reference',pid,len(positive))
  q=mesh(after);a=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64),require_single=True)
  if a['status']!='PASS':q,pr=normalize_one({'id':pid,'stock_frame':{'axis':frame[:,0].tolist(),'width':frame[:,1].tolist(),'depth':frame[:,2].tolist()},**q},a['failures'])
  assert max(amount(shape(q)-after),amount(after-shape(q)))<=TOL,('Serialization changed material',pid,amount(shape(q)-after)/I**3,amount(after-shape(q))/I**3)
  P[pid]={**P[pid],**q,'floorNegativeToolsComposedOnCurrent':True,'geometryFingerprintRegenerationRequired':True};receipts.append({'id':pid,'removedIn3':amount(before-after)/I**3,'secondApplicationDifferenceIn3':diff(after,after-union(active))/I**3 if active else 0})
 # Actual canonical floor parts retain every existing book/joinery relief.
 lowerTools={pid:[spec['tool']]for pid,spec in feet['requiredSourceMinusSeatTools'].items()}
 for pid in list(P):
  if include_cork and 'CORK'in pid:lowerTools[pid]=[old['requiredCorkPocketCutTool'],f['requiredAdditionalCurrentCorkPocketCutTool']]
 for pid,seq in lowerTools.items():
  assert pid in P,('Missing current lower receiver',pid)
  before=shape(P[pid]);after=before
  for t in seq:
   s=shape(t)
   if amount(after^s)>TOL:after=after-s
  if diff(before,after)<=TOL:continue
  q=mesh(after);a=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64))
  if a['status']!='PASS':
   try:q,pr=normalize_one({**P[pid],**q},a['failures'])
   except AssertionError:
    from stock_high_precision_waste import RawBoundary,candidate_planes
    axes=P[pid]['stock_frame'];B=np.column_stack([axes['axis'],axes['width'],axes['depth']]);o=np.mean(np.array(q['vertices']),axis=0);raw=RawBoundary((np.array(q['vertices'])-o)@B/I,q['triangles']);found=None
    for scale in [1e7,5e7,1e8]:
     for eps in [1e-10,2e-10,5e-10]:
      try:
       local=candidate_planes(raw,eps/I,scale);trial=mesh(affine(local,np.column_stack([B*I,o])));audit=inspect_mesh(np.array(trial['vertices']),np.array(trial['triangles'],np.uint64));worldError=diff(after,shape(trial))/I**3;L=np.column_stack([B.T/I,-B.T@o/I]);localError=diff(affine(after,L),affine(shape(trial),L));
       if audit['status']=='PASS'and max(worldError,localError)<=1e-6:found=trial;break
      except Exception:pass
     if found:break
    assert found is not None,('No strict RAW lower cut serialization within original tolerance',pid)
    q=found
  assert amount(shape(q)-before)<=TOL,('Never restore current lower material',pid)
  P[pid]={**P[pid],**q,'floorFilmSeatComposedOnCurrent':True,'geometryFingerprintRegenerationRequired':True};receipts.append({'id':pid,'removedIn3':amount(before-after)/I**3,'lowerNegativeTool':True})
 for pid,p in {**old['parts'],**old['bootParts'],**f['parts']}.items():
  if pid in P:assert diff(shape(P[pid]),shape(p))<=TOL,('Immutable film already differs',pid)
  else:P[pid]=copy.deepcopy(p)
 out['parts']=list(P.values())if aslist else P;out['floorClosureComposition']={'negativeToolReceipts':receipts,'newReturnWood':len(fr['add_parts']),'frozenFilmsAndBoots':len(old['parts'])+len(old['bootParts']),'newFilms':len(f['parts']),'stock43Asset':'assets/stock43-waste-readback.json.gz','requiredHardwareAsset':'assets/floor-return-final-hardware-instances.json.gz','requiredCausalDelta':'assets/floor-gap-v2-causal-metadata.json.gz','readyForCompleteImport':False,'explicitImportBlocker':'Canonical cork additional pocket fresh-cut serialization is not released; default helper preserves cork byte-exact. Required cork tools/diagnostic are separate. Do not claim film/cork nonoverlap until owner resolves them.','limits':['No hardware is silently added by this wood/film helper; integrate all611 separately','Reference stock overrides apply only when their exact child geometry bindings match; otherwise recompute waste against current children','No primary P/rail/old28 floor GP/steel/concrete snapshot overwrite','Field head seals, adhesion, remaining rain/door/cupwall interfaces and owner whole-scene checks remain explicit']};return out
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();d=apply(load(a.input));b=json.dumps(d,separators=(',',':')).encode();a.output.write_bytes(gzip.compress(b,mtime=0)if a.output.suffix=='.gz'else b)
if __name__=='__main__':main()
