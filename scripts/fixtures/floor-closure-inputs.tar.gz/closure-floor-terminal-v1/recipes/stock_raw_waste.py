"""Waste-only raw signed-plane reconstruction with independent partition tests.
No installed part, stock blank, published dimensions, tolerance or auditor edits.
"""
from closure_common import *
from floor_surface_normalization import regular_local
from types import SimpleNamespace

class RawBoundary:
 def __init__(self,v,f):self.v=np.asarray(v,float);self.f=np.asarray(f,np.uint64)
 def to_mesh64(self):return SimpleNamespace(vert_properties=self.v,tri_verts=self.f)
 def volume(self):
  p=self.v[self.f];return float(np.einsum('ij,ij->i',p[:,0],np.cross(p[:,1],p[:,2])).sum()/6)

def stock_frame(blank):
 v=np.asarray(blank['vertices'],float);f=np.asarray(blank['triangles'],np.uint64);normals=[]
 for ids in f:
  p=v[ids];n=np.cross(p[1]-p[0],p[2]-p[0]);length=np.linalg.norm(n)
  if length<1e-18:continue
  n=n/length;n[abs(n)<1e-14]=0.;n=n/np.linalg.norm(n)
  if n[np.argmax(abs(n))]<0:n=-n
  if not any(abs(n@old)>1-1e-11 for old in normals):normals.append(n)
 assert len(normals)==3,('Stockblankmustbearectangularpublishedprism',len(normals))
 normals.sort(key=lambda n:-np.ptp(v@n));B=np.column_stack(normals)
 if np.linalg.det(B)<0:B[:,2]*=-1
 assert np.max(abs(B.T@B-np.eye(3)))<1e-10
 return v.mean(0),B

def in_local(part,origin,B):return RawBoundary((np.asarray(part['vertices'],float)-origin)@B/I,part['triangles'])
def native_local(part,origin,B):
 r=in_local(part,origin,B);return m.Manifold(m.Mesh64(np.array(r.v,order='C'),np.array(r.f,np.uint64,order='C')))
def proof(record,parts,waste):
 origin,B=stock_frame(record['blank']);b=native_solid(record['blank']);children=[native_solid(parts[k])for k in record['children']];s=union(children);w=native_solid(waste);lb=native_local(record['blank'],origin,B);ls=union([native_local(parts[k],origin,B)for k in record['children']]);lw=native_local(waste,origin,B);au=inspect_mesh(np.array(waste['vertices']),np.array(waste['triangles'],np.uint64));metrics={'rawWasteStatus':au['status'],'rawWasteFailures':au['failures'],'blankIn3':b.volume()/I**3,'installedIn3':sum(q.volume()for q in children)/I**3,'wasteIn3':w.volume()/I**3,'worldScalarBalanceIn3':abs(b.volume()-sum(q.volume()for q in children)-w.volume())/I**3,'worldPartitionDifferenceIn3':diff(b,s+w)/I**3,'worldWasteInstalledOverlapIn3':amount(s^w)/I**3,'worldWasteOutsideBlankIn3':amount(w-b)/I**3,'worldInstalledOutsideBlankIn3':amount(s-b)/I**3,'localPartitionDifferenceIn3':diff(lb,ls+lw),'localScalarBalanceIn3':abs(lb.volume()-sum(q.volume()for q in [native_local(parts[k],origin,B)for k in record['children']])-lw.volume()),'localWasteInstalledOverlapIn3':amount(ls^lw),'localWasteOutsideBlankIn3':amount(lw-lb),'localInstalledOutsideBlankIn3':amount(ls-lb)};numeric=[value for key,value in metrics.items()if key.endswith('In3') and key not in ['blankIn3','installedIn3','wasteIn3']];metrics['status']='PASS' if au['status']=='PASS' and max(numeric,default=0)<=1e-6 else'BLOCKED';return metrics

def rebuild(record,parts):
 old=record['declared_exterior_offcut'];initial=proof(record,parts,old)
 if initial['status']=='PASS':return None,{'status':'PASS','changed':False,'initial':initial}
 origin,B=stock_frame(record['blank']);blank=native_solid(record['blank']);installed=union([native_solid(parts[k])for k in record['children']]);worldRemainder=mesh(blank-installed);lb=native_local(record['blank'],origin,B);ls=union([native_local(parts[k],origin,B)for k in record['children']]);localRemainder=mesh(lb-ls);attempts=[]
 sources=[('original RAW signed boundary',in_local(old,origin,B)),('fresh world blank minus actual installed, RAW before native import',in_local(worldRemainder,origin,B)),('fresh stock-local-inch blank minus actual installed, RAW before native import',RawBoundary(localRemainder['vertices'],localRemainder['triangles']))]
 for name,raw in sources:
  for eps_m in [1e-9,1e-10]:
   try:
    rebuilt=regular_local(raw,eps_m/I);candidate=mesh(affine(rebuilt,np.column_stack([B*I,origin])));metrics=proof(record,parts,candidate);attempts.append({'method':name,'planeWeldToleranceM':eps_m,'rawSignedSourceVolumeIn3':raw.volume(),'result':metrics})
    if metrics['status']=='PASS':
     fixed={**record,'declared_exterior_offcut':candidate,'outside_in3':metrics['worldInstalledOutsideBlankIn3'],'reconstruction_in3':metrics['worldPartitionDifferenceIn3'],'serializedWasteReadbackRepair':{'method':name,'planeWeldToleranceM':eps_m,'installedChildrenAndBlankUnchanged':True,'originalWasteGeometrySHA256':geom_fingerprint(old),'final':metrics}};return fixed,{'status':'PASS','changed':True,'initial':initial,'final':metrics,'attempts':attempts}
   except Exception as e:attempts.append({'method':name,'planeWeldToleranceM':eps_m,'error':str(e)[:300]})
 return None,{'status':'BLOCKED','changed':False,'initial':initial,'attempts':attempts}
