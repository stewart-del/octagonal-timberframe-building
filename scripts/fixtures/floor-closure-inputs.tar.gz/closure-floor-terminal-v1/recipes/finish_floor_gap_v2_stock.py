"""Serial waste-only proof against the separate, approved 1/8in return gap."""
from stock_raw_waste_v3 import rebuild
from stock_positive_waste_chunks import *
from stock_waste_plane_snap import targeted_rebuild
import os
def main():
 target=DEST/'floor-gap-v2-stock-final';target.mkdir(exist_ok=True);(target/'rows').mkdir(exist_ok=True)
 paths=[Path(__file__),DEST/'closure-final-raw-wood-patch.json.gz',OUT/'main-wall-raw-unbored-wood.json.gz',DEST/'floor-return-final-raw-wood-patch.json.gz',DEST/'floor-return-physical-films-v2.json.gz',DEST/'stock-readback-floor-v3/correction-asset.json.gz']
 c=json.loads(gzip.decompress(paths[1].read_bytes()));r=json.loads(gzip.decompress(paths[2].read_bytes()));fr=json.loads(gzip.decompress(paths[3].read_bytes()));f=json.loads(gzip.decompress(paths[4].read_bytes()));P={**r['add_parts'],**c['replace_new_envelope_parts'],**c['add_parts'],**fr['replace_new_envelope_parts'],**fr['add_parts'],**f['replaceNewEnvelopeParts_READBACK_ONLY']};old=json.loads(gzip.decompress(paths[5].read_bytes()))['stockRecordOverrides'];stocks=f['sourceStockRecordOverrides']
 for module in list(sys.modules.values()):
  p=getattr(module,'__file__',None)
  if p and str(p).endswith('.py')and(str(p).startswith(str(HERE))or str(p).startswith(str(ROOT/'scripts'))):paths.append(Path(p))
 paths=list(dict.fromkeys(paths));guards={str(p):sha(p)for p in paths};rows=[];fixed={};fail=[]
 for sid,rec in stocks.items():
  binding={'sourceBlankSHA256':geom_fingerprint(rec['blank']),'sourceInstalledChildGeometrySHA256':{k:geom_fingerprint(P[k])for k in rec['children']}};dest=target/'rows'/(hashlib.sha256(sid.encode()).hexdigest()+'.json.gz');hit=None
  if dest.exists():
   cache=json.loads(gzip.decompress(dest.read_bytes()))
   if cache.get('binding')==binding:hit=cache
  if hit: row=hit['proof'];record=hit['stockRecordOverride']
  else:
   record=rec;metrics=proof(rec,P,rec['declared_exterior_offcut']);row={'status':metrics['status'],'changed':False,'final':metrics}
   if metrics['status']!='PASS' and sid in old:
    candidate=old[sid];metrics=proof(rec,P,candidate['declared_exterior_offcut'])
    if metrics['status']=='PASS':record={**rec,'declared_exterior_offcut':candidate['declared_exterior_offcut']};row={'status':'PASS','changed':True,'method':'prior waste independently rechecked against actual gap-v2 children','final':metrics}
   if row['status']!='PASS':
    record,row=rebuild(rec,P)
   if row['status']!='PASS' and sid=='STOCK-S-PLY-02':
    waste,pr=targeted_rebuild(rec,P)
    if waste:record={**rec,'declared_exterior_offcut':waste};row=pr;row['changed']=True
   if row['status']!='PASS':
    record,row=split_waste(rec,P);row['changed']=bool(record)
   if record is None:record=rec
   write_gz(dest,{'stockId':sid,'binding':binding,'stockRecordOverride':record,'proof':row})
  row={**row,'stockId':sid,**binding};rows.append(row)
  if row['status']!='PASS':fail.append(sid)
  fixed[sid]=record
  save(target/'progress.json',{'stockCount':len(stocks),'processed':len(rows),'failed':fail,'rows':rows});print('FLOOR',len(rows),sid,row['status'],flush=True)
 end={str(p):sha(p)for p in paths};out={'status':'PASS'if not fail and guards==end else'BLOCKED','stockCount':len(stocks),'checkedCount':len(rows),'failed':fail,'rows':rows,'sourceGuardsAtStart':guards,'sourceGuardsAtEnd':end,'sourcesUnchangedDuringRun':guards==end,'blankAndInstalledGeometryUnchangedByWasteRepair':True,'positiveVolumeToleranceIn3':1e-6,'scope':'All43 stock rows against gap-v2 installed children; each serialized waste independently strictRAW and native world/local partition checked. Multiple positive waste chunks supported explicitly.'};save(target/'report.json',out);write_gz(target/'correction-asset.json.gz',{'stockRecordOverrides':fixed,'sourceGuards':guards,'installedChildBindings':{r['stockId']:{k:r[k]for k in ['sourceBlankSHA256','sourceInstalledChildGeometrySHA256']}for r in rows},'scope':out['scope']});print('DONE',out['status'],fail,flush=True)
if __name__=='__main__':main()
