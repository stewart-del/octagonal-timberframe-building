"""Read-only canonical source; export failing additional-pocket readbacks."""
from closure_hardware import *
def main():
 target=HERE/'closure-floor-terminal-v1';paths=[Path(__file__),ROOT/'src/floor-foundation-solids.json',DEST/'floor-films-229-frozen.json.gz',DEST/'floor-return-physical-films-v2.json.gz'];fd=read(paths[1]);paths.append(ROOT/'src'/fd['geometryArchive']);guards={str(p):sha(p)for p in paths};arc=payload(paths[-1])['parts'];old=payload(paths[2]);new=payload(paths[3]);tools=[old['requiredCorkPocketCutTool'],new['requiredAdditionalCurrentCorkPocketCutTool']];S=[native_solid(t)for t in tools];rows=[];readbacks={};sources={}
 for p0 in fd['parts']:
  if 'CORK'not in p0['id']:continue
  p=copy.deepcopy(p0)
  if p.get('geometry_ref'):p.update(arc[p['geometry_ref']])
  before=native_solid(p);after=before
  for tool in S:
   if amount(after^tool)>TOL:after=after-tool
  if diff(before,after)<=TOL:continue
  q=mesh(after);audit=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64));sources[p['id']]=p;readbacks[p['id']]={**p,**q};rows.append({'id':p['id'],'sourceGeometrySHA256':geom_fingerprint(p),'removedIn3':amount(before-after)/I**3,'rawStatus':audit['status'],'rawFailures':audit['failures'],'rawSignedVolumeM3':audit['signed_volume_m3'],'preExportNativeVolumeM3':after.volume(),'rawNativeReadbackDifferenceIn3':diff(after,native_solid(q))/I**3})
 end={str(p):sha(p)for p in paths};d={'status':'IMPORT_BLOCKED_STRICT_CORK_RAW','readyForImport':False,'sourceGuardsAtStart':guards,'sourceGuardsAtEnd':end,'sourcesUnchangedDuringRun':guards==end,'canonicalSourceParts_UNCHANGED':sources,'freshCutRawReadbacks_DIAGNOSTIC_ONLY':readbacks,'requiredCutToolsInOrder':tools,'rows':rows,'rule':'Do not import diagnostics as physical released solids. Apply both negative tools compositionally to CURRENT cork preserving existing reliefs/finish0, then establish strict raw and unchanged stock partition before film/cork nonoverlap or complete import claim.','stockThicknessMm':3.0,'firstPocketDepthMm':1.1,'additionalPocketDepthMm':1.45};write_gz(target/'assets/cork-freshcut-import-blocker.json.gz',d);save(target/'proofs/cork-freshcut-import-blocker-check.json',{k:v for k,v in d.items()if k not in ['canonicalSourceParts_UNCHANGED','freshCutRawReadbacks_DIAGNOSTIC_ONLY','requiredCutToolsInOrder']});print('BLOCKER',len(rows),[(r['id'],r['rawStatus'])for r in rows],flush=True)
if __name__=='__main__':main()
