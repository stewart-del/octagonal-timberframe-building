"""Waste-only raw signed-plane reconstruction with independent partition tests.
No installed part, stock blank, published dimensions, tolerance or auditor edits.
"""
from closure_common import *
from floor_surface_normalization import regular_local
from types import SimpleNamespace

class RawBoundary:
 def __init__(self,v,f):self.v=np.asarray(v,float);self.f=np.asarray(f,np.uint64)
 def to_mesh64(self):return SimpleNamespace(vert_properties=self.v,tri_verts=self.f)
 def volume(self):
  p=self.v[self.f];return float(np.einsum('ij,ij->i',p[:,0],np.cross(p[:,1],p[:,2])).sum()/6)

def stock_frame(blank):
 v=np.asarray(blank['vertices'],float);f=np.asarray(blank['triangles'],np.uint64);normals=[]
 for ids in f:
  p=v[ids];n=np.cross(p[1]-p[0],p[2]-p[0]);length=np.linalg.norm(n)
  if length<1e-18:continue
  n=n/length;n[abs(n)<1e-14]=0.;n=n/np.linalg.norm(n)
  if n[np.argmax(abs(n))]<0:n=-n
  if not any(abs(n@old)>1-1e-11 for old in normals):normals.append(n)
 assert len(normals)==3,('Stockblankmustbearectangularpublishedprism',len(normals))
 normals.sort(key=lambda n:-np.ptp(v@n));B=np.column_stack(normals)
 if np.linalg.det(B)<0:B[:,2]*=-1
 assert np.max(abs(B.T@B-np.eye(3)))<1e-10
 return v.mean(0),B

def in_local(part,origin,B):return RawBoundary((np.asarray(part['vertices'],float)-origin)@B/I,part['triangles'])
def native_local(part,origin,B):
 r=in_local(part,origin,B);return m.Manifold(m.Mesh64(np.array(r.v,order='C'),np.array(r.f,np.uint64,order='C')))
def proof(record,parts,waste):
 origin,B=stock_frame(record['blank']);b=native_solid(record['blank']);children=[native_solid(parts[k])for k in record['children']];s=union(children);w=native_solid(waste);lb=native_local(record['blank'],origin,B);ls=union([native_local(parts[k],origin,B)for k in record['children']]);lw=native_local(waste,origin,B);au=inspect_mesh(np.array(waste['vertices']),np.array(waste['triangles'],np.uint64));metrics={'rawWasteStatus':au['status'],'rawWasteFailures':au['failures'],'blankIn3':b.volume()/I**3,'installedIn3':sum(q.volume()for q in children)/I**3,'wasteIn3':w.volume()/I**3,'worldScalarBalanceIn3':abs(b.volume()-sum(q.volume()for q in children)-w.volume())/I**3,'worldPartitionDifferenceIn3':diff(b,s+w)/I**3,'worldWasteInstalledOverlapIn3':amount(s^w)/I**3,'worldWasteOutsideBlankIn3':amount(w-b)/I**3,'worldInstalledOutsideBlankIn3':amount(s-b)/I**3,'localPartitionDifferenceIn3':diff(lb,ls+lw),'localScalarBalanceIn3':abs(lb.volume()-sum(q.volume()for q in [native_local(parts[k],origin,B)for k in record['children']])-lw.volume()),'localWasteInstalledOverlapIn3':amount(ls^lw),'localWasteOutsideBlankIn3':amount(lw-lb),'localInstalledOutsideBlankIn3':amount(ls-lb)};numeric=[value for key,value in metrics.items()if key.endswith('In3') and key not in ['blankIn3','installedIn3','wasteIn3']];metrics['status']='PASS' if au['status']=='PASS' and max(numeric,default=0)<=1e-6 else'BLOCKED';return metrics

def strict_readback_candidate(candidate,origin,B):
 from floor_surface_normalization import normalize_one,collapse_short_edges
 original=native_solid(candidate);localOriginal=native_local(candidate,origin,B)
 toWorld=np.column_stack([B*I,origin]);seed=localOriginal
 # Try RAW stock-local coordinate rounding before nativeimport. Every
 # candidate still requires strictRAW andbothoccupieddifference bounds;
 # the physicalblank/installedparts are neverrounded ormodified.
 rawV=(np.asarray(candidate['vertices'],float)-origin)@B/I;rawF=np.asarray(candidate['triangles'],np.uint64)
 for decimals in [12,11,10,9,8,7,6]:
  for weld_m in [1e-10,1e-9]:
   try:
    rounded=RawBoundary(np.round(rawV,decimals),rawF);option=regular_local(rounded,weld_m/I);q=mesh(affine(option,toWorld));au=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64))
    if au['status']=='PASS' and max(diff(original,native_solid(q))/I**3,diff(localOriginal,native_local(q,origin,B)))<=1e-6:return q,'RAW local rounding decimals='+str(decimals)+' within unchanged world/local1e-6in3'
   except Exception:pass
 options=[('localnative',seed)]
 for eps_m in [1e-10,1e-9,1e-8,1e-7]:
  options.append(('localsimplify'+str(eps_m),seed.simplify(eps_m/I)))
  collapsed,detail=collapse_short_edges(seed,eps_m/I)
  if str(collapsed.status())=='Error.NoError':options.append(('shortedge'+str(eps_m),collapsed.simplify(eps_m/I)))
 for label,option in options:
  q=mesh(affine(option,toWorld));au=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64))
  if au['status']!='PASS':continue
  w=native_solid(q);loc=native_local(q,origin,B)
  if max(diff(original,w)/I**3,diff(localOriginal,loc))<=1e-6:return q,label
 # Connectedpiece normalization retains allphysicalcomponents; onlya total
 # <=1e-6in3 nonpositive/native residual mayvanish, andfinalpartitiontests
 # stilldecideacceptance. Noauditororinstalledgeometrychange.
 pieces=[]
 try:
  for i,piece in enumerate(original.decompose()):
   if piece.volume()<=0:continue
   q=mesh(piece);au=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64))
   if au['status']!='PASS':q,pr=normalize_one({'id':'WASTE-'+str(i),'stock_frame':{'axis':B[:,0].tolist(),'width':B[:,1].tolist(),'depth':B[:,2].tolist()},**q},au['failures'])
   pieces.append(native_solid(q))
  q=mesh(m.Manifold.compose(pieces));au=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64))
  if au['status']=='PASS' and max(diff(original,native_solid(q))/I**3,diff(localOriginal,native_local(q,origin,B)))<=1e-6:return q,'connectedpiece strictnormalization'
 except Exception:pass
 return None,None

def rebuild(record,parts):
 old=record['declared_exterior_offcut'];initial=proof(record,parts,old)
 if initial['status']=='PASS':return None,{'status':'PASS','changed':False,'initial':initial}
 origin,B=stock_frame(record['blank']);blank=native_solid(record['blank']);installed=union([native_solid(parts[k])for k in record['children']]);worldRemainder=mesh(blank-installed);lb=native_local(record['blank'],origin,B);ls=union([native_local(parts[k],origin,B)for k in record['children']]);localRemainder=mesh(lb-ls);attempts=[]
 sources=[('original RAW signed boundary',in_local(old,origin,B)),('fresh world blank minus actual installed, RAW before native import',in_local(worldRemainder,origin,B)),('fresh stock-local-inch blank minus actual installed, RAW before native import',RawBoundary(localRemainder['vertices'],localRemainder['triangles']))]
 for name,raw in sources:
  for eps_m in [1e-9,1e-10]:
   try:
    rebuilt=regular_local(raw,eps_m/I);candidate=mesh(affine(rebuilt,np.column_stack([B*I,origin])));metrics=proof(record,parts,candidate)
    if metrics['status']!='PASS':
     numeric=[v for k,v in metrics.items() if k.endswith('In3') and k not in ['blankIn3','installedIn3','wasteIn3']]
     if max(numeric)<=1e-6:
      repaired,label=strict_readback_candidate(candidate,origin,B)
      if repaired is not None:candidate=repaired;metrics=proof(record,parts,candidate);name=name+'; '+label
    attempts.append({'method':name,'planeWeldToleranceM':eps_m,'rawSignedSourceVolumeIn3':raw.volume(),'result':metrics})
    if metrics['status']=='PASS':
     fixed={**record,'declared_exterior_offcut':candidate,'outside_in3':metrics['worldInstalledOutsideBlankIn3'],'reconstruction_in3':metrics['worldPartitionDifferenceIn3'],'serializedWasteReadbackRepair':{'method':name,'planeWeldToleranceM':eps_m,'installedChildrenAndBlankUnchanged':True,'originalWasteGeometrySHA256':geom_fingerprint(old),'final':metrics}};return fixed,{'status':'PASS','changed':True,'initial':initial,'final':metrics,'attempts':attempts}
   except Exception as e:attempts.append({'method':name,'planeWeldToleranceM':eps_m,'error':str(e)[:300]})
 return None,{'status':'BLOCKED','changed':False,'initial':initial,'attempts':attempts}
