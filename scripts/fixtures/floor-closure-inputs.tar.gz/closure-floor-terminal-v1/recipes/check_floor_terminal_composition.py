from closure_hardware import *
import importlib.util
def main():
 package=HERE/'closure-floor-terminal-v1';spec=importlib.util.spec_from_file_location('compose_floor_terminal',package/'compose_floor.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);paths=[Path(__file__),package/'compose_floor.py',DEST/'frozen-context.json.gz',DEST/'closure-final-raw-wood-patch.json.gz',OUT/'main-wall-raw-unbored-wood.json.gz',ROOT/'src/floor-foundation-solids.json'];fd=read(paths[-1]);paths.append(ROOT/'src'/fd['geometryArchive']);paths+=list((package/'assets').glob('*'));guards={str(p):sha(p)for p in paths};ctx=load_context();core=payload(paths[3]);raw=payload(paths[4]);P={**ctx['parts'],**raw['add_parts'],**core['replace_new_envelope_parts'],**core['add_parts']};arc=payload(paths[6])['parts']
 for p0 in fd['parts']:
  p=copy.deepcopy(p0)
  if p.get('geometry_ref'):p.update(arc[p['geometry_ref']])
  if p.get('triangles')and not p.get('is_fastener'):P[p['id']]=p
 first=mod.apply({'parts':P});print('FIRST composed',flush=True);second=mod.apply(first);print('SECOND composed',flush=True);fr=payload(package/'assets/floor-return-final-raw-wood-patch.json.gz');f=payload(package/'assets/floor-return-physical-films-v2.json.gz');refs={**fr['replace_new_envelope_parts'],**fr['add_parts'],**f['replaceNewEnvelopeParts_READBACK_ONLY']};errors=[];metrics=[]
 for pid,p in refs.items():
  a=first['parts'][pid];difference=diff(native_solid(a),native_solid(p))/I**3;idem=diff(native_solid(a),native_solid(second['parts'][pid]))/I**3;au=inspect_mesh(np.array(a['vertices']),np.array(a['triangles'],np.uint64),require_single=True);row={'id':pid,'referenceDifferenceIn3':difference,'secondApplicationDifferenceIn3':idem,'strictRAW':au['status']};metrics.append(row)
  outside=amount(native_solid(a)-native_solid(p))/I**3;row['currentOutsideReferenceIn3']=outside
  if max(outside,idem)>1e-6 or au['status']!='PASS':errors.append(row)
 H=payload(package/'assets/floor-return-hardware-final-film-receivers.json.gz')['parts'];rays=[]
 for fid,h in H.items():
  purchases={}
  for rid in h['penetrationCheck']['requiredReceiverPurchaseIn']:
   for child in fr['splitConstructionGroups'].get(rid,[rid]):purchases[child]=ray_purchase(native_solid(first['parts'][child]),np.array(h['head_m']),np.array(h['axis_inward']),h['fastenerSpec']['lengthIn']*I)/I
  if not purchases or max(purchases.values())+1e-6<h['penetrationCheck']['minimumIn']:rays.append({'id':fid,'purchases':purchases})
 errors.extend(rays)
 write_gz(package/'proofs/current-reference-subset-variations.json.gz',{'scope':'Readback references only; CURRENT composition remains authoritative; two additional source-negative profile chips compared with earlier reference snapshots require stock recomputation against actual current children','parts':{r['id']:first['parts'][r['id']]for r in metrics if r['referenceDifferenceIn3']>1e-6},'rows':[r for r in metrics if r['referenceDifferenceIn3']>1e-6]})
 protected=[pid for pid in P if not pid.startswith(('ENV-','AIR-','LAP-'))and'CORK'not in pid and pid not in payload(package/'assets/book-foot-film-seats.json.gz')['requiredSourceMinusSeatTools']];bad=[pid for pid in protected if P[pid]!=first['parts'][pid]];end={str(p):sha(p)for p in paths};out={'status':'PASS'if not errors and not bad and guards==end else'BLOCKED','currentNegativeSubsetTargetsChecked':len(refs),'additionalReferenceSubsetVariations':[r for r in metrics if r['referenceDifferenceIn3']>1e-6],'611FreshCurrentRequiredPurchaseFailures':rays,'errors':errors,'protectedUnrelatedRecords':len(protected),'modifiedProtectedRecords':bad,'rows':metrics,'sourceGuardsAtStart':guards,'sourceGuardsAtEnd':end,'sourcesUnchangedDuringRun':guards==end,'scope':'Actual negative tools compose onto source NEW ENV and add only79 new returns, preserving existing canonical lower geometry except4 foot/actual cork pockets. No host readback substituted. Idempotence and256 strict current wood RAW checks. Earlier target snapshots are upper bounds, not replacements; two additional tiny negative profile variations are explicitly inventoried. Cork remains unchanged/import blocked.'};save(package/'proofs/composition-check.json',out);print('DONE',out['status'],len(errors),len(bad),flush=True)
if __name__=='__main__':main()
