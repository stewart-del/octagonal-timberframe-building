"""Candidate construction for waste only; final strict stock proof decides."""
from stock_raw_waste import *

def planes_for(record,parts,origin,B):
 v=(np.asarray(record['blank']['vertices'],float)-origin)@B/I;lo,hi=v.min(0),v.max(0);planes=[]
 for k in range(3):
  n=np.eye(3)[k]
  for value in [lo[k],hi[k]]:planes.append((n,value,0))
 for pid in record['children']:
  p=parts[pid];vv=(np.asarray(p['vertices'],float)-origin)@B/I;ff=np.asarray(p['triangles'],int)
  for ids in ff:
   tri=vv[ids];n=np.cross(tri[1]-tri[0],tri[2]-tri[0]);length=np.linalg.norm(n)
   if length<1e-14:continue
   n/=length
   if n[np.argmax(abs(n))]<0:n=-n
   d=float(n@tri[0])
   if not any(np.linalg.norm(n-nn)<1e-10 and abs(d-dd)<1e-10 for nn,dd,_ in planes):planes.append((n,d,1))
 return planes

def snap_vertices(vertices,planes,tol):
 out=[];shift=0
 for p in np.asarray(vertices,float):
  near=[(priority,abs(float(n@p-d)),n,d)for n,d,priority in planes if abs(float(n@p-d))<=tol];near.sort(key=lambda q:(q[0],q[1]));selected=[]
  for _,_,n,d in near:
   if any(abs(n@old[0])>1-1e-9 for old in selected):continue
   candidate=selected+[(n,d)];A=np.asarray([q[0]for q in candidate]);sing=np.linalg.svd(A,compute_uv=False)
   if sing[-1]<1e-8:continue
   selected=candidate
   if len(selected)==3:break
  q=p.copy()
  if selected:
   A=np.asarray([x[0]for x in selected]);rhs=np.asarray([x[1]for x in selected]);move=np.linalg.lstsq(A,rhs-A@p,rcond=1e-12)[0]
   if np.linalg.norm(move)<=tol*4:q=p+move
  q=np.round(q,12);shift=max(shift,float(np.linalg.norm(q-p)));out.append(q)
 return np.asarray(out),shift

def candidate_planes(raw,plane_tolerance_in):
 # This external CANDIDATE builder uses the same signed face-contours as
 # regular_local, but doesnotaccept/reject against aninvalid rawsurface's
 # scalar volume midway. Only final RAW/world/local STOCK partition proof
 # canaccept it. No auditor or global helper ischanged.
 vertices=raw.v;faces=raw.f;groups=[];tol=plane_tolerance_in;scale=1e6
 for ids in faces:
  p=vertices[ids];n=np.cross(p[1]-p[0],p[2]-p[0]);ln=np.linalg.norm(n)
  if ln<1e-20:continue
  n/=ln
  if n[np.argmax(abs(n))]<0:n=-n
  group=next((g for g in groups if np.linalg.norm(n-g['n'])<1e-9 and np.max(abs((p-g['origin'])@g['n']))<tol),None)
  if group is None:
   axis=np.eye(3)[np.argmin(abs(n))];u=np.cross(n,axis);u/=np.linalg.norm(u);group={'n':n,'origin':p[0],'basis':np.column_stack([u,np.cross(n,u)]),'contours':[]};groups.append(group)
  group['contours'].append((p-group['origin'])@group['basis']*scale)
 pool=[];regions=[]
 for point in vertices:
  if not any(np.linalg.norm(point-v)<=tol for v in pool):pool.append(point.copy())
 def weld(point):
  dist=np.linalg.norm(np.asarray(pool)-point,axis=1);nearest=int(np.argmin(dist))
  if dist[nearest]<=tol:return nearest
  pool.append(point);return len(pool)-1
 for group in groups:
  for sign,fill in [(1,m.FillRule.Positive),(-1,m.FillRule.Negative)]:
   section=m.CrossSection(group['contours'],fill)
   if section.is_empty():continue
   loops=[]
   for poly in section.to_polygons():
    points=group['origin']+np.asarray(poly)/scale@group['basis'].T;loops.append([weld(p)for p in points])
   regions.append((group,sign,loops))
 points=np.asarray(pool);out=[]
 for group,sign,loops in regions:
  contours=[];ids=[]
  for loop in loops:
   split=[]
   for start,end in zip(loop,loop[1:]+loop[:1]):
    a,b=points[start],points[end];edge=b-a;length2=float(edge@edge)
    if length2<=tol*tol:continue
    t=(points-a)@edge/length2;dist=np.linalg.norm(points-(a+t[:,None]*edge),axis=1);middle=np.flatnonzero((t>1e-10)&(t<1-1e-10)&(dist<=tol));split.extend([start]+sorted(middle.tolist(),key=lambda k:t[k]))
   if len(split)<3:continue
   contours.append((points[split]-group['origin'])@group['basis']);ids.extend(split)
  if not contours:continue
  for tri in m.triangulate(contours,epsilon=1e-12,allow_convex=False):
   mapped=[ids[int(i)]for i in tri];out.append(mapped if sign>0 else mapped[::-1])
 used=sorted(set(i for tri in out for i in tri));mp={x:j for j,x in enumerate(used)};s=m.Manifold(m.Mesh64(points[used],np.asarray([[mp[i]for i in tri]for tri in out],np.uint64)));assert str(s.status())=='Error.NoError',str(s.status());return s

def targeted_rebuild(record,parts):
 origin,B=stock_frame(record['blank']);planes=planes_for(record,parts,origin,B);lb=native_local(record['blank'],origin,B);li=union([native_local(parts[k],origin,B)for k in record['children']]);fresh=mesh(lb-li);sources=[('old RAW before native',in_local(record['declared_exterior_offcut'],origin,B)),('fresh local remainder RAW',RawBoundary(fresh['vertices'],fresh['triangles']))];attempts=[]
 for label,raw in sources:
  for snap_m in [1e-10,5e-10,1e-9,2e-9,5e-9]:
   vv,maxshift=snap_vertices(raw.v,planes,snap_m/I)
   for weld_m in [1e-10,5e-10,1e-9]:
    try:
     built=candidate_planes(RawBoundary(vv,raw.f),weld_m/I)
     for final_snap in [False,True]:
      q=mesh(built)
      if final_snap:
       q['vertices'],_=snap_vertices(np.asarray(q['vertices']),planes,snap_m/I);q['vertices']=q['vertices'].tolist()
       built2=candidate_planes(RawBoundary(q['vertices'],q['triangles']),weld_m/I);q=mesh(built2)
      world=mesh(affine(native_solid(q),np.column_stack([B*I,origin])));metrics=proof(record,parts,world);attempts.append({'source':label,'snapM':snap_m,'weldM':weld_m,'postSnap':final_snap,'maxVertexShiftIn':maxshift,'metrics':metrics})
      if metrics['status']=='PASS':return world,{'status':'PASS','method':'Exact source-plane projection ofwasteonly, signed rawcontourrebuild','attempts':attempts,'final':metrics}
    except Exception as e:attempts.append({'source':label,'snapM':snap_m,'weldM':weld_m,'error':str(e)[:150]})
 return None,{'status':'BLOCKED','attempts':attempts}
