"""Separate positive waste chunks, cut only AFTER installed pieces extracted."""
from stock_waste_plane_snap import *

def pieces_proof(record,parts,pieces):
 origin,B=stock_frame(record['blank']);b=native_solid(record['blank']);cs=[native_solid(parts[k])for k in record['children']];s=union(cs);ws=[native_solid(p)for p in pieces];w=union(ws);lb=native_local(record['blank'],origin,B);lcs=[native_local(parts[k],origin,B)for k in record['children']];ls=union(lcs);lws=[native_local(p,origin,B)for p in pieces];lw=union(lws);checks=[inspect_mesh(np.array(p['vertices']),np.array(p['triangles'],np.uint64),require_single=True)for p in pieces];overlap=sum(amount(a^bb)for j,a in enumerate(ws)for bb in ws[:j]);loverlap=sum(amount(a^bb)for j,a in enumerate(lws)for bb in lws[:j]);metrics={'strictWastePieceChecks':[{'status':x['status'],'failures':x['failures']}for x in checks],'positivePieceCount':len(pieces),'allPieceVolumesPositive':all(q.volume()>0 for q in ws),'blankIn3':b.volume()/I**3,'installedIn3':sum(q.volume()for q in cs)/I**3,'wasteIn3':sum(q.volume()for q in ws)/I**3,'worldScalarBalanceIn3':abs(b.volume()-sum(q.volume()for q in cs)-sum(q.volume()for q in ws))/I**3,'worldPartitionDifferenceIn3':diff(b,s+w)/I**3,'worldWasteInstalledOverlapIn3':amount(s^w)/I**3,'worldWasteOutsideBlankIn3':amount(w-b)/I**3,'worldInstalledOutsideBlankIn3':amount(s-b)/I**3,'worldBetweenWastePiecesOverlapIn3':overlap/I**3,'localScalarBalanceIn3':abs(lb.volume()-sum(q.volume()for q in lcs)-sum(q.volume()for q in lws)),'localPartitionDifferenceIn3':diff(lb,ls+lw),'localWasteInstalledOverlapIn3':amount(ls^lw),'localWasteOutsideBlankIn3':amount(lw-lb),'localInstalledOutsideBlankIn3':amount(ls-lb),'localBetweenWastePiecesOverlapIn3':loverlap};num=[v for k,v in metrics.items()if k.endswith('In3')and k not in ['blankIn3','installedIn3','wasteIn3']];metrics['status']='PASS' if all(c['status']=='PASS'for c in checks)and metrics['allPieceVolumesPositive']and max(num,default=0)<=1e-6 else'BLOCKED';return metrics

def candidates_for_cell(cell,origin,B):
 toWorld=np.column_stack([B*I,origin]);raw=mesh(cell);rb=RawBoundary(raw['vertices'],raw['triangles']);choices=[]
 variants=[('directsplit',cell)]
 for eps_m in [1e-10,2e-10,5e-10,1e-9]:
  try:variants.append(('rawplanes'+str(eps_m),regular_local(rb,eps_m/I)))
  except Exception:pass
 for label,s in variants:
  q=mesh(affine(s,toWorld));au=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64),require_single=True)
  if au['status']!='PASS':continue
  actual=native_local(q,origin,B);score=diff(cell,actual)
  choices.append((score,label,q))
 if not choices:return None,{'status':'NO_STRICT_CELL','volumeIn3':cell.volume()}
 choices.sort(key=lambda q:q[0]);score,label,q=choices[0];return q,{'status':'PASS','sourceNativeCellDifferenceIn3':score,'method':label,'volumeIn3':native_solid(q).volume()/I**3}

def split_waste(record,parts):
 origin,B=stock_frame(record['blank']);lb=native_local(record['blank'],origin,B);ls=union([native_local(parts[k],origin,B)for k in record['children']]);waste=lb-ls;v=np.asarray(lb.to_mesh64().vert_properties)[:,:3];lo,hi=v.min(0),v.max(0);iv=np.vstack([in_local(parts[k],origin,B).v for k in record['children']]);ic=(iv.min(0)+iv.max(0))/2;plans=[]
 for axis in [2,1,0]:
  for values in [[ic[axis]],[lo[axis]+.01,ic[axis],hi[axis]-.01],[lo[axis]+.1,ic[axis],hi[axis]-.1],[lo[axis]+.01,lo[axis]+.1,ic[axis],hi[axis]-.1,hi[axis]-.01]]:
   values=sorted(set(float(x)for x in values if lo[axis]+1e-8<x<hi[axis]-1e-8));plans.append((axis,values))
 attempts=[]
 for axis,values in plans:
  normal=np.eye(3)[axis];cells=[waste]
  for value in values:
   nextcells=[]
   for cell in cells:
    for child in [cell.trim_by_plane(normal.tolist(),value),cell.trim_by_plane((-normal).tolist(),-value)]:
     if child.volume()>1e-12:nextcells.append(child)
   cells=nextcells
  components=[];badNegative=False;residual=0
  for cell in cells:
   for c in cell.decompose():
    if c.volume()<=1e-12:residual+=abs(c.volume())
    else:components.append(c)
  if residual>1e-6:attempts.append({'axis':axis,'cutsIn':values,'status':'NEGATIVE_OR_RESIDUAL_VOLUME','residueIn3':residual});continue
  pieces=[];cellproof=[]
  for i,c in enumerate(components):
   q,pr=candidates_for_cell(c,origin,B);cellproof.append(pr)
   if q is None:break
   pieces.append({'id':record['id']+f'-WASTE-{i:02}','sourceStockId':record['id'],'wasteOnly':True,'cutAfterInstalledPiecesExtracted':True,**q})
  if len(pieces)!=len(components):attempts.append({'axis':axis,'cutsIn':values,'status':'RAW_CELL_BLOCKED','cellProof':cellproof});continue
  metrics=pieces_proof(record,parts,pieces);attempts.append({'axis':axis,'cutsIn':values,'cellProof':cellproof,'metrics':metrics,'numericalResidualIn3':residual})
  if metrics['status']=='PASS':
   fixed={k:v for k,v in record.items()if k!='declared_exterior_offcut'};fixed.update(declared_exterior_offcut_pieces=pieces,wasteRepresentation='independent_positive_closed_chunks',outside_in3=metrics['worldInstalledOutsideBlankIn3'],reconstruction_in3=metrics['worldPartitionDifferenceIn3'],serializedWasteReadbackRepair={'method':'Separatepositivewastechunks; handlingcutsAFTERallinstalledpiecesextracted','stockLocalOriginM':origin.tolist(),'stockLocalBasis':B.tolist(),'splitAxis':axis,'splitPlanesIn':values,'final':metrics});return fixed,{'status':'PASS','attempts':attempts,'final':metrics}
 return None,{'status':'BLOCKED','attempts':attempts}
