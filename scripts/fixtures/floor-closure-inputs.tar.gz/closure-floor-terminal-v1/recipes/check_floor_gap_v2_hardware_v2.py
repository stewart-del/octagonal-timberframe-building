from build_core_causal_metadata import ray_intervals
from closure_hardware import *
def floor_phase(pid):
 if pid.startswith('ENV-')or pid.startswith('LAP-'):return 100
 if pid.startswith('AIR-'):
  if 'BASE-RAIL-BEARING'in pid:return 30
  if 'PLINTH-PACKER'in pid:return 25
  if 'BACKER'in pid:return 10
  if 'FLOOR-RETURN'in pid:return 20
 return 0
def main():
 paths=[Path(__file__),DEST/'floor-return-physical-films-v2.json.gz',DEST/'floor-return-final-raw-wood-patch.json.gz',DEST/'floor-return-hardware-final-film-receivers.json.gz',DEST/'floor-return-final-hardware-instances.json.gz',DEST/'closure-final-raw-wood-patch.json.gz',DEST/'floor-return-local-release-check.json',ROOT/'src/floor-foundation-solids.json'];fd=read(paths[-1]);paths.append(ROOT/'src'/fd['geometryArchive']);arc=payload(paths[-1])['parts'];ctx=load_context();core=payload(paths[5]);fr=payload(paths[2]);d=payload(paths[1]);H=payload(paths[3])['parts'];sourceInstances={p['id']:p for p in payload(paths[4])['instances']};P={**ctx['parts'],**core['replace_new_envelope_parts'],**core['add_parts'],**fr['replace_new_envelope_parts'],**fr['add_parts'],**d['replaceNewEnvelopeParts_READBACK_ONLY']}
 for p0 in fd['parts']:
  p=copy.deepcopy(p0)
  if p.get('geometry_ref'):p.update(arc[p['geometry_ref']])
  if p.get('triangles')and not p.get('is_fastener'):P[p['id']]=p
 for module in list(sys.modules.values()):
  p=getattr(module,'__file__',None)
  if p and str(p).endswith('.py')and(str(p).startswith(str(HERE))or str(p).startswith(str(ROOT/'scripts'))):paths.append(Path(p))
 paths=list(dict.fromkeys(paths));guards={str(p):sha(p)for p in paths};native={};errors=[];rows=[];delta={};subset=[]
 def solid(pid):
  if pid not in native:native[pid]=native_solid(P[pid])
  return native[pid]
 for fid,p in H.items():
  head=np.array(p['head_m']);axis=np.array(p['axis_inward']);L=p['fastenerSpec']['lengthIn']*I;minIn=p['penetrationCheck']['minimumIn'];actual={};required=set()
  for rid in p['penetrationCheck']['requiredReceiverPurchaseIn']:
   required.update(fr['splitConstructionGroups'].get(rid,[rid]))
  for rid in required:
   actual[rid]=ray_purchase(solid(rid),head,axis,L)/I
  if not actual or max(actual.values())+1e-6<minIn:errors.append({'id':fid,'requiredActualPurchaseIn':actual,'minimumIn':minIn})
  allowed=[];inward={};later=[];uncertain=[];phase=floor_phase(p['parentId'])
  for rid in p['receiverIds']:
   if rid not in P:errors.append({'id':fid,'missingReceiver':rid});continue
   ins=ray_intervals(solid(rid),head,axis,L);out=ray_intervals(solid(rid),head,-axis,p['withdrawal_distance_m']);inward[rid]=ins
   if rid==p['parentId']or floor_phase(rid)<phase or(floor_phase(rid)==phase and(rid in required or(ins and not out))):allowed.append(rid)
   elif floor_phase(rid)>phase:later.append(rid)
   else:uncertain.append(rid)
  if p['parentId']not in allowed:allowed.append(p['parentId'])
  sourcePose=sourceInstances[fid];desc={k:sourcePose[k]for k in ['mesh_instance','head_m','axis_inward','withdrawal_direction','withdrawal_distance_m']if k in sourcePose};rows.append({'id':fid,'parentId':p['parentId'],'actualRequiredPurchaseIn':actual,'minimumIn':minIn});delta[fid]={'parentId':p['parentId'],'sourceReceiverIds':p['receiverIds'],'withdrawalReceiverIds':sorted(set(allowed)),'assemblyPrerequisiteWoodIds':sorted(set(allowed)),'declaredFloorAssemblyPhase':phase,'inwardActualCenterlineIntervalsIn':inward,'laterStaticContactIds':later,'uncertainSamePhaseStaticContacts':uncertain,'flexibleWeatherReceiverIds':p.get('flexibleWeatherReceiverIds',[]),'filmHeadSealPriorRemoval':'All overlying adhesive films and required field head patches must be peeled/released first; no flexible/metal layer is an axial wood exemption.','sourcePoseDescriptor':desc,'sourcePoseSHA256':hashlib.sha256(json.dumps(desc,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'remainingCausalScope':'Metadata for actual static wood embeds only. Full outward body sweep and later wall/film/threshold obstacles remain owner-master work.'}
 # Every changed wood piece is a negative-only subset, so the original
 # translation paths remain valid in the SAME frozen retained scene.
 oldP={**fr['replace_new_envelope_parts'],**fr['add_parts']}
 for pid,p in d['replaceNewEnvelopeParts_READBACK_ONLY'].items():
  source=oldP.get(pid,core['replace_new_envelope_parts'].get(pid,core['add_parts'].get(pid,ctx['parts'].get(pid))))
  outside=amount(native_solid(p)-native_solid(source))/I**3;subset.append({'id':pid,'newOutsidePreFilmSourceIn3':outside})
  if outside>1e-6:errors.append(subset[-1])
 release=payload(paths[6]);groups=defaultdict(list)
 for pid,p in fr['add_parts'].items():groups[p.get('constructionGroupId',pid)].append(pid)
 inventory=[{'logicalGroupId':k,'physicalWoodIds':v,'physicalActorCount':len(v),'routeType':'individual'if len(v)==1 else'simultaneous physical children'}for k,v in groups.items()];end={str(p):sha(p)for p in paths};out={'status':'PASS'if not errors and guards==end else'BLOCKED','hardwareCount':len(H),'hardwareRayFailures':errors,'freshRequiredPurchaseReceipts':rows,'negativeOnlyWoodChecks':subset,'sourceGuardsAtStart':guards,'sourceGuardsAtEnd':end,'sourcesUnchangedDuringRun':guards==end,'hardwarePositionsChanged':0,'releaseQualification':{'frozenOriginalReportStatus':release['status'],'logicalGroups':len(groups),'physicalWoodIds':len(fr['add_parts']),'multiActorGroups':sum(len(v)>1 for v in groups.values()),'continuousLegs':release['legCount'],'claim':'Monotone negative-subset continuation of the original reference-scene proof. Not a fresh current-root planner proof; no individual route claim for simultaneous groups.'},'releaseGroupInventory':inventory,'scope':'611 fresh required wood-ray purchases after actual 1/8in GP gap and .400mm seats; stock proof separate; no load, coating-adhesion or building airtightness claim.'};save(DEST/'floor-gap-v2-hardware-check.json',out);write_gz(DEST/'floor-gap-v2-causal-metadata.json.gz',{'fasteners':delta,'sourceGuards':guards,'assemblyPhaseRules':'Retained floor0; return backers10; GPreturns20; plinthpackers25; fixed basebearings30; later ENV/LP100. Only earlier actual wood/physical parent or explicit same-phase inward embeds exempted; films/metal never exempted.'});print('DONE',out['status'],len(H),len(errors),flush=True)
if __name__=='__main__':main()
