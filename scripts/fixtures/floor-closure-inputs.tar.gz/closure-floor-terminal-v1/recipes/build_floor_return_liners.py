#!/usr/bin/env python3
"""Rebated, fixed-gauge NEW-GP liners preserve every frozen floor229 film."""
from build_physical_eave_seals import *
from floor_surface_normalization import normalize_one

def gz(p):return json.loads(gzip.decompress(p.read_bytes()))
def main():
 ctx=load_context();core=gz(DEST/'closure-final-raw-wood-patch.json.gz');fr=gz(DEST/'floor-return-final-raw-wood-patch.json.gz');old=gz(DEST/'floor-films-229-frozen.json.gz');fd=read(ROOT/'src/floor-foundation-solids.json');arc=gz(ROOT/'src'/fd['geometryArchive'])['parts'];originalfloor={}
 for p0 in fd['parts']:
  if p0.get('is_fastener'):continue
  p=copy.deepcopy(p0)
  if p.get('geometry_ref'):p.update(arc[p['geometry_ref']])
  if p.get('triangles'):originalfloor[p['id']]=p
 ctx['parts'].update(originalfloor);ctx['parts'].update(core['replace_new_envelope_parts']);ctx['parts'].update(core['add_parts']);ctx['parts'].update(fr['replace_new_envelope_parts']);ctx['parts'].update(fr['add_parts'])
 for p in parts_list(gz(HERE/'porch-pan-isolation-candidate.json.gz')['parts']):ctx['parts'][p['id']]=p
 floor=ctx['mainFaces'][0]['floorDeckTopM'];layouts=gz(DEST/'floor-return-wood-raw-parts.json.gz')['faceLayouts'];T=.0004;oldfilms={**old['bootParts'],**old['parts']};planned={};metadata={};tools=defaultdict(list);newwood={};proofs=[];FM=np.column_stack([[1,0,0],[0,0,1],UP,np.zeros(3)]);heads=m.CrossSection()
 for pid,p in ctx['parts'].items():
  if pid.startswith('POST-BEARING-STAND-') and pid.endswith('-HEAD'):heads=heads+affine(native_solid(p),invert(FM)).project().offset(.0625*I,m.JoinType.Miter)
 headtool=affine(heads.extrude(.2).translate([0,0,-.05]),FM)
 def plan(pid,s,role,length,receivers,product='SIGA Rissan430grey300 #2610-030025.03',width=300,**kw):planned[pid]=s;metadata[pid]={'role':role,'length':length,'receivers':receivers,'product':product,'width':width,**kw}
 for f in layouts:
  name=f['face'];M=np.array(f['basis']);a=f['postChordApothemM'];h=(a+6.25*I)*math.tan(math.pi/8);nw=6.25*I
  # Published .400mm film sits in a machined .400mm NEW plywood rebate.
  # Exposed filmplanes stay exactlyfloorY andwallN, so sharedboots229 and
  # the3mm cork/finish0 do notmove. No structuralfloor GP is cut.
  s=affine(miter_face(profile_prism([[floor-T,0],[floor,0],[floor,nw],[floor+.075,nw],[floor+.075,nw+T],[floor-T,nw+T]],-h,h),M,a),M)-headtool
  if name=='W':
   for x0,x1 in [(-48,-18.7007874),(18.7007874,48)]:s=s-affine(posbox([x0*I,floor-I,2*I],[x1*I,.1,10*I]),M)
   # DoorRO has no GPwall substrate; liner stops at its jambs while its
   # horizontal floorleg remains beneath actual threshold bearing.
   s=s-affine(posbox([-18.7007874*I,floor,6.25*I],[18.7007874*I,.1,7*I]),M)
  plan('AIR-RETURN-'+name+'-RECESSED-LINER',s,'one_fixed_width_recessed_GPfloor_wall_air_liner',2*h+.04,f['sheetIds']+['ENV-'+name+'-PLY'],selectedDevelopedWidthMm=(nw+.075+T)*1000,fieldMiterGapIn=.125)
 # Two AIR bridges have25.4mm concrete-end laps. They are protected by a
 # separately required rainplinth/counterflashing; no exteriorweather claim.
 f=next(f for f in layouts if f['face']=='W');M=np.array(f['basis']);nn=2.125*I;nf=4.375*I;nw=6.25*I;start=-.5*I
 prof=[[floor,start],[floor+T,start],[floor+T,nn],[T,nn],[T,nf],[floor+T,nf],[floor+T,nw-T],[floor+.075,nw-T],[floor+.075,nw],[floor,nw],[floor,nf-T],[0,nf-T],[0,nn+T],[floor,nn+T]]
 for tag,x0,x1 in [('L',-48,-18.7007874),('R',18.7007874,48)]:
  pid='AIR-W-PAN-BRIDGE-'+tag;ni=2.25*I;no=4.25*I
  near=[[floor-2*T,0],[floor-T,0],[floor-T,ni],[floor-.06,ni],[floor-.06,ni-T],[floor-2*T,ni-T]]
  far=[[floor-.06,no],[floor+T,no],[floor+T,nw-T],[floor+.075,nw-T],[floor+.075,nw],[floor,nw],[floor,no+T],[floor-.06,no+T]]
  for label,profile in [('INNER',near),('OUTER',far)]:
   plan(pid+'-'+label,affine(profile_prism(profile,x0*I,x1*I),M),'concrete_sideface_to_GP_floor_wall_air_return',(x1-x0)*I+.1,['AIR-W-FLOOR-RETURN-0','AIR-W-FLOOR-RETURN-1','MUD-PAN-BACK-'+tag,'ENV-W-PLY'],selectedConcreteAdhesionLegMm=60,concreteBoundary='Solidconcretebetweenindependentsidefilms; anycrack/coldjointrequiresaccessiblecompatiblejointseal. No filmoverretainedgirt/concretetop.')
  for side,xx,sg in [('L',x0,-1),('R',x1,1)]:
   L=.03;cp=[[-L,ni-2*T],[T,ni-2*T],[T,no+2*T],[-L,no+2*T],[-L,no+T],[0,no+T],[0,ni-T],[-L,ni-T]];A=np.column_stack([UP,sg*M[:,0],M[:,2],M[:,3]+M[:,0]*xx*I]);end=affine(profile_prism(cp,floor-.06,floor),A);B=np.column_stack([sg*M[:,0],UP,M[:,2],M[:,3]+M[:,0]*xx*I]);flange=affine(posbox([0,floor,ni-2*T],[.0254,floor+T,no+2*T]),B)
   plan(pid+'-END-'+side,end+flange,'endface_wrap_lapped_30mm_on_both_concrete_side_films',no-ni+.1,[pid+'-INNER',pid+'-OUTER','MUD-PAN-BACK-'+tag]+f['sheetIds'],product='SIGA Rissan430grey150 #2610-015025.03',width=150,selectedSideFilmLapMm=30,selectedGPfloorLapMm=25.4)
 # Precutthe recessedwestliner at actualendwraptongues; laterendcapfloorflangessealoverthese.
 for lid in [pid for pid in planned if pid.startswith('AIR-RETURN-W-RECESSED')]:
  for eid in [pid for pid in planned if '-PAN-BRIDGE-' in pid and '-END-' in pid]:
   if boxes_overlap(planned[lid].bounding_box(),planned[eid].bounding_box()) and amount(planned[lid]^planned[eid])>TOL:planned[lid]=planned[lid]-planned[eid]
 write_gz(DEST/'floor-return-planned-films.json.gz',{'parts':{pid:mesh(s) for pid,s in planned.items()},'metadata':metadata})
 # NEW-GP filmseat: only the actual .400mm liner volume is recessed; no
 # primary/old GP/steel edit. Broad planar machinecuts and fieldcorner
 # notches are cuttable surfaces, not a molded adhesive internalprofile.
 for pid,p in ctx['parts'].items():
  isgp=(pid.startswith('ENV-') and '-PLY-' in pid) or ('AIR-' in pid and '-FLOOR-RETURN-' in pid and 'BACKER' not in pid)
  iswest=(pid.startswith('AIR-W-FLOOR-RETURN-')) or (pid.startswith('ENV-W-') and '-PLY-' not in pid) or pid.startswith('AIR-W-PAN-PLINTH-PACKER')
  if not(isgp or iswest):continue
  before=native_solid(p);after=before
  face=pid.split('-')[1];frame=next(np.array(f['basis']) for f in layouts if f['face']==face);local=affine(before,invert(frame))
  for fid,s in planned.items():
   if not boxes_overlap(after.bounding_box(),s.bounding_box()) or amount(after^s)<=TOL:continue
   if '-RECESSED-LINER' in fid and not isgp:continue
   if '-PAN-BRIDGE-' in fid and not iswest:continue
   local=local-affine(s,invert(frame));after=affine(local,frame);tools[pid].append({'filmId':fid,**mesh(s)})
  if pid not in tools:continue
  q=mesh(after);a=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64))
  if a['status']!='PASS':
   frameRecord={'axis':frame[:,0].tolist(),'width':frame[:,1].tolist(),'depth':frame[:,2].tolist()}
   q,proof=normalize_one({'id':pid,'stock_frame':frameRecord,**q},a['failures'])
  newwood[pid]={**p,**q,'floorAirFilmSeat':'Actual .400mm plane rebate inNEWGP; Westbridge film fitting onlyNEWENV/plinth. Primary28floorGP/P/rails/steel untouched.'};proofs.append({'id':pid,'removedIn3':amount(before-native_solid(q))/I**3})
 ctx['parts'].update(newwood);F=Film(ctx,{});F.solids={pid:native_solid(p) for pid,p in oldfilms.items()}
 for pid,s in planned.items():
  r=metadata[pid];kw={k:v for k,v in r.items() if k not in ['role','length','receivers','product','width']};
  try:F.add(pid,s,r['role'],r['length'],r['receivers'],product=r['product'],width=r['width'],T=T,**kw)
  except AssertionError:
   failed,trimmed=F.fit(s);write_gz(DEST/'floor-return-failed-film-readback.json.gz',{'id':pid,**mesh(failed),'trimmed':trimmed});raise
  write_gz(DEST/'floor-return-liner-checkpoint.json.gz',{'parts':F.parts,'newwood':newwood,'tools':dict(tools),'proofs':proofs,'metadata':metadata,'cuts':F.cuts})
 # Eight60mm inner seams overlap both existing floor and rebated liner; all
 # prior frozen229 terrain is explicit. No separate mid-sheet strips are
 # necessary because each233.75mm-wide liner covers its full sheet joint.
 for f in layouts:
  M=np.array(f['basis']);h=(f['postChordApothemM']+6.25*I)*math.tan(math.pi/8);SM=np.column_stack([M[:,0],M[:,2],UP,M[:,3]+UP*floor]);foot=m.CrossSection([[[-h,-.03],[h,-.03],[h,.03],[-h,.03]]],m.FillRule.EvenOdd);foot=foot-affine(headtool,invert(SM)).project().offset(.1875*I,m.JoinType.Miter);print('innerseam',f['face'],flush=True);retained=F.solids;F.solids={pid:ss for pid,ss in retained.items() if pid in oldfilms or 'INNER-SEAM' in pid};coated=F.coat(foot,SM);F.solids=retained;F.add('AIR-RETURN-'+f['face']+'-INNER-SEAM',coated,'current_floor_to_recessed_liner_joint',2*h+.04,f['sheetIds'],product='SIGA Wigluv60 #7510-6040',width=60,T=.00035,selectedAdhesionLegMm=30)
 # New60mm strips only touch cork. Buildable1.45mm underside fitting pocket
 # composes withfrozen1.10mm pockets; no floorfinish/3.000mmstock scaling.
 CFM=np.column_stack([[1,0,0],[0,0,1],UP,[0,floor,0]]);planfoot=m.CrossSection()
 for p in F.parts.values():
  if 'INNER-SEAM' in p['id']:planfoot=planfoot+affine(native_solid(p),invert(CFM)).project()
 pocket=affine(planfoot.extrude(.00145),CFM);cork={}
 for pid,p in originalfloor.items():
  if 'CORK' not in pid:continue
  before=native_solid(p)
  if boxes_overlap(before.bounding_box(),pocket.bounding_box()) and amount(before^pocket)>TOL:cork[pid]={**p,**mesh(before-pocket)}
 total=defaultdict(float)
 for r in F.cuts:total[r['product']]+=r['cutLengthM']
 out={'parts':F.parts,'cutSchedule':F.cuts,'consumptionM':dict(total),'rolls25mWith20PercentAllowance':{k:math.ceil(v*1.2/25) for k,v in total.items()},'requiredAdditionalNewEnvelopeToolSequence':dict(tools),'replaceNewEnvelopeParts_READBACK_ONLY':newwood,'newWoodSeatDeltas':proofs,'requiredAdditionalCurrentCorkPocketCutTool':mesh(pocket),'replaceCurrentCorkParts_READBACK_ONLY':cork,'additionalCorkPocketDepthMm':1.45,'sourceFrozen229SHA256':sha(DEST/'floor-films-229-frozen.json.gz'),'sourceFloorReturnSHA256':sha(DEST/'floor-return-final-raw-wood-patch.json.gz'),'scope':'RecessedNEWGP film plane leaves shared229 films/current3mm cork/finish0fixed. Selectedfolds andadhesionlegs are actualgeometryproposal, not factorybendCAD/testedassembly.','limits':['No original28GP/primaryP/rails/steel/concrete edits','All GP/ENV negative tools must compose onlatest owner solids and preserve later cavities','Solidconcreteupstands joinbondedinner/outer/endfilms; concretecracks/coldjoints requireactualsealdesignandnotestclaimed','Westexteriorrainplinth/counterflashing separate; OEMdoorframe→threshold inner seal remains separate','No testedairtightness/climatevapour/capacity/coatingcompatibility claim']};write_gz(DEST/'floor-return-physical-films.json.gz',out);write_gz(DEST/'floor-return-films-raw-parts.json.gz',{'add_parts':F.parts,'stock':{},'replaceNewEnvelopeParts':{**ctx['parts'],**oldfilms},'replaceCorkUndersideParts':cork});print('DONE',len(F.parts),len(newwood),dict(total),flush=True)
if __name__=='__main__':main()
