#!/usr/bin/env python3
"""Finalize separate24film delta, compositionalNEWstock seats and receipts."""
from closure_hardware import *
from floor_surface_normalization import normalize_one

def main():
 ctx=load_context();core=payload(DEST/'closure-final-raw-wood-patch.json.gz');fr=payload(DEST/'floor-return-final-raw-wood-patch.json.gz');d=payload(DEST/'floor-return-physical-films.json.gz');adapter=payload(DEST/'floor-return-films-raw-parts.json.gz');P=d['parts'];allp={**ctx['parts'],**core['replace_new_envelope_parts'],**core['add_parts'],**fr['replace_new_envelope_parts'],**fr['add_parts'],**d['replaceNewEnvelopeParts_READBACK_ONLY']};newwood=d['replaceNewEnvelopeParts_READBACK_ONLY'];source=allp['AIR-W-BASE-RAIL-BEARING'];before=native_solid(source);fid='AIR-W-PAN-BRIDGE-R-END-R';tool=native_solid(P[fid]);after=before-tool;q=mesh(after);au=inspect_mesh(np.array(q['vertices']),np.array(q['triangles'],np.uint64))
 if au['status']!='PASS':q,proof=normalize_one({'id':source['id'],**q},au['failures'])
 newwood[source['id']]={**source,**q,'additionalEndWrapGPFilmSeat':True};allp.update(newwood);d['requiredAdditionalNewEnvelopeToolSequence'].setdefault(source['id'],[]).append({'filmId':fid,**mesh(tool)});d['newWoodSeatDeltas'].append({'id':source['id'],'removedIn3':amount(before-native_solid(q))/I**3,'purpose':'Actual.400mm endwrap floorflange; onlyNEWbasebearing changed'})
 # Replace logicalplaceholderreceivers with actual currentphysicalsupport
 # IDs. A5micrometre analyticalprobe detects planar area contact only; it
 # changesnoneofthegeometry or the strictnonoverlap tolerance.
 old=payload(DEST/'floor-films-229-frozen.json.gz');oldfilms={**old['bootParts'],**old['parts']};candidates={**newwood,**{pid:p for pid,p in allp.items() if pid.startswith('MUD-PAN-BACK-')},**oldfilms};ns={pid:native_solid(p) for pid,p in candidates.items()};eps=.000005;contacts=[]
 for pid,p in P.items():
  s=native_solid(p);real=[]
  for rid,r in ns.items():
   b=np.array(s.bounding_box());bb=np.array(r.bounding_box())
   if not(np.all(b[3:]+eps>bb[:3]) and np.all(b[:3]-eps<bb[3:])):continue
   hit=0
   for direction in np.eye(3):
    hit=max(hit,amount(s.translate((direction*eps).tolist())^r),amount(s.translate((-direction*eps).tolist())^r))
   if hit>max(TOL,eps*1e-8):real.append(rid)
  p['logicalReceiverReferences']=p['receiverIds'];p['receiverIds']=sorted(real);p['receiverContactProbeM']=eps;p['receiverContactQualification']='Analyticalsmallnormalcontactprobe only; not adhesivecapacity/minimumbondlengthverification';contacts.append({'filmId':pid,'actualPhysicalReceiverIds':sorted(real),'hasReceiver':bool(real)})
 # Exact recomputedblank/offcut records for everychangedNEWpiece. The
 # purchasedsections/panelplanes/stockpositions stayunchanged.
 stocks={**payload(OUT/'main-wall-raw-stock.json.gz')['parts'],**core['stock'],**core['sourceStockRecordOverrides'],**fr['stock'],**fr['sourceWallStockRecordOverrides']};overrides={};stockchecks=[]
 for sid,st in stocks.items():
  if not any(pid in newwood for pid in st['children']):continue
  blank=native_solid(st['blank']);installed=union([native_solid(allp[pid]) for pid in st['children']]);off=blank-installed;outside=amount(installed-blank)/I**3;error=diff(blank,installed+off)/I**3;overrides[sid]={**st,'declared_exterior_offcut':mesh(off),'outside_in3':outside,'reconstruction_in3':error};stockchecks.append({'id':sid,'outsideIn3':outside,'reconstructionIn3':error})
 # Actual flexible-film fastener contacts stayexplicit. Their required
 # covering/fieldpatch sequence is never inferredfromnailwatertight tests.
 hardware=payload(DEST/'floor-return-final-hardware-parts.json.gz')['parts'];flex=[];raybad=[];filmshape={pid:native_solid(p) for pid,p in P.items()};newhardware={}
 for fid,p0 in hardware.items():
  p=copy.deepcopy(p0);s=native_solid(p);hits=[pid for pid,q in filmshape.items() if boxes_overlap(s.bounding_box(),q.bounding_box()) and amount(s^q)>TOL];p['flexibleWeatherReceiverIds']=sorted(set(p.get('flexibleWeatherReceiverIds',[])+hits));receipt=p['penetrationCheck'];purchases={}
  for logicalReceiver in receipt['requiredReceiverPurchaseIn']:
   for rid in fr['splitConstructionGroups'].get(logicalReceiver,[logicalReceiver]):
    purchases[rid]=ray_purchase(native_solid(allp[rid]),np.array(p['head_m']),np.array(p['axis_inward']),p['fastenerSpec']['lengthIn']*I)/I
  if not purchases or max(purchases.values())+1e-6<receipt['minimumIn']:raybad.append({'id':fid,'actualRequiredPurchaseIn':purchases,'minimumIn':receipt['minimumIn']})
  p['postFloorFilmSeatRequiredPurchaseIn']=purchases;newhardware[fid]=p
  if hits:flex.append({'fastenerId':fid,'filmIds':hits,'fieldApplicationRequired':'Installappropriatesealingoverpatch afteractualheadisdrivenflush; selectedSIGAWigluv60minimum60x60mm patch. Factoryheadheight/profileunpublished, soformedpatchsurface isnotclaimedfactoryCAD or testedpiercedjoint.'})
 # Corknegative tools composewiththefrozen1.100mm tool. Neveroverwrite a
 # currentcork witha stale readback, and neverraise thefloorfinish.
 floorMeta=read(ROOT/'src/floor-foundation-solids.json');arc=payload(ROOT/'src'/floorMeta['geometryArchive'])['parts'];cork={};oldtool=native_solid(old['requiredCorkPocketCutTool']);extra=native_solid(d['requiredAdditionalCurrentCorkPocketCutTool']);corkchecks=[]
 for p0 in floorMeta['parts']:
  if 'CORK' not in p0['id']:continue
  p=copy.deepcopy(p0)
  if p.get('geometry_ref'):p.update(arc[p['geometry_ref']])
  if not p.get('triangles'):continue
  s=native_solid(p);changed=s-oldtool-extra
  if diff(s,changed)>TOL:cork[p['id']]={**p,**mesh(changed)};corkchecks.append({'id':p['id'],'removedIn3':amount(s-changed)/I**3,'originalStockThicknessMm':3.0,'finishDatumM':0})
 d['sourceStockRecordOverrides']=overrides;d['actualPhysicalReceiverContacts']=contacts;d['fieldFastenerSealApplicationSites']=flex;d['additionalFieldPatchStock']={'product':'SIGA Wigluv60 #7510-6040','selectedCutMm':[60,60,.35],'count':len(flex),'lengthM':len(flex)*.06,'status':'REQUIRED_FIELD_APPLICATION_REFERENCE; factoryfastenerheadprofileunpublished, geometrynotfabricated'};d['rollsByPublishedLengthWith20PercentAllowance']={p:{'publishedRollM':40 if 'Wigluv60' in p else 25,'quantity':math.ceil(L*1.2/(40 if 'Wigluv60' in p else 25))}for p,L in d['consumptionM'].items()};d.pop('rolls25mWith20PercentAllowance',None);d['replaceCurrentCorkParts_READBACK_ONLY']=cork;d['requiredCorkCompositionOrder']=['CURRENT3.000mmcorkminusfrozen1.100mmtool','Thenminusnew1.450mmtool','Retainallotherbook/finishreliefs; finish0unchanged'];d['assemblyOrder']=['PrepareactualNEWGP.400mmrebates andpanelprofilesfromsamefactoryblanks','Attachfloorreturnbackers/GPwithallitemizedhardware','Innerconcretesidefilm beforetheGPbroadliners; outerconcretesidefilm afterbroadliners','Concreteendwraps afterbothsidefilms; actualsolidconcreteservesasboundarybetweeninside/outsidefilms; cracks/coldjointsrequiresealedinterfaces','Frozen64steelboots and165floorfilms followbroadliners; theirbytes/posesstayunchanged','New8inner60mmruns followfrozen229terrain','Applyallitemizedfieldfastenerseals beforecoveringwithfixedbearings/frames/3mmcork','Fixedbearingstrips/ENVwallfasteners afterfilms; anynewpiercings requiretheir ownexplicitsealedpatch/application','Ownerfullcausalwithdrawalprerequisitesincludepeeling/removingalloverlyingfilm/patches beforefastenerwithdrawal'];d['sourceFloorSHA256']=sha(ROOT/'src/floor-foundation-solids.json');d['sourceFloorArchiveSHA256']=sha(ROOT/'src'/floorMeta['geometryArchive']);d['qualification']='Physical24filmgeometry/59NEWstockseats areseparatefromrequiredfieldfastener-head patch applications, actualsteel/concretecoatingadhesion, doorperimeter/outerraincounterflashing andwholebuildingtest.';write_gz(DEST/'floor-return-physical-films-final.json.gz',d);write_gz(DEST/'floor-return-hardware-final-film-receivers.json.gz',{'parts':newhardware});adapter['add_parts']={**P,**newwood};adapter['stock']=overrides;adapter['replaceNewEnvelopeParts'].update(newwood);adapter['replaceCorkUndersideParts']=cork;write_gz(DEST/'floor-return-films-final-raw-parts.json.gz',adapter);save(DEST/'floor-return-film-support-attachment-check.json',{'status':'PASS' if not raybad and all(r['hasReceiver'] for r in contacts) and all(max(r['outsideIn3'],r['reconstructionIn3'])<=1e-6 for r in stockchecks) else'BLOCKED','physicalFilms':len(P),'changedNEWStockPieces':len(newwood),'stockChecks':stockchecks,'all611HardwarePurchaseRechecked':True,'hardwarePurchaseFailures':raybad,'receiverContacts':contacts,'fieldFastenerSealApplicationSiteCount':len(flex),'corkReadbacks':corkchecks,'scope':'No primary/28floorGP/steel/concrete edits; onlyNEWstock seats andcompositionalcorkundersides. Headpatches explicitlyfieldreferences.'});print('final',len(P),len(newwood),'stock',len(stockchecks),'flexsites',len(flex),'raybad',raybad,'unsupported',[q for q in contacts if not q['hasReceiver']],flush=True)
if __name__=='__main__':main()
