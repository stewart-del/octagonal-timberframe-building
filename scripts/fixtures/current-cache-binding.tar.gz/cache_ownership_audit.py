"""Fresh bounded cache-input compatibility; no canonical data/certificate edits."""
from pathlib import Path
import sys,json,gzip,hashlib,itertools,re,argparse,time,copy
sys.dont_write_bytecode=True
import numpy as np
import manifold3d as m
from shapely.geometry import Polygon
R=Path('/workspace/sites/octagonal-timberframe-building');D=Path('/workspace/timberframe-next-step/research/cache-ownership-audit');sys.path.insert(0,str(R/'scripts'))
from physical_data import read_physical_json,occupied_part
from audit_revised_joinery import native_solid
from audit_cavity_fit import inspect_mesh
from physical_contacts import contact_kind
I=.0254;TOL=1e-6*I**3
NAMES={'baseline':'model-data.json','proposed':'step-lap-proposed-model.json','top-entry':'top-entry-proposed-model.json'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(gzip.decompress(Path(p).read_bytes()))if str(p).endswith('.gz')else json.load(open(p))
def save(p,a):Path(p).write_text(json.dumps(a,separators=(',',':'))+'\n')
def canon(a):return json.dumps(a,sort_keys=True,separators=(',',':'),allow_nan=False)
def fp(p):return hashlib.sha256(canon({'vertices':p['vertices'],'triangles':p['triangles']}).encode()).hexdigest()
def digest(a):return hashlib.sha256(canon(a).encode()).hexdigest()
def unpack(p):return native_solid(p)if p.get('triangles')else m.Manifold()
def volume(s):return max(0.,float(s.volume()))
def diff(a,b):return volume(a-b)+volume(b-a)
def union(ss):ss=list(ss);return m.Manifold.batch_boolean(ss,m.OpType.Add)if ss else m.Manifold()
def record(s):q=s.to_mesh64();v=np.asarray(q.vert_properties)[:,:3];return {'vertices':v.tolist(),'triangles':np.asarray(q.tri_verts).tolist(),'volume_m3':float(s.volume())}
def aabb(s):return np.array(s.bounding_box())
def near(a,b):return bool(np.all(a[:3]<b[3:])and np.all(a[3:]>b[:3]))
def contacts(a,b):
 def tri(s):
  q=s.to_mesh64();v=np.asarray(q.vert_properties)[:,:3];t=v[np.asarray(q.tri_verts)];n=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);L=np.linalg.norm(n,axis=1);keep=L>1e-14;t=t[keep];n=n[keep]/L[keep,None];return t,n,np.einsum('ij,ij->i',t[:,0],n)
 ta,na,da=tri(a);tb,nb,db=tri(b);areas={}
 for i,t in enumerate(ta):
  n=na[i];same=np.where((nb@n<-1+1e-9)&(np.abs(tb[:,0]@n-da[i])<1e-8))[0]
  if not len(same):continue
  u=np.cross(n,np.eye(3)[np.argmin(abs(n))]);u/=np.linalg.norm(u);v=np.cross(n,u);B=np.column_stack([u,v]);origin=t[0];p=Polygon((t-origin)@B)
  for j in same:
   ar=p.intersection(Polygon((tb[j]-origin)@B)).area
   if ar>1e-12:key=tuple(np.round(n,8));areas[key]=areas.get(key,0)+ar/I**2
 return [{'normal':list(k),'areaIn2':v}for k,v in sorted(areas.items())]
def native_check(p,single=True):return inspect_mesh(np.array(p['vertices']),np.array(p['triangles'],np.uint64),require_single=single)
def normfast(p):
 p=copy.deepcopy(p)
 if p.get('is_fastener'):
  spec=p.get('fastenerSpec')or p.get('fastener_spec')or{};code=str(spec.get('partNumber',''));description=' '.join(str(x)for x in [p.get('name',''),spec.get('product','')]);kind=p.get('fastenerKind')
  if not kind:
   if re.search(r'\bnail\b',description,re.I)or re.match(r'^(T7SN7B|T20SNDB|T311ARN1|T8PCS10|8DHDG|16DHDG)',code):kind='nail'
   elif re.search(r'\bscrew\b',description,re.I)or re.match(r'^(WSV|S10\d+WP)',code)or(spec.get('manufacturer')=='GRK'and code in ['14221','14225','14231','12235','12285','113077']):kind='screw'
  p['fastenerKind']=kind or'other hardware';p['intentionalFastenerPenetration']=p.get('intentionalFastenerPenetration',kind in['nail','screw'])
 return p
class Audit:
 def __init__(self):
  self.started=time.monotonic();self.capture=load(D/'input-capture.json.gz');self.frozen=load(R/'scripts/fixtures/cupola-access-inputs.json.gz');self.wall=load(R/'src/wall-joinery-fit.json');self.old={v:json.loads(q['sourceModelText'])for v,q in self.frozen['variants'].items()};self.current={v:load(R/'src'/n)for v,n in NAMES.items()};self.O={v:{p['id']:p for p in m['parts']}for v,m in self.old.items()};self.C={v:{p['id']:p for p in m['parts']}for v,m in self.current.items()};self.sourceHashes={str(p):sha(p)for p in [R/'scripts/fixtures/cupola-access-inputs.json.gz',D/'input-capture.json.gz',R/'src/wall-joinery-fit.json',R/'src/floor-foundation-solids.json',R/'src/floor-foundation-geometries.json.gz',R/'src/mudroom-joinery-fit.json',R/'scripts/fixtures/wall-locking-pegs.json.gz',R/'src/bookshelf-solids.json',Path(__file__),*[R/'src'/n for n in NAMES.values()]]}
  for v,n in NAMES.items():assert self.capture['variants'][v]['currentSourceSha256']==sha(R/'src'/n),(v,'Capture stale')
 def ownership(self):
  variants={}
  for v in NAMES:
   old,cur=self.O[v],self.C[v];changed=[pid for pid in cur if fp(cur[pid])!=fp(old[pid])];assert len(changed)==49;cap=self.capture['variants'][v];rows={}
   for key in ['floorFixedSections','wallRaw','wallFittedEnclosure','porchRaw','porchFitted','mainCedarFace2']:
    A={p['id']:fp(p)for p in cap['historical'][key]};B={p['id']:fp(p)for p in cap['current'][key]};assert A==B,(v,key,'Changed influential output');rows[key]={'count':len(B),'exactPerPartFingerprints':B,'sameAsFrozen':True}
   oldL={k:x for k,x in cap['historical']['floorLayout'].items()if k!='revision'};newL={k:x for k,x in cap['current']['floorLayout'].items()if k!='revision'};assert oldL==newL;assert cap['historical']['porchRoofSpec']==cap['current']['porchRoofSpec'];minY=min(min(q[1]for q in cur[pid]['vertices'])for pid in changed);assert minY>1e-8
   posts={pid:{'exactMeshSha256':fp(cur[pid]),'center':cur[pid]['center'],'footY_M':min(q[1]for q in cur[pid]['vertices']),'footprintVertices':sorted({tuple(q)for q in cur[pid]['vertices']if abs(q[1]-min(x[1]for x in cur[pid]['vertices']))<1e-7})}for pid in [f'P{k}'for k in range(8)]};beams={f'B{k}':{'meshSha256':fp(cur[f'B{k}']),'undersideY_M':min(q[1]for q in cur[f'B{k}']['vertices'])}for k in range(8)}
   assert all(fp(cur[pid])==fp(old[pid])for pid in posts);assert all(fp(cur[pid])==fp(old[pid])for pid in beams)
   schedule=[j for j in self.current[v]['tenon_schedule']if j.get('receiver')in posts or j.get('donor')in posts];historical=[j for j in self.old[v]['tenon_schedule']if j.get('receiver')in posts or j.get('donor')in posts];assert canon(schedule)==canon(historical)
   variants[v]={'currentSourceSha256':cap['currentSourceSha256'],'historicalSourceSha256':cap['historicalSourceSha256'],'changed49Ids':changed,'exactUnchangedPartCount':len(cur)-49,'changedPartMinimumY_M':minY,'floorLayoutGeometrySha256':digest(newL),'exactScopeOutputs':rows,'posts':posts,'wallBeamInputs':beams,'primaryPostJointScheduleCount':len(schedule),'primaryPostJointScheduleSha256':digest(schedule),'porchConsumedC2C3Projection':cap['current']['consumedC2C3Projection'],'porchRoofSpecSha256':digest(cap['current']['porchRoofSpec']),'scope':'Upper C/CR/CC/kingpost/peg geometry changes are not ignored: floor slab classification, actual wall inputs and consumed porch roof projections are checked.'}
  adv=self.capture['adversaries'];post=adv['P2raisedFoot']['modelPost'];oldP=self.C['baseline']['P2'];floor=read_physical_json(R/'src/floor-foundation-solids.json');head=next(p for p in floor['parts']if p['id']=='POST-BEARING-STAND-2-HEAD');H=native_solid(head);before=native_solid(oldP).min_gap(H,I)/I;after=native_solid(post).min_gap(H,I)/I;assert before<1e-7 and abs(after-.125)<1e-7;assert adv['legacyFloorCenterlineGuardStillAccepts'];assert adv['P2raisedFoot']['capture']['porchFitError']=='Porch joinery anchors are stale';assert fp(post)!=fp(oldP)
  out={'status':'PASS_FRESH_SCOPED_INPUT_OWNERSHIP_ONLY','sourceHashes':self.sourceHashes,'scope':'Independent compatibility evidence; historical source_model_sha/proof status remain untouched. Does not approve cupola-window/roof caches, later overlays or whole-building assembly. Current model/source/assembly gates remain required.','variants':variants,'adversary':{'id':'P2_PLUS_1_8IN_FOOT_DATUM','legacyFloorCenterlineGuardStillAccepts':True,'newPostMeshFingerprintRejects':True,'floorHeadGapBeforeIn':before,'floorHeadGapAfterIn':after,'currentPorchAnchorGuardRejects':True,'rawWallGeometryChanged':digest(adv['P2raisedFoot']['capture']['wallRaw'])!=digest(self.capture['variants']['baseline']['current']['wallRaw']),'whyMeaningful':'The plan centerline remains identical; a real1/8in unsupported foot gap appears. Cache reuse cannot be gated only by P.x/z or by changed-ID whitelists.'},'capacity_verified':False};save(D/'input-ownership-report.json',out);print('OWNERSHIP PASS all3; raisedP2 foot adversary rejects',flush=True)
 def wall_replay(self,v):
  f=self.wall['variants'][v];base={**self.C[v],**{p['id']:p for p in self.capture['variants'][v]['current']['wallFittedEnclosure']}};patch={**f['primary_parts'],**f['wall_parts']};orig={pid:native_solid(base[pid])for pid in patch};design=load(R/'scripts/fixtures/wall-locking-pegs.json.gz')['variants'][v];bores={}
  for p in design['bore_tools']:
   for pid in p['receiverIds']:bores.setdefault(pid,[]).append(native_solid(p))
  final={};stock={};checks=[];records={}
  for pid,p in patch.items():
   added=unpack(p['wallJoineryAdded']);removed=unpack(p['wallJoineryRemoved']);stock[pid]=orig[pid]+added;replayed=stock[pid]-removed;toolAdded=union(unpack(j['tongue'])for j in f['joints']if j['donor']==pid);toolCuts=union([*[unpack(j['socket_tool'])for j in f['joints']if j['receiver']==pid],*bores.get(pid,[])]);independent=(orig[pid]+toolAdded)-toolCuts;cached=native_solid(p);error=diff(replayed,cached);independentError=diff(independent,cached);assert error<=TOL and independentError<=TOL,(v,pid,'Wall recipe mismatch',error/I**3,independentError/I**3);proof=native_check(p);assert proof['status']=='PASS',(v,pid,proof);final[pid]=cached;records[pid]={'id':pid,**record(cached)};checks.append({'id':pid,'currentInputMeshSha256':fp(base[pid]),'cachedBoundaryMeshSha256':fp(p),'addedRemovedReplayDifferenceIn3':error/I**3,'independentJointAndPegToolReplayDifferenceIn3':independentError/I**3,'rawStatus':proof['status'],'boundaryPolicy':'Stored strict raw boundary reused ONLY after two current-input Boolean reconstructions agree at unchanged tolerance.'})
  pegs={p['id']:native_solid(p)for p in f['locking_pegs']};pinChecks=[]
  for p in f['locking_pegs']:
   s=pegs[p['id']];targets=p['receiverIds'];outside=volume(s-union(stock[q]for q in targets));assert outside<=TOL,(p['id'],'Fresh pin leaves current mating stock',outside/I**3);proof=native_check(p);assert proof['status']=='PASS';rows=[]
   for q in targets:
    overlap=volume(s^final[q]);gap=s.min_gap(final[q],.01*I)/I;assert overlap<=TOL,(p['id'],q,overlap/I**3);rows.append({'receiver':q,'overlapIn3':overlap/I**3,'gapIn':gap})
   pinChecks.append({'id':p['id'],'outsideCurrentUnboredMatingStockIn3':outside/I**3,'hosts':rows,'rawStatus':proof['status']})
  S={**final,**pegs};boxes={pid:aabb(s)for pid,s in S.items()};pairs=0;maximum=0.
  for pid,s in S.items():
   for q,t in S.items():
    if q>=pid or not near(boxes[pid],boxes[q]):continue
    overlap=volume(s^t);pairs+=1;maximum=max(maximum,overlap);assert overlap<=TOL,(v,pid,q,overlap/I**3)
  # Every old perimeter-post primary joint and every current cavity stays.
  joints=[j for j in self.current[v]['tenon_schedule']if j.get('receiver')in f['primary_parts']or j.get('donor')in f['primary_parts']];contactRows=[];cavname={'baseline':'cavity-data.json','proposed':'step-lap-proposed-cavities.json','top-entry':'top-entry-proposed-cavities.json'}[v];cavpath=R/'src'/cavname;cav=load(cavpath);self.sourceHashes[str(cavpath)]=sha(cavpath)
  for i,j in enumerate(joints):
   post=j['receiver']if j['receiver']in f['primary_parts']else j['donor'];mate=j['donor']if post==j['receiver']else j['receiver'];oldMate=native_solid(self.O[v][mate]);currentMate=native_solid(self.C[v][mate]);assert fp(self.O[v][mate])==fp(self.C[v][mate]);oldContact=contacts(native_solid(f['primary_parts'][post]),oldMate);newContact=contacts(final[post],currentMate);oldArea=sum(x['areaIn2']for x in oldContact);newArea=sum(x['areaIn2']for x in newContact);assert abs(oldArea-newArea)<=1e-6,(v,j['id'],'Primary contact changed',oldArea,newArea);gap=final[post].min_gap(currentMate,.01*I)/I;overlap=volume(final[post]^currentMate);assert overlap<=TOL;void=unpack(cav['parts'][post]['removed']);filled=volume(final[post]^void);assert filled<=TOL,(v,post,'Current primary cavity filled',filled/I**3);contactRows.append({'jointId':j['id'],'post':post,'mate':mate,'oldAcceptedWallFitContactAreaIn2':oldArea,'currentReconstructedContactAreaIn2':newArea,'areaDifferenceIn2':abs(oldArea-newArea),'minimumGapIn':gap,'overlapIn3':overlap/I**3,'currentPrimaryVoidFilledIn3':filled/I**3,'positiveContactRetained':newArea>1e-6})
   if i%12==11:print('WALL',v,'primary contacts',i+1,flush=True)
  return {'currentModelSha256':sha(R/'src'/NAMES[v]),'historicalFitModelSha256':f['source_model_sha256'],'currentGeometryPrimaryParts':{pid:records[pid]for pid in f['primary_parts']},'currentGeometryWallParts':{pid:records[pid]for pid in f['wall_parts']},'replayChecks':checks,'pinChecks':pinChecks,'primaryJointContacts':contactRows,'matchedSceneExactPairs':pairs,'maximumMatchedSceneOverlapIn3':maximum/I**3,'scope':'Fresh exact-input/two-recipe reconstruction,134actual pins,48retained primary joints. No source_model_sha in original wall cache or old fit proof is modified. This is not the whole-scene assembly gate.'}
 def wall_audit(self):
  out={}
  for v in NAMES:out[v]=self.wall_replay(v);print('WALL PASS',v,flush=True)
  save(D/'wall-current-reconstruction-report.json',{'status':'PASS_FRESH_SCOPED_WALL_RECONSTRUCTION','sourceHashes':self.sourceHashes,'variants':out,'unchangedCollisionToleranceIn3':1e-6,'capacity_verified':False});print('WALL ALL3 COMPLETE',flush=True)
 def floor_audit(self):
  path=R/'src/floor-foundation-solids.json';f=read_physical_json(path);P={p['id']:normfast(occupied_part(p,f['prototypes']))for p in f['parts']};S={pid:native_solid(p)for pid,p in P.items()};boxes={pid:aabb(s)for pid,s in S.items()};assert len(S)==3056;native=[]
  for pid,s in S.items():assert str(s.status())=='Error.NoError'and s.volume()>0 and len(s.decompose())==1,(pid,'Native invalid');native.append(pid)
  # Existing contact policy is copied only to identify actual named receiving
  # wood for nails/screws. Pins/steel/concrete never receive this exception.
  ids=list(S);b=np.array([boxes[x]for x in ids]);pairs=0;allowed=0;maximum=0.;maxForbidden=0.
  for i,pid in enumerate(ids):
   choices=np.where(np.all(b[:i,3:]>b[i,:3],axis=1)&np.all(b[:i,:3]<b[i,3:],axis=1))[0]
   for j in choices:
    q=ids[j];overlap=volume(S[pid]^S[q]);pairs+=1;maximum=max(maximum,overlap)
    if contact_kind(P[pid],P[q]):allowed+=overlap>TOL;continue
    maxForbidden=max(maxForbidden,overlap);assert overlap<=TOL,(pid,q,'Floor forbidden overlap',overlap/I**3)
   if i%500==0:print('FLOOR static',i,'of',len(ids),flush=True)
  cabinet=load(R/'src/bookshelf-solids.json');embedded={pid:fp(p)for pid,p in P.items()if pid.startswith('BOOK-')};assert all(embedded[p['id']]==fp(p)for p in cabinet['parts']);assert len(embedded)==214
  # Current native head/post bearing and current49upper-actor separation.
  variants={}
  for v in NAMES:
   current={pid:native_solid(p)for pid,p in self.C[v].items()};foot=[]
   for k in range(8):
    pid=f'P{k}';hid=f'POST-BEARING-STAND-{k}-HEAD';gap=S[hid].min_gap(current[pid],.1*I)/I;overlap=volume(S[hid]^current[pid]);area=sum(x['areaIn2']for x in contacts(S[hid],current[pid]));assert gap<1e-7 and overlap<=TOL and area>0;foot.append({'postId':pid,'headId':hid,'gapIn':gap,'overlapIn3':overlap/I**3,'unboredCanonicalHeadContactAreaIn2':area})
   changed=[pid for pid in current if fp(self.O[v][pid])!=fp(self.C[v][pid])];changedBoxes=np.array([aabb(current[x])for x in changed]);minimum=1e9;potential=0
   for pid,bb in boxes.items():
    sep=np.maximum(0,np.maximum(bb[:3]-changedBoxes[:,3:],changedBoxes[:,:3]-bb[3:]));mins=np.max(sep,axis=1);minimum=min(minimum,float(mins.min()));potential+=int(np.count_nonzero(mins<=0))
   assert potential==0,(v,'Changed cupola near floor requires exact extra check',potential)
   variants[v]={'currentModelSha256':sha(R/'src'/NAMES[v]),'headContacts':foot,'changed49BroadphasePairs':len(P)*49,'changed49PossibleOverlaps':potential,'minimumAxisSeparationM':minimum,'floorLayoutSourcePostCentersMatch':self.capture['variants'][v]['current']['floorLayout']['sourcePostCenters']==f['layout']['sourcePostCenters']}
  # Recheck declared small peg/bore fit instead of demanding literal zero gap.
  pins=[]
  for pid,p in P.items():
   if not pid.startswith('BOOK-PEG-'):continue
   vs=np.array(p['vertices']);_,V=np.linalg.eigh(np.cov(vs.T));ax=V[:,-1];center=(vs.min(0)+vs.max(0))/2;r=p['modeled_bore_diameter_in']/p['diameter_in'];A=r*np.eye(3)+(1-r)*np.outer(ax,ax);expanded=S[pid].transform(np.column_stack([A,center-A@center]).tolist());hosts=[]
   for q in p['receiverIds']:
    gap=S[pid].min_gap(S[q],.02*I)/I;eg=expanded.min_gap(S[q],.02*I)/I;ov=volume(expanded^S[q]);assert eg<1e-7 and ov<=TOL;hosts.append({'id':q,'nominalGapIn':gap,'radialOnlyDeclaredBoreExpansionGapIn':eg,'expandedOverlapIn3':ov/I**3})
   pins.append({'id':pid,'hosts':hosts})
  hashes={pid:fp(p)for pid,p in P.items()};save(D/'floor-current-compatibility-report.json',{'status':'PASS_FRESH_FLOOR_CACHE_INPUT_COMPATIBILITY','scope':'Canonical3056part layer only. Fresh native validity, internal static policy,8current foot/head contacts pervariant, current214furniture geometry and49changed-upper-actor separation. Architecture overlays, global stock/motion and structural capacity remain separate. Historical floor.source_model_sha256 remains untouched.','sourceHashes':self.sourceHashes,'historicalFloorSourceModelSha256':f['source_model_sha256'],'nativePartCount':len(native),'exactFloorPairs':pairs,'permittedNamedNailScrewPairs':allowed,'maximumNonpermittedOverlapIn3':maxForbidden/I**3,'currentFurnitureGeometryMatches214':True,'exactPerPartGeometryFingerprints':hashes,'variants':variants,'bookshelfPegFreshClearanceFits':pins,'unchangedCollisionToleranceIn3':1e-6,'capacity_verified':False});print('FLOOR COMPLETE',pairs,'pairs',flush=True)
 def porch_audit(self):
  old=load(R/'src/mudroom-joinery-fit.json');fresh=load(D/'current-porch-generated.json.gz');assert fresh['source_model_sha256']==sha(R/'src/model-data.json');A={**old['parts'],**{p['id']:p for p in old['added_parts']}};B={**fresh['parts'],**{p['id']:p for p in fresh['added_parts']}};assert set(A)==set(B);assert all(fp(A[k])==fp(B[k])for k in A);assert canon(old['joints'])==canon(fresh['joints'])
  components={p['id']:p for p in self.capture['variants']['baseline']['current']['porchRaw']};components.update(fresh['parts']);components.update({p['id']:p for p in fresh['added_parts']});S={pid:native_solid(p)for pid,p in components.items()};boxes={pid:aabb(s)for pid,s in S.items()};pairs=0;maximum=0.
  for pid,s in S.items():
   assert str(s.status())=='Error.NoError'and s.volume()>0 and len(s.decompose())==1,(pid,'Porch invalid')
   for q,t in S.items():
    if q>=pid or not near(boxes[pid],boxes[q]):continue
    amount=volume(s^t);pairs+=1;maximum=max(maximum,amount);assert amount<=TOL,(pid,q,'Fresh porch overlap',amount/I**3)
  jointContacts=[]
  for j in fresh['joints']:
   donor,receiver=j['donor'],j['receiver'];gap=S[donor].min_gap(S[receiver],.01*I)/I;area=sum(x['areaIn2']for x in contacts(S[donor],S[receiver]));jointContacts.append({'id':j['id'],'donor':donor,'receiver':receiver,'gapIn':gap,'actualCoplanarContactAreaIn2':area,'positiveContact':area>1e-6});assert gap<1e-7,(j['id'],'Fresh porch joint gap',gap)
   if len(jointContacts)%40==0:print('PORCH contacts',len(jointContacts),flush=True)
  variantProof=[];reference=self.capture['variants']['baseline']['current']
  for v in NAMES:
   cur=self.capture['variants'][v]['current'];assert canon(cur['porchRaw'])==canon(reference['porchRaw']);assert cur['porchRoofSpec']==reference['porchRoofSpec'];variantProof.append({'variant':v,'currentModelSha256':sha(R/'src'/NAMES[v]),'exactRaw678PartAndDerivedRoofInputEqualityToFreshGeneratedBaseline':True,'freshCurrentDerivedPorchGeometryFingerprint':digest({pid:fp(p)for pid,p in B.items()})})
  save(D/'porch-current-compatibility-report.json',{'status':'PASS_FRESH_FITTED_PORCH_BASE_INPUT_COMPATIBILITY','scope':'Fresh generator was run without changing old cache. Its89fittedparts and51addedparts are byte-identical geometry to the cached base; all729live base components freshly checked at1e-6in3. Full source hashes of historical proofs remain unchanged. Roof-support/stair/pan/drain overlays and primary-to-porch whole-scene/assembly gates remain separate.','sourceHashes':{**self.sourceHashes,str(D/'current-porch-generated.json.gz'):sha(D/'current-porch-generated.json.gz')},'historicalPorchSourceModelSha256':old['source_model_sha256'],'freshGeneratedBaselineSourceSha256':fresh['source_model_sha256'],'exactFitted89Fingerprints':{pid:fp(p)for pid,p in fresh['parts'].items()},'exactAdded51Fingerprints':{p['id']:fp(p)for p in fresh['added_parts']},'freshNativeLiveComponentCount':len(S),'freshExactPairs':pairs,'maximumOverlapIn3':maximum/I**3,'jointContacts':jointContacts,'variants':variantProof,'capacity_verified':False});print('PORCH COMPLETE',len(S),'components',pairs,'pairs',flush=True)
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--scope',choices=['ownership','wall','floor','porch'],required=True);arg=parser.parse_args();a=Audit();{'ownership':a.ownership,'wall':a.wall_audit,'floor':a.floor_audit,'porch':a.porch_audit}[arg.scope]()
