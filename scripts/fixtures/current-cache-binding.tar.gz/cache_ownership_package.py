"""Publish a bounded, fresh cache-input binding without changing canonical caches."""
from pathlib import Path
import sys, json, gzip, hashlib, copy, math, importlib, importlib.metadata, platform, subprocess
sys.dont_write_bytecode = True
import numpy as np
R = Path('/workspace/sites/octagonal-timberframe-building')
D = Path('/workspace/timberframe-next-step/research/cache-ownership-audit')
sys.path.insert(0, str(R / 'scripts'))
from physical_data import read_physical_json

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):
    p = Path(p)
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_bytes())
def canon(a): return json.dumps(a, sort_keys=True, separators=(',', ':'), allow_nan=False)
def digest(a): return hashlib.sha256(canon(a).encode()).hexdigest()
def save(p, a): Path(p).write_text(json.dumps(a, indent=2) + '\n')

reports = {n: load(D / n) for n in ['input-ownership-report.json', 'floor-current-compatibility-report.json', 'wall-current-reconstruction-report.json', 'porch-current-compatibility-report.json']}
assert all(a['status'].startswith('PASS_FRESH_') for a in reports.values())
floor = read_physical_json(R / 'src/floor-foundation-solids.json')
books = load(R / 'src/bookshelf-solids.json')
walls = load(R / 'src/wall-joinery-fit.json')
porch = load(R / 'src/mudroom-joinery-fit.json')
fresh_porch = load(D / 'current-porch-generated.json.gz')
capture = load(D / 'input-capture.json.gz')
ownership = reports['input-ownership-report.json']
embedded = {p['id']: p for p in floor['parts']}
stock = [p for p in books['parts'] if p.get('joineryStock')]
assert len(stock) == 68
assert all(canon(p['joineryStock']) == canon(embedded[p['id']]['joineryStock']) for p in stock)

dependency_paths = [
 'src/model-data.json', 'src/step-lap-proposed-model.json', 'src/top-entry-proposed-model.json',
 'src/floor-foundation-solids.json', 'src/floor-foundation-geometries.json.gz',
 'src/floor-foundation.js', 'src/bookshelf-solids.json', 'scripts/build_floor_solids.py',
 'scripts/floor_sheet_panels.py', 'scripts/floor_edge_supports.py', 'scripts/fixtures/floor-supports.json.gz',
 'src/wall-joinery-fit.json', 'src/schematic-walls.js', 'scripts/fit_wall_joinery.py',
 'scripts/wall_locking_pegs.py', 'scripts/fixtures/wall-locking-pegs.json.gz',
 'src/enclosure-fit.json', 'src/step-lap-proposed-enclosure-fit.json', 'src/top-entry-proposed-enclosure-fit.json',
 'src/cavity-data.json', 'src/step-lap-proposed-cavities.json', 'src/top-entry-proposed-cavities.json',
 'src/mudroom-joinery-fit.json', 'src/mudroom.js', 'src/mudroom-roof.js', 'src/roof-coverings.js',
 'scripts/fit_mudroom_joinery.py', 'scripts/fixtures/cupola-access-inputs.json.gz',
 'scripts/physical_data.py', 'scripts/audit_revised_joinery.py', 'scripts/audit_cavity_fit.py',
 'scripts/physical_contacts.py',
]
for module in ['audit_revised_joinery','audit_cavity_fit','physical_contacts','fit_mudroom_joinery']:
    importlib.import_module(module)
imported_modules = {}
for name, module in sys.modules.copy().items():
    path = Path(getattr(module,'__file__','') or '/nonexistent')
    if path.is_file() and R in path.parents:
        relative = str(path.relative_to(R))
        imported_modules[name] = relative
        if relative not in dependency_paths: dependency_paths.append(relative)
deps = {p: sha(R / p) for p in dependency_paths}
for module, expected in capture['sourceModuleHashes'].items():
    assert deps['src/' + module] == expected
for old_key, path in {
 'source_module_sha256': 'src/floor-foundation.js',
 'source_builder_sha256': 'scripts/build_floor_solids.py',
 'source_sheet_module_sha256': 'scripts/floor_sheet_panels.py',
 'source_furniture_sha256': 'src/bookshelf-solids.json',
}.items():
    assert floor[old_key] == deps[path]
assert floor['fastenerSummary']['sourceEdgeSupportFixtureSha256'] == deps['scripts/fixtures/floor-supports.json.gz']
for old_key, path in {
 'source_module_sha256':'src/mudroom.js',
 'source_roof_module_sha256':'src/mudroom-roof.js',
 'source_fitter_sha256':'scripts/fit_mudroom_joinery.py',
}.items(): assert fresh_porch[old_key] == deps[path]

proof_deps = {p.name: sha(p) for p in [D / n for n in reports] + [D / 'input-capture.json.gz', D / 'current-porch-generated.json.gz']}
producer_deps = {p.name: sha(p) for p in [D.parent / 'cache_input_capture.cjs', D.parent / 'cache_ownership_audit.py', Path(__file__), D / 'verify-scoped-binding.py']}

# Additional exact AABB separation proves that the 49 changed actors cannot
# introduce new contacts with either reused base scope. Native occupied-solid
# checks for each reused scope are in the separate reports above.
names = {'baseline':'model-data.json','proposed':'step-lap-proposed-model.json','top-entry':'top-entry-proposed-model.json'}
separation = {}
for variant, name in names.items():
    c = capture['variants'][variant]['current']
    current = {p['id']:p for p in load(R / 'src' / name)['parts']}
    changed = [current[x] for x in ownership['variants'][variant]['changed49Ids']]
    B = np.array([[*np.asarray(p['vertices']).min(0), *np.asarray(p['vertices']).max(0)] for p in changed])
    scopes = {
      'fittedWallBaseIncludingUnpatchedEnclosureActors': [*reports['wall-current-reconstruction-report.json']['variants'][variant]['currentGeometryPrimaryParts'].values(), *c['wallFittedEnclosure'], *walls['variants'][variant]['locking_pegs']],
      'fittedPorchBase': c['porchFitted'],
    }
    rows = {}
    for scope, parts in scopes.items():
        possible, minimum = 0, math.inf
        for p in parts:
            A = np.asarray(p['vertices'])
            sep = np.maximum(0, np.maximum(A.min(0) - B[:,3:], B[:,:3] - A.max(0)))
            axis = sep.max(1)
            possible += int(np.count_nonzero(axis <= 0))
            minimum = min(minimum, float(axis.min()))
        assert possible == 0, (variant, scope, possible)
        rows[scope] = {'retainedPartCount':len(parts), 'changedPartCount':49, 'aabbPairs':49*len(parts), 'possibleContactPairs':possible, 'minimumAxisSeparationM':minimum}
    separation[variant] = rows

dependency_report = {
 'status':'PASS_FRESH_SCOPED_DEPENDENCY_AND_SEPARATION_BINDING',
 'dependencyHashes':deps, 'proofArtifactHashes':proof_deps, 'producerHashes':producer_deps,
 'floorUnchangedGeneratorDependencies':True,
 'floorEdgeSupportFixtureHashMatchesCanonicalHeader':True,
 'furnitureExactJoineryStockCount':68, 'furnitureFloorKeepoutStockCount':10,
 'furnitureAllJoineryStockMatchesEmbeddedCanonicalFloor':True,
 'porchFreshGeneratorDependenciesMatchCurrent':True,
 'porchHistoricalGeneratorHeaderEqualsCurrent':{k:porch[k]==deps[p] for k,p in {'source_module_sha256':'src/mudroom.js','source_roof_module_sha256':'src/mudroom-roof.js','source_fitter_sha256':'scripts/fit_mudroom_joinery.py'}.items()},
 'currentRuntimeImportedLocalModules':imported_modules,
 'evidenceBasis':'Fresh current-input exact geometry fingerprints, paired actual consumed inputs and two independent current CSG replay recipes; compatibility is not inferred from an old fitter SHA. SourceHash maps recorded at the start of each fresh audit remain byte-identical at packaging. The dependency closure adds current imported modules rather than claiming unrecorded historical runtime hashes.',
 'changedUpperActorsAgainstReusedBaseScopes':separation,
 'historicalCacheHeadersPreserved':{
   'floorSourceModelSha256':floor['source_model_sha256'],
   'wallVariantSourceModelSha256':{v:a['source_model_sha256'] for v,a in walls['variants'].items()},
   'porchSourceModelSha256':porch['source_model_sha256'],
   'enclosureHeaders':{n:{k:v for k,v in load(R/'src'/n).items() if k.startswith('source_') or k in ['status','geometryArchive','geometryArchiveSha256','geometryArchives','partArchives']} for n in ['enclosure-fit.json','step-lap-proposed-enclosure-fit.json','top-entry-proposed-enclosure-fit.json']},
   'wallAllSourceHeaders':{v:{'source_model_sha256':a['source_model_sha256'],'sources':a['sources']} for v,a in walls['variants'].items()},
   'floorAllSourceAndArchiveHeaders':{k:v for k,v in load(R/'src/floor-foundation-solids.json').items() if k.startswith('source_') or k in ['geometryArchive','geometryArchiveSha256','geometryArchives','partArchives']},
   'porchAllSourceHeaders':{k:v for k,v in porch.items() if k.startswith('source_')},
 },
 'adversarialFootDatumTest':ownership['adversary'],
 'wholeBuildingSourceGateSatisfied':False, 'wholeBuildingAssemblyGateSatisfied':False,
 'capacityVerified':False,
}
# Each long-running proof recorded source hashes on entry. Require every one
# still to match; this never rewrites those receipts or their historical data.
for report in reports.values():
    for path, expected in report['sourceHashes'].items():
        assert sha(path) == expected, ('Changed during/after native proof',path)
runtime = {
 'python':platform.python_version(), 'node':subprocess.check_output(['node','--version'],text=True).strip(),
 'packages':{n:importlib.metadata.version(n) for n in ['numpy','scipy','manifold3d','shapely']},
 'manifoldBinarySha256':sha(importlib.import_module('manifold3d').__file__),
}
dependency_report['runtime'] = runtime
save(D / 'dependency-and-separation-report.json', dependency_report)

recipe = {
 'schema':'fresh-scoped-cache-compatibility-recipe-v1',
 'purpose':'A separate current-input gate authorizing bounded geometry reuse; never relabel or overwrite historical cache/proof provenance.',
 'collisionToleranceIn3':1e-6,
 'fingerprint':'SHA256 of sorted compact JSON {vertices,triangles}; exact array data and triangle ordering, by part ID. Derived/semantic inputs are separately included.',
 'floor':{
   'scope':'Existing canonical 3056 physical parts, including 214 bookshelf actors. Architecture/connection/finish overlays are outside this scope.',
   'influentialInputs':['8 P.x/z plan centers','8 P exact meshes and full foot/head datum for compatibility, stronger than legacy builder input','20 actual primary/wall-rail/porch-floor fixed sections intersecting the finish-slab Y band','68 unchanged bookshelf joineryStock records, especially 10 BOOK-FOOT stock keepouts','214 bookshelf physical geometry records','unchanged floor builder/module/sheet/edge-support code and actual edge-support fixture'],
   'freshChecks':['3056 valid positive single native components','23160 exact internal pairs at unchanged tolerance','8 zero-gap, positive-area 64 in2 post/head bearing contacts per current variant','106 pegs engage both declared hosts through nominal 0.001in radial clearance, verified by radial-only expansion to the declared 0.252in bore without changing axial extent','3056 x49 changed-upper-actor AABB pairs per variant have positive separation'],
   'reuse':'Use existing strict serialized geometry/prototypes only after this separate binding passes. Preserve source_model_sha256=historical source.',
 },
 'wall':{
   'scope':'8 patched primary posts +74 fitted wall actors +134 locking pins per variant. Cupola windows and global primary scene are excluded.',
   'base':'Current P0..P7 meshes plus current schematic-wall actors produced with the current, hash-bound enclosure-fit input. Also compare raw wall generation so stale fit overlays cannot conceal changed inputs.',
   'recipeA':'(CURRENT_BASE + cached.wallJoineryAdded) - cached.wallJoineryRemoved',
   'recipeB':'(CURRENT_BASE + union(joint.tongue where joint.donor=id)) - union(joint.socket_tool where joint.receiver=id, actual locking-peg bore tools that list id)',
   'acceptance':'Both current-input occupied reconstructions must match the cached strict raw boundary at <=1e-6in3 symmetric difference, with fresh raw/native validity and internal static checks.',
   'metadata':'Keep CURRENT primary actor properties and CURRENT primary joineryCavity metadata. Geometry-only snapshots are provided separately; never spread an old cached PASS certificate over current source.',
   'primaryJoints':'All 48 old primary post schedule entries and mating donor geometry are exact unchanged. Fresh actual contact areas remain positive, zero-gap; current primary removed-cavity solids remain void.',
   'pins':'134 actual pins remain in current unbored mating stock, fit declared actual bore hosts without forbidden overlap. Do not infer fit from metadata alone.',
 },
 'porch':{
   'scope':'729 fitted original porch-base actors only. Later roof supports, custom pans, grates, formwork, stairs and connection overlays are excluded.',
   'importantConsumedInput':'The porch roof DOES indirectly consume changed C2/C3 via main cedar face2. Exact maximum projection of both posts along face2 normal is still1.0616882430808336m; actual face2 batches, eave/intercept, roof spec and all raw678 porch actors remain unchanged.',
   'freshGeneration':'Run fit_mudroom_joinery.generate() read-only against CURRENT baseline. Fresh89 fitted and51 added geometry fingerprints equal historical cache;155joint records are exact equal.',
   'crossVariant':'All3 current variants have identical actual raw678 porch and full roof inputs, so the current-baseline fresh generation applies to all3.',
   'freshChecks':['729 native positive single components','3655 exact internal pairs','155/155 positive actual coplanar joint contacts with zero gap','positive AABB separation from all49 changed primary upper actors'],
 },
 'negativeControl':{
   'change':'Move P2 occupied mesh, full center and foot datum upward0.125in, preserving x/z plan centers.',
   'expected':'Legacy floor centerline guard still accepts; fresh gate rejects exact mesh/datum binding, native foot gap measures0.125in, raw wall geometry changes, porch anchor guard throws.',
   'observed':ownership['adversary'],
 },
 'mandatorySeparateOwnerGates':['fresh current primary source/cavity/stock checks','full architecture scene and declared fastener-receiver checks','complete assembly/disassembly current-source motion certification','build/browser/publication checks'],
 'notAuthorization':'No whole-building readiness, capacity, stock sufficiency, assembly route or publication certificate is issued by this package.',
}
save(D / 'compatibility-recipe.json', recipe)
binding = {
 'schema':'current-source-scoped-cache-binding-v1',
 'status':'PASS_BOUNDED_CURRENT_INPUT_COMPATIBILITY',
 'repositoryInputs':deps,
 'artifactInputs':{**proof_deps, 'dependency-and-separation-report.json':sha(D / 'dependency-and-separation-report.json'),'compatibility-recipe.json':sha(D / 'compatibility-recipe.json')},
 'producerInputs':producer_deps,
 'acceptedCurrentModelSha256':{v:sha(R / 'src' / n) for v,n in names.items()},
 'acceptedScopes':['canonical-floor3056','wall-fit8P74wall134pins-all3variants','original-fitted-porch-base729'],
 'preserveHistoricalCacheMetadata':True,
 'rejectOnAnyBoundInputOrProofChange':True,
 'separateCurrentSourceAndWholeAssemblyGatesRequired':True,
 'collisionToleranceIn3':1e-6,
 'runtime':runtime,
}
save(D / 'current-source-scoped-cache-binding.json', binding)
print(json.dumps({'status':binding['status'],'dependencyCount':len(deps),'bindingSha256':sha(D/'current-source-scoped-cache-binding.json'),'separation':separation},indent=2))
