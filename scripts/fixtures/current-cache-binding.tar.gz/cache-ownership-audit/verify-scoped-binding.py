"""Reject changes before historical cache consumption; not a source/motion certificate."""
from pathlib import Path
import argparse, hashlib, json, copy

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest_bytes(raw): return hashlib.sha256(raw).hexdigest()

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--package', type=Path, default=Path(__file__).resolve().parent)
parser.add_argument('--self-test', action='store_true')
args = parser.parse_args()
binding = json.loads((args.package/'current-source-scoped-cache-binding.json').read_text())
errors = []
for name, expected in binding['repositoryInputs'].items():
    path = args.repo/name
    if not path.is_file() or sha(path) != expected: errors.append('repository input changed: '+name)
for name, expected in binding['artifactInputs'].items():
    path = args.package/name
    if not path.is_file() or sha(path) != expected: errors.append('compatibility evidence changed: '+name)
for name, expected in binding['producerInputs'].items():
    path = args.package/name if name == Path(__file__).name else args.package.parent/name
    if not path.is_file() or sha(path) != expected: errors.append('producer input changed: '+name)
if errors: raise SystemExit('\n'.join(errors))
out = {'status':'PASS_BOUNDED_CURRENT_INPUT_BINDING_ONLY','acceptedScopes':binding['acceptedScopes'],'separateCurrentSourceAndWholeAssemblyGatesRequired':True}
if args.self_test:
    path = args.repo/'src/model-data.json'
    model = json.loads(path.read_text())
    changed = copy.deepcopy(model)
    p = next(p for p in changed['parts'] if p['id']=='P2')
    old_plan = [p['center'][0],p['center'][2]]
    offset = .125*.0254
    p['vertices'] = [[v[0],v[1]+offset,v[2]] for v in p['vertices']]
    p['center'][1] += offset
    for key in ['axis_start','axis_end','label_position']:
        if p.get(key): p[key][1] += offset
    mutated = json.dumps(changed,separators=(',',':')).encode()
    expected = binding['repositoryInputs']['src/model-data.json']
    assert digest_bytes(mutated) != expected
    assert [p['center'][0],p['center'][2]] == old_plan
    cache = args.repo/'src/floor-foundation-solids.json'
    assert digest_bytes(cache.read_bytes()+b'\n') != binding['repositoryInputs']['src/floor-foundation-solids.json']
    report = args.package/'floor-current-compatibility-report.json'
    assert digest_bytes(report.read_bytes()+b'\n') != binding['artifactInputs'][report.name]
    out['adversarialControls'] = {'raisedP2FootSamePlanCentersRejected':True,'modifiedCacheBytesRejected':True,'modifiedNativeReceiptBytesRejected':True,'canonicalFilesMutated':False}
print(json.dumps(out,indent=2))
